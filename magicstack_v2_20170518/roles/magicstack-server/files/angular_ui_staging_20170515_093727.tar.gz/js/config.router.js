'use strict';

/**
 * Config for the router
 */
angular.module('app')
    .run(
        ['$rootScope', '$state', '$stateParams',
            function ($rootScope, $state, $stateParams) {
                $rootScope.$state = $state;
                $rootScope.$stateParams = $stateParams;
            }
        ]
    )
    .config(
        ['$stateProvider', '$urlRouterProvider', 'JQ_CONFIG', 'MODULE_CONFIG',
            function ($stateProvider, $urlRouterProvider, JQ_CONFIG, MODULE_CONFIG) {
                var layout = "tpl/app.html";
                var content_layout = "tpl/blocks/nav_header.html";
                // $urlRouterProvider.otherwise('/access/index');
                //校验用户是否登录
                $urlRouterProvider.otherwise(function ($injector, $location) {
                    var msLocalStorage = $injector.get("msLocalStorage");
                    var $http = $injector.get("$http");
                    if (msLocalStorage.get("userId")) {
                        $http({
                            method: 'GET',
                            url: '/v1/permissions/check_login',
                            data: ''
                        }).then(function successCallback(response) {
                            $location.replace().path("/app/ui/overview");
                        }, function errorCallback(response) {
                            $location.replace().path("/access/index");
                        });
                    } else {
                        $location.replace().path("/access/index");
                    }

                });
                /**
                 * 判断用户是否登录如果没有就返回首页、禁止敲路径直接进入页面
                 */
                $urlRouterProvider.rule(function ($injector, $location) {
                    var path = $location.path(),
                        normalized = path.toLowerCase();
                    var msLocalStorage = $injector.get("msLocalStorage");
                    var $http = $injector.get("$http");
                    var $modalStack = $injector.get("$modalStack");
                    $('.app-header').css('z-index', '');
                    $modalStack.dismissAll();//有路由变化时关闭侧拉模态框
                    if (normalized == '/auth/approve' || normalized == '/auth/login') {//SSO
                        var action = $.ms.getUrlParameter('action');
                        if (action == 'setpass') {
                            $location.replace().path(normalized);
                        } else {
                            $location.replace().path("/auth/login");
                        }
                    } else {//登录
                        if (msLocalStorage.get("userId")) {
                            if (normalized) {
                                $location.replace().path(normalized);
                            } else {
                                $location.replace().path("/app/ui/overview");
                            }
                        }
                    }
                });
                $stateProvider
                    .state('access', {
                        url: '/access',
                        template: '<div ui-view class="fade-in-right-big smooth" style="height: 100%"></div>'
                    })
                    .state('access.index', {
                        title: '登录页面',
                        url: '/index',
                        templateUrl: 'tpl/ms_index.html',
                        controller: 'indexCtrl',
                        resolve: {
                            deps: getLoad(['js/controllers/ms-index-controllers.js']),
                            isVerify: ["$http", function ($http) {
                                return $http({
                                    method: 'GET',
                                    url: '/v1/license-manage/check/license/verify/',
                                    data: ''
                                }).then(function successCallback(response) {
                                    return response.data.is_verify;
                                }, function errorCallback(response) {
                                    return true;
                                });
                            }]
                        }
                    })
                    .state('access.404', {
                        title: '404错误页',
                        url: '/404',
                        templateUrl: 'tpl/ms_page_404.html'
                    })
                    /**
                     * 授权登陆
                     */
                    .state('auth', {
                        url: '/auth',
                        template: '<div ui-view class="fade-in-right-big smooth" style="height: 100%"></div>'
                    })
                    .state('auth.approve', {
                        title: '授权批准',
                        url: '/approve/:email/:username/:token',
                        templateUrl: 'tpl/ms_auth_approve.html',
                        controller: 'authApproveCtrl',
                        resolve: load(['js/controllers/ms-authapprove-controllers.js'])
                    })
                    .state('auth.login', {
                        title: '授权登陆',
                        url: '/login/:token',
                        templateUrl: 'tpl/ms_auth_login.html',
                        controller: 'authLoginCtrl',
                        resolve: load(['js/controllers/ms-authapprove-controllers.js'])
                    })
                    .state('auth.sso', {
                        title: '单点登录请求',
                        url: '/sso',
                        templateUrl: 'tpl/ms_auth_login.html',
                        controller: 'ssoCtrl',
                        resolve: load(['js/controllers/ms-authapprove-controllers.js'])
                    })
                    .state('auth.license', {
                        title: 'License认证',
                        url: '/license',
                        templateUrl: 'tpl/ms_auth_license.html',
                        controller: 'licenseAuthCtrl',
                        resolve: load(['js/controllers/ms-authapprove-controllers.js'])
                    })
                    .state('pluginView', {
                        title: '插件详情',
                        url: '/plugin-view/:url',
                        templateUrl: 'tpl/ms_plugin_view.html',
                        controller: 'pluginViewController',
                        resolve: load([
                            'js/controllers/ms-pluginview-controllers.js'])
                    })
                    .state('app', {
                        abstract: true,
                        url: '/app',
                        templateUrl: layout,
                        controller: 'appController',
                        resolve: {
                            deps: getLoad(['js/controllers/ms-app-controllers.js']),
                            permission: ["$http", 'msLocalStorage', function ($http, msLocalStorage) {
                                return $http({
                                    method: 'GET',
                                    err_title: "查询权限",
                                    url: '/v1/permissions/project/' + msLocalStorage.get("projectId") + '/my-permission/',
                                }).then(function successCallback(response) {
                                    $.ms.setPermissions(response.data);
                                })
                            }],
                        }
                    })
                    .state('app.ui', {
                        url: '/ui',
                        template: '<div ui-view class="fade-in-up"></div>'
                    })
                    .state('app.ui.overview', {
                        title: '全局概览',
                        url: '/overview',
                        perm: '',
                        hideChangeProject: true,
                        templateUrl: 'tpl/ms_overview.html',
                        controller: 'overviewController',
                        resolve: load(['js/controllers/ms-overview-controllers.js'])
                    })
                    //项目管理
                    .state('app.project', {
                        url: '/project',
                        templateUrl: content_layout,
                        controller: 'contentLayoutController',
                        resolve: {
                            deps: getLoad([
                                'js/controllers/ms-app-controllers.js']),
                            tabs: function () {
                                return [
                                    // {stateName: 'app.project.user', title: '用户列表', perm: 'USER_LIST_MENU'},
                                    {stateName: 'app.project.asset', title: '资产列表', perm: 'ASSET_LIST_MENU'},
                                    {stateName: 'app.project.idc', title: '机房列表', perm: 'ASSET_IDC_MENU'}];
                            }
                        }
                    })
                    .state('app.project.user', {//用户列表
                        title: '用户列表',
                        url: '/user',
                        perm: 'USER_LIST_MENU',
                        hideChangeProject: true,
                        templateUrl: 'tpl/ms_project_user.html',
                        controller: 'userlistController',
                        resolve: {
                            deps: getLoad([
                                'ui.select',
                                'js/controllers/ms-projectuser-controllers.js']),
                            ldapauth_type: ["$http", 'msLocalStorage', function ($http, msLocalStorage) {
                                return $http({
                                    method: 'GET',
                                    err_title: "查询LDAP",
                                    url: '/v1/global-settings/ldap/list/',
                                }).then(function successCallback(response) {
                                    return !response.data.results[0].manageable && response.data.results[0].ldap_auth;
                                })
                            }],
                            is_admin: function () {
                                return false;
                            }
                        }
                    })
                    .state('app.project.asset', {
                        title: '资产列表',
                        url: '/asset',
                        perm: 'ASSET_LIST_MENU',
                        templateUrl: 'tpl/ms_project_asset.html',
                        controller: 'assetController',
                        resolve: load(['moment',
                            'libs/jquery/underscore/underscore-min.js',
                            'js/controllers/ms-projectasset-controllers.js'])
                    })
                    .state('app.project.idc', {
                        title: '机房列表',
                        url: '/idc',
                        perm: 'ASSET_IDC_MENU',
                        templateUrl: 'tpl/ms_project_idc.html',
                        controller: 'idcController',
                        resolve: {
                            deps: getLoad(['js/controllers/ms-projectidc-controllers.js']),
                            is_admin: function () {
                                return false;
                            }
                        }
                    })
                    //IDC详情
                    .state('app.idcdetail', {
                        title: 'IDC详情',
                        url: '/idcdetail/:id',
                        templateUrl: 'tpl/ms_projectidc_detail.html',
                        controller: 'idcDetailController',
                        resolve: {
                            deps: getLoad(['js/controllers/ms-projectidc-controllers.js']),
                            is_admin: function () {
                                return false;
                            }
                        }
                    })
                    .state('app.batchupload', {
                        title: '批量导入',
                        url: '/batchupload',
                        perm: '',
                        templateUrl: 'tpl/ms_project_batchupload.html',
                        controller: 'batchUploadController',
                        resolve: load(['ngFileUpload', 'js/controllers/ms-projectasset-controllers.js'])
                    })
                    .state('app.hostdetection', {
                        title: '主机探测',
                        url: '/hostdetection',
                        perm: '',
                        templateUrl: 'tpl/ms_project_hostdetection.html',
                        controller: 'hostDetectionController',
                        resolve: load(['ngFileUpload', 'js/controllers/ms-projectasset-controllers.js'])
                    })
                    //应用管理
                    .state('app.use', {
                        url: '/use',
                        templateUrl: content_layout,
                        controller: 'contentLayoutController',
                        resolve: {
                            deps: getLoad([
                                'js/controllers/ms-app-controllers.js']),
                            tabs: function () {
                                return [{stateName: 'app.use.modulescript', title: '模板剧本', perm: 'APP_MODULE_MENU'}];
                                // {stateName:'app.use.containerdeploy',title:'容器部署',perm:'APP_CONTAINER_MENU'}
                            }
                        }
                    })
                    .state('app.use.modulescript', {
                        title: '模板剧本',
                        url: '/modulescript',
                        perm: 'APP_MODULE_MENU',
                        hideChangeProject: true,
                        templateUrl: 'tpl/ms_module_script.html',
                        controller: 'modulescriptController',
                        resolve: load([
                            'ngFileUpload',
                            'ui.select',
                            'js/controllers/ms-modulescript-controllers.js'])
                    })
                    .state('app.apprun', {
                        title: '应用部署',
                        url: '/apprun/:id/:deploy_id/',
                        perm: '',
                        templateUrl: 'tpl/ms_project_apprun.html',
                        controller: 'appRunController',
                        resolve: load(['ui.select',
                            'ui.ace',
                            'libs/xterm/xterm.js',
                            'libs/jquery/ace-builds/mode-sh.js',
                            'libs/jquery/ace-builds/mode-yaml.js',
                            'js/controllers/ms-apprun.js',
                            'js/services/ms_item_select_modal.js'])
                    })
                    .state('app.use.containerdeploy', {
                        title: '容器部署',
                        url: '/containerdeploy',
                        perm: 'APP_CONTAINER_MENU',
                        hideChangeProject: true,
                        templateUrl: 'tpl/ms_container_deploy.html',
                        controller: 'containerdeployController',
                        resolve: load(['js/controllers/ms-containerdeploy-controllers.js'])
                    })
                    //任务管理
                    .state('app.task', {
                        url: '/task',
                        templateUrl: content_layout,
                        controller: 'contentLayoutController',
                        resolve: {
                            deps: getLoad([
                                'js/controllers/ms-app-controllers.js']),
                            tabs: function () {
                                return [{stateName: 'app.task.list', title: '常规任务', perm: 'TASK_COMMON_MENU'},
                                    {stateName: 'app.task.listtpl', title: '常规任务模版', perm: ''},
                                    {stateName: 'app.task.advlist', title: '高级任务', perm: 'TASK_ADVANCED_MENU'},
                                    {stateName: 'app.task.advlisttpl', title: '高级任务模版', perm: ''},
                                    {stateName: 'app.task.pathfile', title: '路径/文件备份', perm: 'BACKUP_FILE_MENU'},
                                    {stateName: 'app.task.mysqlbak', title: '数据库备份', perm: 'BACKUP_DATABASE_MENU'}];
                            }
                        }
                    })
                    .state('app.task.list', {
                        title: '常规任务',
                        url: '/list',
                        perm: 'TASK_COMMON_MENU',
                        templateUrl: 'tpl/ms_task_list.html',
                        controller: 'tasklistController',
                        resolve: load([
                            'ui.select',
                            'libs/xterm/xterm.js',
                            'js/services/ms_playback.js',
                            'libs/jquery/underscore/underscore-min.js',
                            'js/controllers/ms-tasklist-controllers.js'])
                    })
                    .state('app.task.listtpl', {
                        title: '常规任务模版',
                        url: '/listtpl',
                        perm: '',
                        templateUrl: 'tpl/ms_task_listtpl.html',
                        controller: 'tasklistTplController',
                        resolve: load([
                            'ui.select',
                            'libs/xterm/xterm.js',
                            'js/services/ms_playback.js',
                            'libs/jquery/underscore/underscore-min.js',
                            'js/controllers/ms-task-tpl-list-controllers.js'])
                    })
                    .state('app.task.advlist', {
                        title: '高级任务',
                        url: '/advlist',
                        perm: 'TASK_ADVANCED_MENU',
                        templateUrl: 'tpl/ms_task_advlist.html',
                        controller: 'taskadvlistController',
                        resolve: load([
                            'ui.select',
                            'ui.ace',
                            'libs/xterm/xterm.js',
                            'libs/jquery/ace-builds/mode-sh.js',
                            'libs/jquery/ace-builds/mode-yaml.js',
                            'js/services/ms_playback.js',
                            'js/controllers/ms-taskadvlist-controllers.js'])
                    })
                    .state('app.task.advlisttpl', {
                        title: '高级任务模版',
                        url: '/advlisttpl',
                        perm: '',
                        templateUrl: 'tpl/ms_task_advlisttpl.html',
                        controller: 'taskadvlisttplController',
                        resolve: load([
                            'ui.select',
                            'ui.ace',
                            'libs/xterm/xterm.js',
                            'libs/jquery/ace-builds/mode-sh.js',
                            'libs/jquery/ace-builds/mode-yaml.js',
                            'js/services/ms_playback.js',
                            'js/controllers/ms-taskadv-tpl-list-controllers.js'])
                    })
                    .state('app.task.pathfile', {
                        title: '路径/文件备份',
                        url: '/pathfile',
                        perm: 'BACKUP_FILE_MENU',
                        templateUrl: 'tpl/ms_backup_pathfile.html',
                        controller: 'pathfileController',
                        resolve: load([
                            'ui.select',
                            'libs/xterm/xterm.js',
                            'js/services/ms_playback.js',
                            'js/controllers/ms-pathfile-controllers.js'])
                    })
                    .state('app.task.mysqlbak', {
                        title: '数据库备份',
                        url: '/mysqlbak',
                        perm: 'BACKUP_DATABASE_MENU',
                        templateUrl: 'tpl/ms_backup_mysqlbak.html',
                        controller: 'mysqlbakController',
                        resolve: load([
                            'ui.select',
                            'libs/xterm/xterm.js',
                            'js/services/ms_playback.js',
                            'js/controllers/ms-mysqlbak-controllers.js'])
                    })
                    //授权管理
                    .state('app.permission', {
                        url: '/permission',
                        templateUrl: content_layout,
                        controller: 'contentLayoutController',
                        resolve: {
                            deps: getLoad([
                                'js/controllers/ms-app-controllers.js']),
                            tabs: function () {
                                return [{stateName: 'app.permission.sudo', title: 'SUDO', perm: 'AUTH_SUDO_MENU'},
                                    {stateName: 'app.permission.role', title: '系统用户', perm: 'AUTH_ROLE_MENU'},
                                    {stateName: 'app.permission.rule', title: '授权规则', perm: 'AUTH_RULE_MENU'}];
                            }
                        }
                    })
                    .state('app.permission.sudo', {
                        title: 'SUDO',
                        url: '/sudo',
                        perm: 'AUTH_SUDO_MENU',
                        templateUrl: 'tpl/ms_permission_sudo.html',
                        controller: 'permissionsudoController',
                        resolve: load(['js/controllers/ms-permissionsudo-controllers.js'])
                    })
                    .state('app.permission.role', {
                        title: '系统用户',
                        url: '/role',
                        perm: 'AUTH_ROLE_MENU',
                        templateUrl: 'tpl/ms_permission_role.html',
                        controller: 'permissionroleController',
                        resolve: load([
                            'ui.select',
                            'js/controllers/ms-permissionrole-controllers.js'])
                    })
                    .state('app.permission.rule', {
                        title: '授权规则',
                        url: '/rule',
                        perm: 'AUTH_RULE_MENU',
                        templateUrl: 'tpl/ms_permission_rule.html',
                        controller: 'permissionruleController',
                        resolve: load([
                            'ui.select',
                            'js/controllers/ms-permissionrule-controllers.js'])
                    })
                    //日志管理
                    .state('app.log', {
                        url: '/log',
                        templateUrl: content_layout,
                        controller: 'contentLayoutController',
                        resolve: {
                            deps: getLoad([
                                'js/controllers/ms-app-controllers.js']),
                            tabs: function () {
                                return [{stateName: 'app.log.online', title: '在线', perm: 'LOG_ASSET_ONLINE_QUERY'},
                                    {stateName: 'app.log.history', title: '历史登录', perm: 'LOG_ASSET_LOGIN_QUERY'},
                                    {stateName: 'app.log.alarmevent', title: '告警事件', perm: 'LOG_ALARM_QUERY'},
                                    {stateName: 'app.log.usersrecord', title: '操作记录', perm: 'LOG_OPERATOR_QUERY'},
                                    {stateName: 'app.log.apprunlog', title: '应用部署记录', perm: ''},
                                    {stateName: 'app.log.monitor', title: '监控告警记录', perm: ''},
                                ];
                            }
                        }
                    })
                    .state('app.log.online', {
                        title: '在线',
                        url: '/list',
                        perm: 'LOG_LIST_MENU',
                        templateUrl: 'tpl/ms_log_online.html',
                        controller: 'logOnLineController',
                        resolve: load([
                            'ui.select',
                            'js/controllers/ms-loglist-controllers.js'
                        ])
                    })
                    .state('app.log.history', {
                        title: '历史登录',
                        url: '/history',
                        perm: 'LOG_LIST_MENU',
                        templateUrl: 'tpl/ms_log_historyinquire.html',
                        controller: 'logHistoryController',
                        resolve: load([
                            'ui.select',
                            'libs/xterm/xterm.js',
                            'js/services/ms_playback.js',
                            'js/controllers/ms-loglist-controllers.js'
                        ])
                    })

                    .state('app.log.alarmevent', {
                        title: '告警事件',
                        url: '/alarmevent',
                        perm: 'LOG_LIST_MENU',
                        templateUrl: 'tpl/ms_log_alarmeventinquire.html',
                        controller: 'logAlarmEventController',
                        resolve: load([
                            'ui.select',
                            'js/controllers/ms-loglist-controllers.js'
                        ])
                    })

                    .state('app.log.usersrecord', {
                        title: '操作记录',
                        url: '/usersrecord',
                        perm: 'LOG_LIST_MENU',
                        templateUrl: 'tpl/ms_log_usersrecordinquire.html',
                        controller: 'logUsersRecordController',
                        resolve: load([
                            'ui.select',
                            'js/controllers/ms-loglist-controllers.js'
                        ])
                    })
                    .state('app.log.apprunlog', {
                        title: '应用部署记录',
                        url: '/apprunlog',
                        perm: '',
                        templateUrl: 'tpl/ms_log_apprunlog.html',
                        controller: 'apprunLogController',
                        resolve: load([
                            'ui.select',
                            'libs/xterm/xterm.js',
                            'js/controllers/app-log-runapplog.js'
                        ])
                    })
                    .state('app.log.monitor', {
                        title: '监控告警记录',
                        url: '/monitor',
                        perm: '',
                        templateUrl: 'tpl/ms_log_monitor.html',
                        controller: 'logMonitorController',
                        resolve: load([
                            'ui.select',
                            'libs/xterm/xterm.js',
                            'js/services/ms_playback.js',
                            'js/controllers/ms-logmonitor-controllers.js'
                        ])
                    })
                    //待办事项 或者 我的工作
                    .state('app.wokerflow', {
                        url: '/wokerflow',
                        templateUrl: content_layout,
                        controller: 'contentLayoutController',
                        resolve: {
                            deps: getLoad([
                                'js/controllers/ms-app-controllers.js']),
                            tabs: function () {
                                return [{
                                    stateName: 'app.wokerflow.mycreate',
                                    title: '我起草的',
                                    perm: 'WORKFLOW_MY_CREATE_MENU'
                                },
                                    {stateName: 'app.wokerflow.willdo', title: '待处理的', perm: 'WORKFLOW_WILL_DO_MENU'},
                                    {
                                        stateName: 'app.wokerflow.complete',
                                        title: '已完成的',
                                        perm: 'WORKFLOW_COMPLETE_MENU'
                                    }];
                            }
                        }
                    })
                    .state('app.wokerflow.mycreate', {
                        title: '我起草的',
                        url: '/mycreate',
                        perm: 'WORKFLOW_MY_CREATE_MENU',
                        templateUrl: 'tpl/ms_wokerflow_mycreate.html',
                        controller: 'wokerFlowMyCreateCtrl',
                        resolve: load(['js/controllers/ms-wokerflowmycreate-controllers.js'])
                    })
                    .state('app.wokerflow.willdo', {
                        title: '待处理的',
                        url: '/willdo',
                        perm: 'WORKFLOW_WILL_DO_MENU',
                        templateUrl: 'tpl/ms_wokerflow_willdo.html',
                        controller: 'wokerFlowWillDoCtrl',
                        resolve: load(['js/controllers/ms-wokerflowwilldo-controllers.js'])
                    })
                    .state('app.wokerflow.complete', {
                        title: '已完成的',
                        url: '/complete',
                        perm: 'WORKFLOW_COMPLETE_MENU',
                        templateUrl: 'tpl/ms_wokerflow_complete.html',
                        controller: 'wokerFlowMyCompleteCtrl',
                        resolve: load(['js/controllers/ms-wokerflowmycomplete-controllers.js'])
                    })
                    //插件管理
                    .state('app.pluginmanage', {
                        url: '/pluginmanage',
                        templateUrl: content_layout,
                        controller: 'contentLayoutController',
                        resolve: {
                            deps: getLoad([
                                'js/controllers/ms-app-controllers.js']),
                            tabs: function () {
                                return [{stateName: 'app.pluginmanage.list', title: '插件列表', perm: 'PLUGIN_LIST_MENU'}];
                            }
                        }
                    })
                    .state('app.pluginmanage.list', {
                        title: '插件列表',
                        url: '/list',
                        perm: 'PLUGIN_LIST_MENU',
                        templateUrl: 'tpl/ms_pluginmanage_list.html',
                        controller: 'pluginmanageController',
                        resolve: load([
                            'js/controllers/ms-pluginmanage-controllers.js'
                        ])
                    })
                    //插件详情
                    .state('app.plugindetail', {
                        title: '插件详情',
                        url: '/plugindetail/:url',
                        perm: '',
                        templateUrl: 'tpl/ms_plugindetail.html',
                        controller: 'pluginDetailController',
                        resolve: load(['js/controllers/ms-pluginmanage-controllers.js'])
                    })
                    //警告管理
                    .state('app.emergency', {
                        url: '/emergency',
                        templateUrl: content_layout,
                        controller: 'contentLayoutController',
                        resolve: {
                            deps: getLoad([
                                'js/controllers/ms-app-controllers.js']),
                            tabs: function () {
                                return [
                                    // {stateName: 'app.emergency.media', title: '告警媒介类型', perm: 'ALARM_TYPE_MENU'},
                                    {stateName: 'app.emergency.rule', title: '告警设置', perm: 'ALARM_SETTING_MENU'},
                                    // {stateName: 'app.emergency.monitor', title: '监控告警', perm: ''}
                                ];
                            }
                        }
                    })
                    .state('app.emergency.media', {
                        title: '告警媒介类型',
                        url: '/media',
                        perm: 'ALARM_TYPE_MENU',
                        templateUrl: 'tpl/ms_emergency_media.html',
                        controller: 'emergencymediaController',
                        resolve: {
                            deps: getLoad([
                                'js/controllers/ms-emergencymedia-controllers.js'
                            ]),
                            is_admin: function () {
                                return false;
                            }
                        }
                    })
                    .state('app.emergency.rule', {
                        title: '告警设置',
                        url: '/rule',
                        perm: 'ALARM_SETTING_MENU',
                        templateUrl: 'tpl/ms_emergency_rule.html',
                        controller: 'emergencyruleController',
                        resolve: load(['xeditable',
                            "ngMockE2E", "checklist-model",
                            'js/controllers/ms-emergencyrule-controllers.js'])
                    })
                    .state('app.emergency.monitor', {
                        title: '监控告警',
                        url: '/monitor',
                        perm: '',
                        templateUrl: 'tpl/ms_emergency_monitor.html',
                        controller: 'emergencyMonitorController',
                        resolve: load(['js/controllers/ms-emergencymonitor-controllers.js'])
                    })
                    .state('app.newmonitor', {
                        title: '新增监控告警',
                        url: '/newmonitor',
                        perm: '',
                        templateUrl: 'tpl/ms_emergency_neweditmonitor.html',
                        controller: 'emergencyNewEditMonitorController',
                        resolve: load(['xeditable',
                            'ui.select',
                            "ngMockE2E", "checklist-model",
                            'js/controllers/ms-emergencymonitor-controllers.js'])
                    })
                    .state('app.editmonitor', {
                        title: '编辑监控告警',
                        url: '/editmonitor/:id',
                        perm: '',
                        templateUrl: 'tpl/ms_emergency_neweditmonitor.html',
                        controller: 'emergencyNewEditMonitorController',
                        resolve: load(['xeditable',
                            'ui.select',
                            "ngMockE2E", "checklist-model",
                            'js/controllers/ms-emergencymonitor-controllers.js'])
                    })
                    //上传下载
                    .state('app.updownload', {
                        url: '/updownload',
                        templateUrl: content_layout,
                        controller: 'contentLayoutController',
                        resolve: {
                            deps: getLoad([
                                'js/controllers/ms-app-controllers.js']),
                            tabs: function () {
                                return [{
                                    stateName: 'app.updownload.fileupload',
                                    title: '文件上传',
                                    perm: 'FILE_UPLOAD_MENU'
                                },
                                    {
                                        stateName: 'app.updownload.filedownload',
                                        title: '文件下载',
                                        perm: 'FILE_DOWNLOAD_MENU'
                                    }];
                            }
                        }
                    })
                    .state('app.updownload.fileupload', {
                        title: '文件上传',
                        url: '/fileupload',
                        perm: 'FILE_UPLOAD_MENU',
                        templateUrl: 'tpl/ms_file_upload.html',
                        controller: 'fileuploadController',
                        resolve: load([
                            'ngFileUpload',
                            'ui.select',
                            'js/controllers/ms-fileupload-controllers.js'])
                    })
                    .state('app.updownload.filedownload', {
                        title: '文件下载',
                        url: '/filedownload',
                        perm: 'FILE_DOWNLOAD_MENU',
                        templateUrl: 'tpl/ms_file_download.html',
                        controller: 'filedownloadController',
                        resolve: load(['js/controllers/ms-filedownload-controllers.js'])
                    })
                    //持续集成
                    .state('app.integration', {
                        url: '/integration',
                        templateUrl: content_layout,
                        controller: 'contentLayoutController',
                        resolve: {
                            deps: getLoad([
                                'js/controllers/ms-app-controllers.js']),
                            tabs: function () {
                                return [{
                                    stateName: 'app.integration.continuous',
                                    title: '持续集成',
                                    perm: ''
                                }];
                            }
                        }
                    })
                    .state('app.integration.continuous', {
                        title: '持续集成',
                        url: '/continuous',
                        perm: '',
                        templateUrl: 'tpl/ms_continuous_integration.html',
                        controller: 'cIController',
                        resolve: load(['js/controllers/ms-continuousintegration-controllers.js'])
                    })
                    .state('app.newcontinuous', {
                        title: '新增持续集成',
                        url: '/newcontinuous',
                        perm: '',
                        templateUrl: 'tpl/ms_newedit_continuous.html',
                        controller: 'newEditCIController',
                        resolve: load([
                            'ui.select',
                            'js/controllers/ms-continuousintegration-controllers.js'])
                    })
                    .state('app.editcontinuous', {
                        title: '编辑持续集成',
                        url: '/newcontinuous/:id',
                        perm: '',
                        templateUrl: 'tpl/ms_newedit_continuous.html',
                        controller: 'newEditCIController',
                        resolve: load([
                            'ui.select',
                            'js/controllers/ms-continuousintegration-controllers.js'])
                    })
                    .state('app.cibuild', {
                        title: '持续集成构建',
                        url: '/cibuild/:id',
                        perm: '',
                        templateUrl: 'tpl/ms_ci_detail.html',
                        controller: 'cIBuildCIController',
                        resolve: load(['moment', 'js/controllers/ms-continuousintegration-controllers.js'])
                    })
                    .state('app.cibuildattr', {
                        title: '持续集成详情',
                        url: '/cibuildattr/:id',
                        perm: '',
                        templateUrl: 'tpl/ms_ciattr_detail.html',
                        controller: 'cIBuildAttrCIController',
                        resolve: load([
                            'moment',
                            'ui.ace',
                            'libs/xterm/xterm.js',
                            'libs/jquery/ace-builds/mode-sh.js',
                            'libs/jquery/ace-builds/mode-yaml.js',
                            'js/controllers/ms-continuousintegration-controllers.js'])
                    })
                    .state('app.cibuildrequest', {
                        title: '持续集成构建请求',
                        url: '/cibuildrequest/:id',
                        perm: '',
                        templateUrl: 'tpl/ms_ci_buildrequests.html',
                        controller: 'cIBuildRequestsCIController',
                        resolve: load(['moment', 'js/controllers/ms-continuousintegration-controllers.js'])
                    })
                    .state('admin', {
                        abstract: true,
                        url: '/admin',
                        templateUrl: layout,
                        controller: 'appController',
                        resolve: {
                            deps: getLoad(['js/controllers/ms-app-controllers.js']),
                            permission: ["$http", 'msLocalStorage', function ($http, msLocalStorage) {
                                return $http({
                                    method: 'GET',
                                    err_title: "查询权限",
                                    url: '/v1/permissions/project/' + msLocalStorage.get("projectId") + '/my-permission/',
                                }).then(function successCallback(response) {
                                    $.ms.setPermissions(response.data);
                                })
                            }],
                        }
                    })
                    //项目管理
                    .state('admin.project', {
                        url: '/project',
                        templateUrl: content_layout,
                        controller: 'contentLayoutController',
                        resolve: {
                            deps: getLoad([
                                'js/controllers/ms-app-controllers.js']),
                            tabs: function () {
                                return [{stateName: 'admin.project.list', title: '项目列表', perm: ''},
                                    {stateName: 'admin.project.user', title: '用户列表', perm: ''},
                                    {stateName: 'admin.project.idc', title: '机房列表', perm: ''}];
                            }
                        }
                    })
                    .state('admin.project.list', {
                        title: '项目列表',
                        url: '/list',
                        perm: 'PROJECT_LIST_MENU',
                        hideChangeProject: true,
                        templateUrl: 'tpl/ms_project_list.html',
                        controller: 'projectListController',
                        resolve: load([
                            'ui.select',
                            'js/controllers/ms-projectlist-controllers.js'])
                    })
                    .state('admin.project.user', {//用户列表
                        title: '用户列表',
                        url: '/user',
                        perm: 'USER_LIST_MENU',
                        hideChangeProject: true,
                        templateUrl: 'tpl/ms_project_user.html',
                        controller: 'userlistController',
                        resolve: {
                            deps: getLoad([
                                'ui.select',
                                'js/controllers/ms-projectuser-controllers.js']),
                            ldapauth_type: ["$http", 'msLocalStorage', function ($http, msLocalStorage) {
                                return $http({
                                    method: 'GET',
                                    err_title: "查询LDAP",
                                    url: '/v1/global-settings/ldap/list/',
                                }).then(function successCallback(response) {
                                    return !response.data.results[0].manageable && response.data.results[0].ldap_auth;
                                })
                            }],
                            is_admin: function () {
                                return true;
                            }
                        }
                    })
                    .state('admin.project.idc', {
                        title: '机房列表',
                        url: '/idc',
                        perm: 'ASSET_IDC_MENU',
                        hideChangeProject: true,
                        templateUrl: 'tpl/ms_project_idc.html',
                        controller: 'idcController',
                        resolve: {
                            deps: getLoad(['js/controllers/ms-projectidc-controllers.js']),
                            is_admin: function () {
                                return true;
                            }
                        }
                    })
                    //IDC详情
                    .state('admin.idcdetail', {
                        title: 'IDC详情',
                        url: '/idcdetail/:id',
                        hideChangeProject: true,
                        templateUrl: 'tpl/ms_projectidc_detail.html',
                        controller: 'idcDetailController',
                        resolve: {
                            deps: getLoad(['js/controllers/ms-projectidc-controllers.js']),
                            is_admin: function () {
                                return true;
                            }
                        }
                    })
                    //代理管理
                    .state('admin.proxy', {
                        url: '/proxy',
                        templateUrl: content_layout,
                        controller: 'contentLayoutController',
                        resolve: {
                            deps: getLoad([
                                'js/controllers/ms-app-controllers.js']),
                            tabs: function () {
                                return [{stateName: 'admin.proxy.list', title: '项目列表', perm: ''}];
                            }
                        }
                    })
                    .state('admin.proxy.list', {
                        title: '代理列表',
                        url: '/list',
                        perm: 'PROXY_LIST_MENU',
                        hideChangeProject: true,
                        templateUrl: 'tpl/ms_proxy_list.html',
                        controller: 'proxylistController',
                        resolve: load(['js/controllers/ms-proxylist-controllers.js'])
                    })
                    //应用管理
                    .state('admin.use', {
                        url: '/use',
                        templateUrl: content_layout,
                        controller: 'contentLayoutController',
                        resolve: {
                            deps: getLoad([
                                'js/controllers/ms-app-controllers.js']),
                            tabs: function () {
                                return [{stateName: 'admin.use.modulescript', title: '模板剧本', perm: ''}];
                            }
                        }
                    })
                    .state('admin.use.modulescript', {
                        title: '模板剧本',
                        url: '/modulescript',
                        perm: 'APP_MODULE_MENU',
                        hideChangeProject: true,
                        templateUrl: 'tpl/ms_module_script.html',
                        controller: 'modulescriptController',
                        resolve: load([
                            'ngFileUpload',
                            'ui.select',
                            'js/controllers/ms-modulescript-controllers.js'])
                    })
                    .state('admin.use.containerdeploy', {
                        title: '容器部署',
                        url: '/containerdeploy',
                        perm: 'APP_CONTAINER_MENU',
                        hideChangeProject: true,
                        templateUrl: 'tpl/ms_container_deploy.html',
                        controller: 'containerdeployController',
                        resolve: load(['js/controllers/ms-containerdeploy-controllers.js'])
                    })
                    //警告管理
                    .state('admin.emergency', {
                        url: '/emergency',
                        templateUrl: content_layout,
                        controller: 'contentLayoutController',
                        resolve: {
                            deps: getLoad([
                                'js/controllers/ms-app-controllers.js']),
                            tabs: function () {
                                return [
                                    {stateName: 'admin.emergency.media', title: '告警媒介类型', perm: 'ALARM_TYPE_MENU'},
                                ];
                            }
                        }
                    })
                    .state('admin.emergency.media', {
                        title: '告警媒介类型',
                        url: '/media',
                        perm: 'ALARM_TYPE_MENU',
                        templateUrl: 'tpl/ms_emergency_media.html',
                        controller: 'emergencymediaController',
                        resolve: {
                            deps: getLoad([
                                'js/controllers/ms-emergencymedia-controllers.js'
                            ]),
                            is_admin: function () {
                                return true;
                            }
                        }
                    })
                    //全局设置
                    .state('admin.legalize', {
                        url: '/legalize',
                        templateUrl: content_layout,
                        controller: 'contentLayoutController',
                        resolve: {
                            deps: getLoad([
                                'js/controllers/ms-app-controllers.js']),
                            tabs: function () {
                                return [{stateName: 'admin.legalize.certification', title: '认证', perm: ''}];
                            }
                        }
                    })
                    .state('admin.legalize.certification', {
                        title: '认证',
                        url: '/certification',
                        perm: 'GLOBAL_SETTINGS_AUTH_MENU',
                        hideChangeProject: true,
                        templateUrl: 'tpl/ms_certification_set.html',
                        controller: 'certificationSetController',
                        resolve: load(['js/controllers/ms-certificationset-controllers.js'])
                    })
                    .state('admin.legalize.set', {
                        title: '全局设置',
                        url: '/set',
                        perm: '',
                        templateUrl: 'tpl/ms_global_set.html',
                        controller: 'globalsetController',
                        resolve: load(['xeditable',
                            "ngMockE2E", "checklist-model",
                            'js/controllers/ms-globalset-controllers.js'])
                    });

                function getLoad(srcs, callback) {
                    return ['$$animateJs', '$ocLazyLoad', '$q',
                        function ($$animateJs, $ocLazyLoad, $q) {
                            var deferred = $q.defer();
                            var promise = false;
                            srcs = angular.isArray(srcs) ? srcs : srcs.split(/\s+/);
                            if (!promise) {
                                promise = deferred.promise;
                            }
                            angular.forEach(srcs, function (src) {
                                promise = promise.then(function () {
                                    if (JQ_CONFIG[src]) {
                                        return $ocLazyLoad.load(JQ_CONFIG[src]);
                                    }
                                    angular.forEach(MODULE_CONFIG, function (module) {
                                        if (module.name == src) {
                                            name = module.name;
                                        } else {
                                            name = src;
                                        }
                                    });
                                    return $ocLazyLoad.load(name);
                                });
                            });
                            deferred.resolve();
                            return callback ? promise.then(function () {
                                    return callback();
                                }) : promise;
                        }];
                }

                function load(srcs, callback) {
                    return {
                        deps: getLoad(srcs, callback)
                    }
                }
            }
        ]
    );
