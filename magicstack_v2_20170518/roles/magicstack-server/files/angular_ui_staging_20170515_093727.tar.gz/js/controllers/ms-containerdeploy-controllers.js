/**
 * Created by lidukang on 2016/8/5.
 * 应用管理-容器部署
 */
'use strict';
app.controller('containerdeployController', ['$rootScope','$scope','$state',
    function($rootScope,$scope,$state) {

    }
]);
