/**
 * Created by lidukang on 2016/8/5.
 * 任务管理-高级任务
 */
'use strict';

app.controller('advTaskTplModalCtrl', ['$rootScope', '$scope', '$http', '$modalInstance',
    'msLocalStorage', '$timeout', 'toaster', 'items',
    function ($rootScope, $scope, $http, $modalInstance,
              msLocalStorage, $timeout, toaster, items) {
        $scope.type = 'sh';
        $scope.modes = ['sh', 'yaml'];
        if (!$.ms.isEmptyObject(items)) {
            $http({
                method: 'GET',
                err_title: "查询高级任务",
                url: '/v1/task-tpl/project/' + msLocalStorage.get("projectId") + '/advanced-tasktpl/' + items.id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.advTaskModel = response.data;
                    $scope.advTaskModel.type = $scope.DataBaseToScriptType($scope.advTaskModel.type);
                    $scope.type = $scope.advTaskModel.type;

                    // The ui-ace option
                    $scope.aceOption = {
                        theme: 'monokai',
                        mode: $scope.advTaskModel.type,
                        onLoad: function (_ace) {
                            // HACK to have the ace instance in the scope...
                            $scope.modeChanged = function () {
                                _ace.getSession().setMode("ace/mode/" + $scope.advTaskModel.type);
                            };
                        }
                    };

                    $scope.advTaskModel.assetNames = '';
                    angular.forEach($scope.advTaskModel.assets, function (data, index, array) {
                        if ($scope.advTaskModel.assetNames) {
                            $scope.advTaskModel.assetNames += ',' + data.name;
                        } else {
                            $scope.advTaskModel.assetNames = data.name;
                        }
                    });
                }
            });
        } else {
            $scope.advTaskModel = {trigger_kwargs: {}};
            $scope.advTaskModel.type = $scope.modes[0];
            // The ui-ace option
            $scope.aceOption = {
                theme: 'monokai',
                mode: $scope.advTaskModel.type,
                onLoad: function (_ace) {
                    // HACK to have the ace instance in the scope...
                    $scope.modeChanged = function () {
                        _ace.getSession().setMode("ace/mode/" + $scope.advTaskModel.type);
                    };
                }
            };
        }

        $scope.shContent = '';
        $scope.yamlContent = '';

        $scope.$watch('advTaskModel.type', function (newVal, oldVal) {
            if ($scope.type != newVal) {
                if (newVal == 'sh') {
                    $scope.yamlContent = $scope.advTaskModel.content;
                    $scope.advTaskModel.content = $scope.shContent;
                }
                if (newVal == 'yaml') {
                    $scope.shContent = $scope.advTaskModel.content;
                    $scope.advTaskModel.content = $scope.yamlContent;
                }
                $scope.type = newVal;
            }
            if (newVal == 'yaml' && $scope.advTaskModel.content == '') {
                $scope.type = newVal;
                $scope.advTaskModel.content = '---\n' +
                    '  - hosts: default_group\n' +
                    '    remote_user: root\n' +
                    '    tasks:\n';

            }

        });

        $scope.scriptTypeToDataBase = function (type) {
            if (type === 'sh') {
                return 'shell';
            }
            if (type === 'yaml') {
                return 'ansible-pb';
            }
        };

        $scope.DataBaseToScriptType = function (type) {
            if (type === 'shell') {
                return 'sh';
            }
            if (type === 'ansible-pb') {
                return 'yaml';
            }
        };

        //脚本校验状态
        $scope.scriptFlag = true;
        /**
         * 脚本校验
         */
        $scope.$watch('advTaskModel.content', function (newVal, oldVal) {
            if (newVal) {
                $scope.scriptFlag = false;
            }
        }, true);

        $scope.ok = function () {
            $scope.advTaskModel.type = $scope.scriptTypeToDataBase($scope.advTaskModel.type);
            $modalInstance.close($scope.advTaskModel);
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
app.controller('taskadvlisttplController', ['$rootScope', '$scope', '$compile', '$state', '$http', '$modal', '$log',
    'msLocalStorage', '$interval', 'toaster', '$q',
    function ($rootScope, $scope, $compile, $state, $http, $modal, $log, msLocalStorage, $interval, toaster, $q) {
        $scope.listUrl = '/v1/task-tpl/project/' + msLocalStorage.get("projectId") + '/advanced-tasktpl/';
        var editBtnOpt = {
            text: '编辑',
            class: 'color-2',
            perm: "",
            color: '#004740',
            action: function () {
                var items = $scope.table_options.getCheckedItems();
                $scope.newEditAdvTaskTpl(items[0]);
            }
        };
        var deleteBtnOpt = {
            text: '删除',
            class: 'color-4',
            perm: "",
            color: '#d2181c',
            action: function (e, dt, node, config) {
                var items = $scope.table_options.getCheckedItems();
                $scope.delAdvTaskTpl(items);
            }
        };
        $scope.table_options = new msTables.Option()
            .withButtons([{
                hide: false,
                disable: false,
                text: '添加',
                class: 'color-1',
                perm: "",
                color: '#2f5398',
                action: function (button) {
                    $scope.newEditAdvTaskTpl('');
                }
            },
                editBtnOpt, deleteBtnOpt, {
                    text: '展示/隐藏',
                    extend: 'colvis',
                    perm: "",
                    class: 'color-0'
                }
            ])
            .setCheckedChangeFunc(function (items) {
                if (items.length == 1) {
                    editBtnOpt.disable = false;
                } else {
                    editBtnOpt.disable = true;
                }
                if (items.length > 0) {
                    deleteBtnOpt.disable = false;
                } else {
                    deleteBtnOpt.disable = true;
                }
            })
            .enableSearch(true)
            .withFields(
                [{
                    key: "name",
                    title: "任务名称",
                    sort_key: "name",
                    can_hide: false
                }, {
                    key: 'type',
                    title: '脚本类型',
                    sort_key: 'type'
                }, {
                    title: "操作",
                    can_hide: false,
                    class: 'ms-table-operate',
                    html: function () {
                        return '<ms-ext-btn buttons="$ctrl.tabBtn" item="$item"/>';
                    }
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                var url = $scope.listUrl + '?offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "查询高级任务列表",
                    url: url,
                }).then(function (response) {
                    var relaod = false;
                    response.data.results.forEach(function (item) {
                        if (item.job_next_run_time || item.last_exec_status == 'running') {
                            relaod = true;
                        }
                    });
                    response.data.auto_reload = relaod;
                    return response.data;
                })
            })
            .enableExternData(false, function (item) {
                // return $scope.advTaskConfigHtml(item);
            })
            .setCtrlInitFunc(function ($ctrl) {
                $ctrl.tabBtn = [
                    {
                        name: '编辑',
                        click: $scope.newEditAdvTaskTpl,
                        perm: "",
                    },
                    {
                        name: '删除',
                        click: $scope.delAdvTaskTpl,
                        perm: "",
                    }
                ];
            });

        /**
         * 新增修改高级任务模版
         * @param advTaskId
         */
        $scope.newEditAdvTaskTpl = function (advTaskId) {
            $scope.items = (advTaskId == null || advTaskId == "" ||
            typeof(advTaskId) == "undefined") ? {} : advTaskId;
            var modalInstance = $modal.open({
                templateUrl: 'advlisttplTpl',
                controller: 'advTaskTplModalCtrl',
                size: 'lg',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var method = "POST", url = $scope.listUrl;
                if (selectedItem.hasOwnProperty('id')) {
                    method = 'PUT';
                    url += selectedItem.id + '/';

                    var trigger_flag = true;
                    for (var key in selectedItem.trigger_kwargs) {
                        if (key !== 'start_date' && key !== 'end_date') {
                            if (selectedItem.trigger_kwargs[key] !== '') {
                                trigger_flag = false;
                                break;
                            }
                        }
                    }
                    if (trigger_flag) {
                        toaster.pop('error', '修改任务', '保存失败原因: 触发器至少需要添加一项');
                        return;
                    }
                }
                $http({
                    method: method,
                    err_title: "创建或修改高级任务",
                    url: url,
                    data: selectedItem
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('success', '修改高级任务', '保存成功');
                        } else {
                            toaster.pop('success', '新增高级任务', '保存成功');
                        }
                        $scope.table_options.reload();//重新渲染表格
                    } else {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('error', '修改高级任务', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        } else {
                            toaster.pop('error', '新增高级任务', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        }
                    }
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         * 删除高级任务模版
         * @param taskObj
         */
        $scope.delAdvTaskTpl = function (advTaskObj) {
            if (!(advTaskObj instanceof Array)) {
                advTaskObj = (advTaskObj == null || advTaskObj == "" ||
                typeof(advTaskObj) == "undefined") ? [] : [advTaskObj];
            }
            advTaskObj = (advTaskObj == null || advTaskObj == "" ||
            typeof(advTaskObj) == "undefined") ? [] : advTaskObj;
            $scope.items = advTaskObj;
            var modalInstance = $modal.open({
                templateUrl: 'delAdvTasktplTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var defers = [];
                angular.forEach(selectedItem, function (data, index, array) {
                    defers.push($scope.deleteAdvTaskTpl(data.id));
                });
                $q.all(defers).then(function () {
                    $scope.table_options.reload();//重新渲染表格
                });

            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
        /**
         * 删除高级任务
         * @param id
         */
        $scope.deleteAdvTaskTpl = function (id) {
            return $http({
                method: 'DELETE',
                err_title: "删除高级任务",
                url: $scope.listUrl + id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '删除高级任务', '删除成功');
                } else {
                    toaster.pop('error', '删除高级任务', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            });
        };
    }
])
;