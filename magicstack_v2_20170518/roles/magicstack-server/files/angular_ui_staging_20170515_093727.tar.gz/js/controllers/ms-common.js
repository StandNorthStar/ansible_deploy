/**
 * Created by Administrator on 2016/5/18.
 */
$.ms = {
    dtOptioni18n: {
        "sProcessing": "处理中...",
        "sLengthMenu": "显示 _MENU_ 项结果",
        "sZeroRecords": "没有匹配结果",
        "sInfo": "显示第 _START_ 至 _END_ 项结果，共 _TOTAL_ 项",
        "sInfoEmpty": "显示第 0 至 0 项结果，共 0 项",
        "sInfoFiltered": "(由 _MAX_ 项结果过滤)",
        "sInfoPostFix": "",
        "sSearch": "搜索:",
        "sUrl": "",
        "sEmptyTable": "表中数据为空",
        "sLoadingRecords": "载入中...",
        "sInfoThousands": ",",
        "oPaginate": {
            "sFirst": "首页",
            "sPrevious": "上页",
            "sNext": "下页",
            "sLast": "末页"
        },
        "oAria": {
            "sSortAscending": ": 以升序排列此列",
            "sSortDescending": ": 以降序排列此列"
        }
    },
    /**
     * 格式化HTML
     * @param source
     * @param params
     * @returns {*}
     */
    format: function (source, params) {
        if (arguments.length === 1) {
            return function () {
                var args = $.makeArray(arguments);
                args.unshift(source);
                return $.validator.format.apply(this, args);
            };
        }
        if (arguments.length > 2 && params.constructor !== Array) {
            params = $.makeArray(arguments).slice(1);
        }
        if (params.constructor !== Array) {
            params = [params];
        }
        $.each(params, function (i, n) {
            source = source.replace(new RegExp("\\{" + i + "\\}", "g"), function () {
                return n;
            });
        });
        return source;
    },
    /**
     * 获取Url地址信息
     * @param name
     * @returns {null}
     */
    getUrlParameter: function (name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        if (r != null)return unescape(r[2]);
        return null;
    },
    /**
     * 校验一个字符串是否为空，为空返回false
     * @param obj
     * @returns {boolean}
     */
    isNull: function (obj) {
        if (typeof obj == "number") {
            return true;
        } else if (obj != null && obj != "" && obj != undefined && obj.length > 0) {
            return true;
        }
        return false;
    },
    /***
     * 检查对象是否为空
     * @param obj
     * @returns {boolean}
     */
    isEmptyObject: function (obj) {
        for (var key in obj) {
            return false;
        }
        return true;
    },
    /**
     * 格式化表格数据
     * @param backData
     * @returns {*}
     */
    formatDTData: function (response) {
        if (!$.ms.isEmptyObject(response)) {
            var dtData = {};
            dtData.draw = response.draw;
            dtData.recordsTotal = response.count;
            dtData.recordsFiltered = response.count;
            dtData.data = response.results;
            return dtData;
        }
        return '';
    },
    /**
     * 执行状体转换
     * @param complyStatus
     * @returns {string}
     */
    complyStatusConversion: function (complyStatus) {
        var complyText = '未知';
        if (complyStatus == 'complete') {
            complyText = '完成';
        }
        if (complyStatus == 'failed') {
            complyText = '失败';
        }
        if (complyStatus == 'running') {
            complyText = '执行中';
        }
        if (complyStatus == '') {
            complyText = '';
        }
        return complyText;
    },
    /**
     * 任务状态code转标识
     * @param code
     * @returns {string}
     */
    taskStatusCodeToText: function (code) {
        var statusText = '无';
        if (code == '1') {
            statusText = '无';
        }
        if (code == '2') {
            statusText = '更新中';
        }
        if (code == '3') {
            statusText = '开机中';
        }
        if (code == '4') {
            statusText = '重启中';
        }
        if (code == '5') {
            statusText = '关机中';
        }
        if (code == '6') {
            statusText = '重装系统中';
        }
        return statusText;
    },
    setWindowOpen: function (newUrl, target, width, height) {
        target = (target == null || target == "" || typeof(target) == "undefined") ? '_blank' : target;
        window.open(newUrl, target, 'toolbar=no, location=no,resizable=no,copyhistory=yes, scrollbars=no,width='
            + width + ',height=' + height + '');
    },
    /***
     * 判断Datatables 选中个数、选中数据ID的集合、数据对象列表
     * @param dataObj 数据对象
     * @param selectedItems 选中集合
     * @param editBtnEle 编辑按钮
     * @param delBtnEle 删除按钮
     * @returns {Array}
     */
    judgeChecked: function (dataObj, selectedItems, editBtnEle, delBtnEle) {
        var checkedNumber = 0, checkedIdList = [], checkedDataObj = [];
        for (var id in selectedItems) {
            if (selectedItems.hasOwnProperty(id)) {
                if (selectedItems[id]) {
                    checkedNumber++;
                    checkedIdList.push(id);
                }
            }
        }
        if (checkedNumber > 0) {
            delBtnEle.removeAttr("disabled");
            if (checkedNumber === 1) {
                editBtnEle.removeAttr("disabled");
            } else {
                editBtnEle.attr({"disabled": "disabled"});
            }
        } else {
            delBtnEle.attr({"disabled": "disabled"});
            editBtnEle.attr({"disabled": "disabled"});
        }
        angular.forEach(dataObj, function (data, index, array) {
            angular.forEach(checkedIdList, function (IdData, IdIndex, IdArray) {
                if (index === IdData) {
                    checkedDataObj.push(data);
                    return;
                }
            });
        });
        return checkedDataObj;
    },
    /**
     * 初始化分页控件
     * @param CtrlID
     */
    initPageControls: function (CtrlID) {
        $.jqPaginator(CtrlID, {
            totalPages: 1,
            visiblePages: 10,
            first: '<li class="first"><a href="javascript:;">首页</a></li>',
            prev: '<li class="prev"><a href="javascript:;">上一页</a></li>',
            next: '<li class="next"><a href="javascript:;">下一页</a></li>',
            last: '<li class="last"><a href="javascript:;">末页</a></li>',
            page: '<li class="page"><a href="javascript:;">{{page}}</a></li>'
        });
    }
    ,
    /**
     * datatimepick配置项
     */
    datatimepickOption: {
        language: 'zh-CN',
        weekStart: 1,
        todayBtn: 1,
        todayHighlight: 1,
        startView: 2,
        forceParse: 0,
        showMeridian: 1,
        autoclose: true,
        minView: 2,
        format: "yyyy-mm-dd",
        pickerPosition: "bottom-left"
    }
    ,
    /**
     * ECharts 给Tooltip添加单位
     * @param option 配置参数
     * @param units 单位
     */
    echartSetTooltip: function (option, units) {
        option.tooltip['formatter'] = function (params, ticket, callback) {
            var res = params[0].name;
            for (var i = 0, l = params.length; i < l; i++) {
                res += '<br/>' + params[i].seriesName + ':' + params[i].value + units;
            }
            setTimeout(function () {
                // 仅为了模拟异步回调
                callback(ticket, res);
            }, 1);
            return 'loading';
        };
    }
    ,
    /**
     * 创建二维码方法
     * @param qrCodeID 生成二维码的容器ID
     * @param qrCodeContent 生成二维码内容
     * @param qrCodeLabel 生成二维码Label
     */
    createQRCode: function (qrCodeID, qrCodeContent, qrCodeLabel) {
        var options = {
            render: 'canvas',
            ecLevel: 'H',
            minVersion: 9,
            fill: '#333333',
            background: '#ffffff',
            text: qrCodeContent,
            size: '300',
            radius: 0.5,
            quiet: 1,
            mode: 2,
            mSize: 0.11,
            mPosX: 0.5,
            mPosY: 0.5,
            label: qrCodeLabel,
            fontname: 'Ubuntu',
            fontcolor: '#ff9818'
        };
        qrCodeID.empty().qrcode(options);
    }
    ,
    /**
     * 获取mimeType
     * @param  {String} type the old mime-type
     * @return the new mime-type
     */
    _fixType: function (type) {
        type = type.toLowerCase().replace(/jpg/i, 'jpeg');
        var r = type.match(/png|jpeg|bmp|gif/)[0];
        return 'image/' + r;
    }
    ,
    /**
     * 在本地进行文件保存
     * @param  {String} data   要保存到本地的图片数据
     * @param  {String} filename 文件名
     */
    saveFile: function (data, filename) {
        var save_link = document.createElementNS('http://www.w3.org/1999/xhtml', 'a');
        save_link.href = data;
        save_link.download = filename;

        var event = document.createEvent('MouseEvents');
        event.initMouseEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
        save_link.dispatchEvent(event);
    }
    ,
// ---------- 一些排序算法
// js 利用sort进行排序
    systemSort: function (array) {
        return array.sort(function (a, b) {
            return a - b;
        });
    }
    ,
// 冒泡排序
    bubbleSort: function (array) {
        var i = 0, len = array.length,
            j, d;
        for (; i < len; i++) {
            for (j = 0; j < len; j++) {
                if (array[i] < array[j]) {
                    d = array[j];
                    array[j] = array[i];
                    array[i] = d;
                }
            }
        }
        return array;
    }
    ,
// 快速排序
    quickSort: function (array) {
        //var array = [8,4,6,2,7,9,3,5,74,5];
        //var array = [0,1,2,44,4,324,5,65,6,6,34,4,5,6,2,43,5,6,62,43,5,1,4,51,56,76,7,7,2,1,45,4,6,7];
        var i = 0;
        var j = array.length - 1;
        var Sort = function (i, j) {
            // 结束条件
            if (i == j) {
                return
            }
            ;
            var key = array[i];
            var stepi = i; // 记录开始位置
            var stepj = j; // 记录结束位置
            while (j > i) {
                // j <<-------------- 向前查找
                if (array[j] >= key) {
                    j--;
                } else {
                    array[i] = array[j]
                    //i++ ------------>>向后查找
                    while (j > ++i) {
                        if (array[i] > key) {
                            array[j] = array[i];
                            break;
                        }
                    }
                }
            }
            // 如果第一个取出的 key 是最小的数
            if (stepi == i) {
                Sort(++i, stepj);
                return;
            }
            // 最后一个空位留给 key
            array[i] = key;
            // 递归
            Sort(stepi, i);
            Sort(j, stepj);
        };
        Sort(i, j);
        return array;
    }
    ,
// 插入排序
    insertSort: function (array) {
        var i = 1, j, step, key,
            len = array.length;

        for (; i < len; i++) {

            step = j = i;
            key = array[j];

            while (--j > -1) {
                if (array[j] > key) {
                    array[j + 1] = array[j];
                } else {
                    break;
                }
            }

            array[j + 1] = key;
        }

        return array;
    }
    ,
// 希尔排序
//Jun.array.shellSort(Jun.array.df(10000));
    shellSort: function (array) {
        var stepArr = [1750, 701, 301, 132, 57, 23, 10, 4, 1]; // reverse() 在维基上看到这个最优的步长 较小数组
        var i = 0;
        var stepArrLength = stepArr.length;
        var len = array.length;
        var len2 = parseInt(len / 2);

        for (; i < stepArrLength; i++) {
            if (stepArr[i] > len2) {
                continue;
            }

            stepSort(stepArr[i]);
        }
        // 排序一个步长
        function stepSort(step) {
            //console.log(step) 使用的步长统计
            var i = 0, j = 0, f, tem, key;
            var stepLen = len % step > 0 ? parseInt(len / step) + 1 : len / step;
            for (; i < step; i++) {// 依次循环列
                for (j = 1; /*j < stepLen && */step * j + i < len; j++) {//依次循环每列的每行
                    tem = f = step * j + i;
                    key = array[f];
                    while ((tem -= step) >= 0) {// 依次向上查找
                        if (array[tem] > key) {
                            array[tem + step] = array[tem];
                        } else {
                            break;
                        }
                    }
                    array[tem + step] = key;
                }
            }
        }

        return array;
    },
    ExecuteCmd: function (options) {
        var self = this;
        var protocol = '';
        if (window.location.protocol == 'https:') {
            protocol = 'wss://';
        } else {
            protocol = 'ws://';
        }
        var websockets = [];
        var enters = options.enters;
        self.has_run_close = false;

        function onclose() {
            if (!self.has_run_close) {
                self.has_run_close = true;
                websockets.forEach(function (ws) {
                    if (ws.connected) {
                        ws.close();
                    }
                });
                options.onclose();
            }


        }

        enters.forEach(function (item) {
            var url = protocol + item.url;
            var ws = new WebSocket(url);
            websockets.push(ws);
            ws.onmessage = options.onmessage;
            ws.onclose = onclose;

        });
        this.send = function (data) {
            websockets.forEach(function (ws) {
                ws.send(JSON.stringify(data));
            })
        }

    },
    setPermissions: function (permissions) {
        $.ms.permissions = permissions;
    },
    checkPermissions: function (permissions) {
        return true;
        function checkOnePermission(permission) {
            if (!permission) {
                return true;
            }
            if (!$.ms.permissions) {
                return false;
            }
            if (permission == 'SUPER_ACTION') {
                return window.localStorage.isSuperuser == 'true';
            }
            var pms_key = ms_permission_kv[permission];
            return !!$.ms.permissions[pms_key];
        }

        if (angular.isArray(permissions)) {
            for (var i in permissions) {
                var permission = permissions[i];
                if (checkOnePermission(permission)) {
                    return true;
                }
            }
            return false;
        }
        else {
            return checkOnePermission(permissions);
        }

    },
    getQueryString: function (name) {
        var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
        var r = window.location.search.substr(1).match(reg);
        if (r != null) {
            return unescape(r[2]);
        }
        return null;
    }
}
;