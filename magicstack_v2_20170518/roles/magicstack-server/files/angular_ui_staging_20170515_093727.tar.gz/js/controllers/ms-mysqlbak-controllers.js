/**
 * Created by lidukang on 2016/8/5.
 * 备份管理-数据库备份
 */
'use strict';
app.controller('mysqlBakModalCtrl', ['$scope', '$http', '$modalInstance',
    'msLocalStorage', '$timeout', 'toaster', 'items',
    function ($scope, $http, $modalInstance, msLocalStorage, $timeout, toaster, items) {
        $scope.cycletypeSource = [];
        if (!$.ms.isEmptyObject(items)) {
            $http({
                method: 'GET',
                err_title: "查询路径/文件",
                url: '/v1/backup/project/' + msLocalStorage.get("projectId") + '/db-backup/' + items.id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.mySqlBakModel = response.data;
                    var tempCycleTypeVal = [];
                    if ($scope.mySqlBakModel.hasOwnProperty('trigger_kwargs')) {
                        if ($scope.mySqlBakModel.trigger_kwargs.hasOwnProperty('cycle_type_val')) {
                            var tempCycletypeSource = [];
                            if ($scope.mySqlBakModel.trigger_kwargs.cycle_type == 'week') {
                                tempCycletypeSource = $scope.weekList;
                            }
                            if ($scope.mySqlBakModel.trigger_kwargs.cycle_type == 'month') {
                                tempCycletypeSource = $scope.monthList;
                            }
                            angular.forEach(tempCycletypeSource, function (weekData, weekIndex, weekArray) {
                                angular.forEach($scope.mySqlBakModel.trigger_kwargs.cycle_type_val, function (data, index, array) {
                                    if (weekData.value === data) {
                                        tempCycleTypeVal.push(weekData);
                                    }
                                });
                            });
                            $scope.mySqlBakModel.trigger_kwargs.cycle_type_val = tempCycleTypeVal;
                        }
                    }
                }
            });
        } else {
            $scope.mySqlBakModel = {
                kwargs: {db_port: 3306, ftp_port: 21},
                trigger_kwargs: {
                    trigger_cycle: 'disposable'
                }
            };
        }

        /**
         * 代理
         */
        $http({
            method: 'GET',
            err_title: "代理列表查询",
            url: '/v1/proxy-manage/project/' + msLocalStorage.get("projectId") + '/proxy/?limit=all',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.proxyItems = response.data.results;
            }
        });

        /**
         * 获取资产列表
         */
        $scope.$watch('mySqlBakModel.proxy', function (newVal, oldVal) {
            if (!$.ms.isEmptyObject(newVal)) {
                $http({
                    method: 'GET',
                    err_title: "资产列表查询",
                    url: '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/proxy/' + newVal.id + '/asset/?is_active=1&limit=all',
                    data: ''
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        $scope.assetItems = response.data.results;
                    }
                });
            }
        }, true);

        $scope.weekList = [
            {value: 1, text: '周一'},
            {value: 2, text: '周二'},
            {value: 3, text: '周三'},
            {value: 4, text: '周四'},
            {value: 5, text: '周五'},
            {value: 6, text: '周六'},
            {value: 0, text: '周日'}
        ];

        $scope.monthList = [
            {value: 1, text: '1'},
            {value: 2, text: '2'},
            {value: 3, text: '3'},
            {value: 4, text: '4'},
            {value: 5, text: '5'},
            {value: 6, text: '6'},
            {value: 7, text: '7'},
            {value: 8, text: '8'},
            {value: 9, text: '9'},
            {value: 10, text: '10'},
            {value: 11, text: '11'},
            {value: 12, text: '12'},
            {value: 13, text: '13'},
            {value: 14, text: '14'},
            {value: 15, text: '15'},
            {value: 16, text: '16'},
            {value: 17, text: '17'},
            {value: 18, text: '18'},
            {value: 19, text: '19'},
            {value: 20, text: '20'},
            {value: 21, text: '21'},
            {value: 22, text: '22'},
            {value: 23, text: '23'},
            {value: 24, text: '24'},
            {value: 25, text: '25'},
            {value: 26, text: '26'},
            {value: 27, text: '27'},
            {value: 28, text: '28'},
            {value: 29, text: '29'},
            {value: 30, text: '30'},
            {value: 31, text: '31'}
        ];

        $scope.everydayStatus = false;//每天
        $scope.weeklyStatus = false;//每周
        $scope.permonthStatus = false;//每月
        $scope.customizeStatus = false;//自定义状态

        $scope.$watch('mySqlBakModel.trigger_kwargs.trigger_cycle', function (newVal, oldVal) {
            if (newVal) {
                if (newVal === 'disposable') {
                    $scope.everydayStatus = false;//每天
                    $scope.weeklyStatus = false;//每周
                    $scope.permonthStatus = false;//每月
                    $scope.customizeStatus = false;//自定义状态
                }
                if (newVal === 'everyday') {
                    $scope.everydayStatus = true;//每天
                    $scope.weeklyStatus = false;//每周
                    $scope.permonthStatus = false;//每月
                    $scope.customizeStatus = false;//自定义状态
                }
                if (newVal === 'weekly') {
                    $scope.everydayStatus = false;//每天
                    $scope.weeklyStatus = true;//每周
                    $scope.permonthStatus = false;//每月
                    $scope.customizeStatus = false;//自定义状态
                }
                if (newVal === 'permonth') {
                    $scope.everydayStatus = false;//每天
                    $scope.weeklyStatus = false;//每周
                    $scope.permonthStatus = true;//每月
                    $scope.customizeStatus = false;//自定义状态
                }
                if (newVal === 'customize') {
                    $scope.everydayStatus = false;//每天
                    $scope.weeklyStatus = false;//每周
                    $scope.permonthStatus = false;//每月
                    $scope.customizeStatus = true;//自定义状态
                }
                if ($scope.mySqlBakModel.hasOwnProperty('trigger_kwargs')) {
                    if (!$scope.mySqlBakModel.id || oldVal) {
                        $scope.mySqlBakModel.trigger_kwargs.cycle_val = null;
                        $scope.mySqlBakModel.trigger_kwargs.trigger_hour = '';
                        $scope.mySqlBakModel.trigger_kwargs.trigger_minute = '';
                    }
                }
            }
        }, true);

        $scope.$watch('mySqlBakModel.trigger_kwargs.cycle_type', function (newVal, oldVal) {
            if (newVal) {
                if (newVal === 'week') {
                    $scope.cycletypeSource = $scope.weekList;
                }
                if (newVal === 'month') {
                    $scope.cycletypeSource = $scope.monthList;
                }
                if ($scope.mySqlBakModel.hasOwnProperty('trigger_kwargs')) {
                    if (!$scope.mySqlBakModel.id || oldVal) {
                        $scope.mySqlBakModel.trigger_kwargs.cycle_type_val = [];
                        $scope.mySqlBakModel.trigger_kwargs.trigger_hour = '';
                        $scope.mySqlBakModel.trigger_kwargs.trigger_minute = '';
                    }
                }
            }
        }, true);

        $scope.ok = function () {
            if ($scope.mySqlBakModel.trigger_kwargs.hasOwnProperty('cycle_val')) {
                if ($scope.mySqlBakModel.trigger_kwargs.cycle_val) {
                    $scope.mySqlBakModel.trigger_kwargs.cycle_val = parseInt($scope.mySqlBakModel.trigger_kwargs.cycle_val, 10);
                } else {
                    delete $scope.mySqlBakModel.trigger_kwargs.cycle_val;
                }
            }
            if ($scope.mySqlBakModel.trigger_kwargs.hasOwnProperty('cycle_type_val')) {
                var tempCycleTypeVal = [];
                angular.forEach($scope.mySqlBakModel.trigger_kwargs.cycle_type_val, function (data, index, array) {
                    tempCycleTypeVal.push(data.value);
                });
                $scope.mySqlBakModel.trigger_kwargs.cycle_type_val = tempCycleTypeVal;
            }
            $modalInstance.close($scope.mySqlBakModel);
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
app.controller('mysqlbakController', ['$rootScope', '$scope', '$state', '$http', '$modal', '$q', '$log', 'msLocalStorage', '$interval', 'toaster',
    function ($rootScope, $scope, $state, $http, $modal, $q, $log, msLocalStorage, $interval, toaster) {
        $scope.listUrl = '/v1/backup/project/' + msLocalStorage.get("projectId") + '/db-backup/';
        var editBtnOpt = {
            text: '编辑',
            class: 'color-2',
            perm: "BACKUP_DATABASE_EDIT_ACTION",
            color: '#004740',
            action: function () {
                var items = $scope.table_options.getCheckedItems();
                $scope.newEditMySqlBak(items[0]);
            }
        };
        var deleteBtnOpt = {
            text: '删除',
            class: 'color-4',
            perm: "BACKUP_DATABASE_DELETE_ACTION",
            color: '#d2181c',
            action: function (e, dt, node, config) {
                var items = $scope.table_options.getCheckedItems();
                $scope.delMySqlBak(items);
            }
        };
        $scope.table_options = new msTables.Option()
            .withButtons([{
                hide: false,
                disable: false,
                text: '添加',
                class: 'color-1',
                perm: "BACKUP_DATABASE_CREATE_ACTION",
                color: '#2f5398',
                action: function (button) {
                    $scope.newEditMySqlBak('');
                }
            },
                editBtnOpt, deleteBtnOpt, {
                    text: '展示/隐藏',
                    extend: 'colvis',
                    perm: "",
                    class: 'color-0'
                }
            ])
            .setCheckedChangeFunc(function (items) {
                if (items.length == 1) {
                    editBtnOpt.disable = false;
                } else {
                    editBtnOpt.disable = true;
                }
                if (items.length > 0) {
                    deleteBtnOpt.disable = false;
                } else {
                    deleteBtnOpt.disable = true;
                }
            })
            .enableSearch(true)
            .withFields(
                [{
                    key: "name",
                    title: "任务名称",
                    sort_key: "name",
                    can_hide: false
                }, {
                    key: 'proxy__proxy_name',
                    title: "代理名称",
                    sort_key: "proxy__proxy_name"
                }, {
                    title: "任务状态",
                    sort_key: "approve_status,status",
                    html: function (item) {
                        var statusText = '';
                        if (item.approve_status == 0) {
                            if (item.status == 1) {
                                statusText = '启用';
                            } else if (item.status == 0) {
                                statusText = '禁用';
                            }
                        }
                        else if (item.approve_status == 1) {
                            statusText = '审批中';
                        }
                        else if (item.approve_status == 2) {
                            statusText = '审批拒绝';
                        }
                        return statusText;
                    }
                }, {
                    key: 'last_exec_time',
                    title: "最后执行时间",
                    sort_key: "last_exec_time"
                }, {
                    key: 'last_exec_status',
                    title: "执行状态",
                    sort_key: "last_exec_status"
                }, {
                    key: 'comment',
                    title: "备注",
                    sort_key: "comment"
                }, {
                    title: "操作",
                    can_hide: false,
                    class: 'ms-table-operate',
                    html: function () {
                        return '<ms-ext-btn buttons="$ctrl.tabBtn" item="$item"/>';
                    }
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                var url = $scope.listUrl + '?offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "数据库备份列表查询",
                    url: url,
                }).then(function (response) {
                    return response.data;
                })
            })
            .enableExternData(true, function (item) {
                return $scope.dbConfigHtml(item);
            })
            .setCtrlInitFunc(function ($ctrl) {
                $ctrl.tabBtn = [
                    {
                        name: '查看明细',
                        click: $scope.mySqlExecDetails,
                        perm: "ASSET_IDC_DETAIL_ACTION",
                    },
                    {
                        name: '编辑',
                        click: $scope.newEditMySqlBak,
                        perm: "BACKUP_DATABASE_EDIT_ACTION",
                    },
                    {
                        name: '删除',
                        click: $scope.delMySqlBak,
                        perm: "BACKUP_DATABASE_DELETE_ACTION",
                    }
                ];
            });

        $scope.dbConfigHtml = function (data, type, full, meta) {
            var dd = '';
            if (data.trigger_kwargs.hasOwnProperty('start_datetime')) {
                dd += '<dd>开始时间:' + data.trigger_kwargs.start_datetime + '</dd>';
            }
            if (data.trigger_kwargs.hasOwnProperty('end_datetime')) {
                dd += '<dd>结束时间:' + data.trigger_kwargs.end_datetime + '</dd>';
            }
            if (data.trigger_kwargs.hasOwnProperty('trigger_cycle')) {
                dd += '<dd>重复周期:' + data.trigger_kwargs.trigger_cycle + '</dd>';
                if (data.trigger_kwargs.hasOwnProperty('cycle_val')) {
                    if (data.trigger_kwargs.trigger_cycle == 'weekly') {
                        dd += '<dd>周:' + data.trigger_kwargs.cycle_val + '</dd>';
                    }
                    if (data.trigger_kwargs.trigger_cycle == 'permonth') {
                        dd += '<dd>日:' + data.trigger_kwargs.cycle_val + '</dd>';
                    }
                }
            }
            if (data.trigger_kwargs.hasOwnProperty('trigger_hour')) {
                dd += '<dd>时:' + data.trigger_kwargs.trigger_hour + '</dd>';
            }
            if (data.trigger_kwargs.hasOwnProperty('trigger_minute')) {
                dd += '<dd>分:' + data.trigger_kwargs.trigger_minute + '</dd>';
            }
            return '<dl class="user-project"><dt>任务配置:</dt>' + dd + '</dl>';
        };

        /**
         * 新增、编辑mySql备份
         * @param mySqlBakId
         */
        $scope.newEditMySqlBak = function (mySqlBakId) {
            $scope.items = (mySqlBakId == null || mySqlBakId == "" ||
            typeof(mySqlBakId) == "undefined") ? {} : mySqlBakId;
            var modalInstance = $modal.open({
                templateUrl: 'newEditMySqlTpl',
                controller: 'mysqlBakModalCtrl',
                size: 'lg',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var method = "POST", url = $scope.listUrl;
                if (selectedItem.hasOwnProperty('id')) {
                    method = 'PUT';
                    url += selectedItem.id + '/';
                }
                $http({
                    method: method,
                    err_title: "创建或修改mySql备份",
                    url: url,
                    data: selectedItem
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('success', '修改mySql备份', '保存成功');
                        } else {
                            toaster.pop('success', '新增mySql备份', '保存成功');
                        }
                        $scope.table_options.reload();//重新渲染表格
                    } else {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('error', '修改mySql备份', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        } else {
                            toaster.pop('error', '新增mySql备份', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        }
                    }
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         * 删除mySql备份
         * @param mySqlBakObj
         */
        $scope.delMySqlBak = function (mySqlBakObj) {
            if (!(mySqlBakObj instanceof Array)) {
                mySqlBakObj = (mySqlBakObj == null || mySqlBakObj == "" ||
                typeof(mySqlBakObj) == "undefined") ? [] : [mySqlBakObj];
            }
            mySqlBakObj = (mySqlBakObj == null || mySqlBakObj == "" ||
            typeof(mySqlBakObj) == "undefined") ? [] : mySqlBakObj;
            $scope.items = mySqlBakObj;
            var modalInstance = $modal.open({
                templateUrl: 'delMySqlBakTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var defered_array = [];
                angular.forEach(selectedItem, function (data, index, array) {
                    defered_array.push($scope.deleteMySqlBak(data.id));
                });
                $q.all(defered_array).then(function() {
                    $scope.table_options.reload();//重新渲染表格
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
        /**
         * 删除mySql备份
         * @param id
         */
        $scope.deleteMySqlBak = function (id) {
            var defer = $q.defer();
            $http({
                method: 'DELETE',
                err_title: "删除mySql备份",
                url: $scope.listUrl + id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '删除mySql备份', '删除成功');
                } else {
                    toaster.pop('error', '删除mySql备份', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
                defer.resolve();
            }, function errorCallback(response) {
                defer.resolve();
            });
            return defer.promise;
        };

        $scope.mySqlExecDetails = function (pathFileObj) {
            $scope.items = (pathFileObj == null || pathFileObj == "" ||
            typeof(pathFileObj) == "undefined") ? {} : pathFileObj;
            var modalInstance = $modal.open({
                templateUrl: 'mySqlExecDetailsTpl',
                controller: 'dbBakExecModalCtrl',
                size: 'lg',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                $scope.selected = selectedItem;
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
    }
]);
app.controller('dbBakExecModalCtrl', ['$rootScope', '$scope', '$modal', '$http', '$modalInstance',
    'msLocalStorage', '$timeout', 'toaster', 'items','msPlayback',
    function ($rootScope, $scope, $modal, $http, $modalInstance, msLocalStorage, $timeout, toaster, items, msPlayback) {
        $scope.dbBakExecPagination = {
            dbBakExecMaxSize: 5,
            dbBakExecTotalItems: 0,
            dbBakExecCurrentPage: 1
        };
        $scope.dbBakExecTableModal = {};
        $scope.selectDBBakExec = function (offset) {
            var url = '/v1/backup/project/' + msLocalStorage.get("projectId") + '/db-backup/' + items.id + '/execinfo/';
            if (offset !== 0) {
                offset = offset + '0';
            }
            url += '?offset=' + offset + '&limit=10';
            $http({
                method: 'GET',
                err_title: "数据库执行明细表查询",
                url: url,
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.dbBakExecPagination.dbBakExecTotalItems = response.data.count;
                    $scope.dbBakExecTableModal = response.data.results;
                }
                else {
                    toaster.pop('error', '数据库执行明细表查询错误', response.data.message, $rootScope.errorDwellTime);
                }
            });
        };

        $scope.$watch('dbBakExecPagination.dbBakExecCurrentPage', function (newVal, oldVal) {
            if (!$.ms.isEmptyObject(items)) {
                if (newVal && newVal > -1) {
                    $scope.dbBakExecPagination.dbBakExecCurrentPage = newVal;
                    $scope.selectDBBakExec((newVal - 1));
                }
            }
        }, true);

        $scope.replay = function (obj) {
            obj = angular.copy(obj);
            obj.task_id = items.id;
            $modalInstance.close($scope.items);
            $http({
                method: 'GET',
                err_title: "获取回放信息",
                url: '/v1/backup/project/' + msLocalStorage.get("projectId") + '/db-backup/' + obj.task_id + '/replay/' + obj.id,

            }).then(function successCallback(response) {
                msPlayback({data: response.data});
            });

        };

        $scope.download = function (path) {
            $http({
                method: 'POST',
                err_title: "获取下载地址",
                url: '/v1/backup/project/' + msLocalStorage.get("projectId") + '/db-backup/' + items.id + "/download/",
                data: {file_path: path}
            }).then(function successCallback(response) {
                window.open(response.data.link, '_self', 'toolbar=no, location=no,resizable=no,copyhistory=yes, scrollbars=no');
            });

        };

        $scope.ok = function () {
            $modalInstance.close($scope.items);
        };

        $scope.clear = function () {
            $scope.items = {};
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
