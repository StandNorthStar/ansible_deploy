/**
 * Created by lidukang on 2016/11/2.
 * 授权认证、授权登陆
 */
'use strict';
app.controller('authApproveCtrl', ['$scope', 'msLoginSsoAuth', '$stateParams', function ($scope, msLoginSsoAuth, $stateParams) {
    $scope.authApproveModule = {
        email: decodeURIComponent($stateParams.email),
        username: decodeURIComponent($stateParams.username),
        action: "setpass",
        token: decodeURIComponent($stateParams.token)
    };

    $scope.login = function () {
        msLoginSsoAuth('/v1/sso/sso_auth/', 'POST', $scope.authApproveModule, '授权认证登录错误');
    }
}]);

app.controller('authLoginCtrl', ['msLoginSsoAuth', '$stateParams', function (msLoginSsoAuth, $stateParams) {
    msLoginSsoAuth('/v1/sso/sso_auth/', 'POST',
        {token: decodeURIComponent($stateParams.token), action: "login"}, '授权认证登录错误');
}]);
app.controller('ssoCtrl', ['msLoginSsoAuth', '$state', '$http', function (msLoginSsoAuth, $state, $http) {

    $http({
        method: 'POST',
        url: '/v1/sso/openstack/',
        data: {token: $.ms.getUrlParameter('token')}
    }).then(function successCallback(response) {
        if (response.data.action == 'login') {
            $state.go("auth.login", {
                token: response.data.token
            })
        }
        else if (response.data.action == 'setpass') {
            $state.go("auth.approve", {
                email: response.data.email,
                username: response.data.username,
                token: response.data.token
            })
        }
    });
}]);
/**
 * License 认证
 */
app.controller('licenseAuthCtrl', ['$rootScope', '$scope', '$http', '$location', 'toaster', function ($rootScope, $scope, $http, $location, toaster) {
    $scope.licenseAuthModule = {
        licenseKey: ''
    };

    //查询机器码
    $http({
        method: 'GET',
        url: '/v1/license-manage/machine/code/',
        data: ''
    }).then(function successCallback(response) {
        console.log(response);
        $scope.machineCode = response.data.machine_code;
    });

    /**
     * 认证
     */
    $scope.licenseAuth = function () {
        $http({
            method: 'POST',
            url: '/v1/license-manage/license/verify/',
            data: $scope.licenseAuthModule
        }).then(function successCallback(response) {
            $location.replace().path("/access/index");
        });
    }
}]);