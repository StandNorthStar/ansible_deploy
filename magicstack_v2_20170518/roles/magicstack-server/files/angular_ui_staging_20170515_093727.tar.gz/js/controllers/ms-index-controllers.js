/**
 * Created by lidukang on 2016/8/16.
 * 首页
 */
'use strict';
app.controller('signinForgotCtrl', ['$scope', '$modalInstance', function ($scope, $modalInstance) {
    $scope.items = {
        title: '登录',
        signinFlag: true,
        forgotFlag: false,
        "username": "",
        "password": ""
    };
    $scope.loginSrc = '';
    $scope.forgotSrc = '';

    $scope.loginSrcBtn = function () {
        $scope.loginSrc = '/v1/permissions/image_code?key=login&' + Math.random()
    };

    $scope.loginFocus = function () {
        if (!$scope.loginSrc) {
            $scope.loginSrcBtn();
        }
    };

    $scope.forgotSrcBtn = function () {
        $scope.forgotSrc = '/v1/permissions/image_code?key=login&' + Math.random()
    };

    $scope.forgotFocus = function () {
        if (!$scope.forgotSrc) {
            $scope.forgotSrcBtn();
        }
    };

    $scope.toggleSignin = function () {
        $scope.items.signinFlag = false;
        $scope.items.forgotFlag = true;
        $scope.items.title = "忘记密码";
    };
    $scope.toggleForgot = function () {
        $scope.items.signinFlag = true;
        $scope.items.forgotFlag = false;
        $scope.items.title = "登录";
    };

    $scope.login = function () {
        $modalInstance.close({
            signinFlag: $scope.items.signinFlag,
            forgotFlag: $scope.items.forgotFlag,
            username: $scope.items.username,
            password: $scope.items.password,
            code: $scope.items.loginCode
        });
    };

    $scope.LoginKeyPress = function (event) {
        if (event.charCode === 13) {
            $scope.login();
        }
    };

    $scope.forgot = function () {
        $modalInstance.close({
            signinFlag: $scope.items.signinFlag,
            forgotFlag: $scope.items.forgotFlag,
            email: $scope.items.email,
            code: $scope.items.forgotCode
        });
    };

    $scope.forgotKeyPress = function (event) {
        if (event.charCode === 13) {
            $scope.forgot();
        }
    };
    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
}]);
app.controller('indexCtrl', ['$scope','$state', '$modal', '$log', 'msLoginSsoAuth','isVerify', function ($scope,$state, $modal, $log, msLoginSsoAuth,isVerify) {
    if(!isVerify){
        $state.go('auth.license');
    }
    $scope.signinOpen = function () {
        var modalInstance = $modal.open({
            templateUrl: 'signintpl',
            controller: 'signinForgotCtrl',
            size: 'signin',
            resolve: {
                items: function () {
                    return $scope.items;
                }
            }
        });

        modalInstance.result.then(function (selectedItem) {
            if (selectedItem.signinFlag) {
                msLoginSsoAuth('/v1/permissions/login', 'POST', {
                    username: selectedItem.username,
                    password: selectedItem.password,
                    code: "!qwe"
                }, '登录错误');
            }
        }, function () {
            $log.info('关闭时间: ' + new Date());
        });
    };
}]);

