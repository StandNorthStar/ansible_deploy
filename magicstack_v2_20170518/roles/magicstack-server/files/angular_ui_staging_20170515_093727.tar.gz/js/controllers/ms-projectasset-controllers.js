/**
 * Created by lidukang on 2016/8/5.
 * 资产管理-查看资产组
 */
'use strict';
/***
 * 模态框控制器
 */
app.controller('assetModalCtrl', ['$rootScope', '$scope', '$http', '$modalInstance', 'msLocalStorage', 'toaster', 'items', 'values',
    function ($rootScope, $scope, $http, $modalInstance, msLocalStorage, toaster, items, values) {
        $scope.nameEditable = false;
        $scope.proxyEditable = false;
        $scope.delNetWorkDisabled = true;
        $scope.positionArray = [];
        /*
         <option value="1">drac5</option>
         <option value="2">idrac</option>
         <option value="3">ilo</option>
         <option value="4">ilo2</option>
         <option value="5">ilo3</option>
         <option value="6">ilo4</option>
         <option value="7">intelmodular</option>
         <option value="8">ipmilan</option>
         */
        $scope.powerTypes = [
            {"key": 1, "value": "drac5"},
            {"key": 2, "value": "idrac"},
            {"key": 3, "value": "ilo"},
            {"key": 4, "value": "ilo2"},
            {"key": 5, "value": "ilo3"},
            {"key": 6, "value": "ilo4"},
            {"key": 7, "value": "intelmodular"},
            {"key": 8, "value": "ipmilan"},
        ]
        for (var i = 1; i <= 42; i++) {
            $scope.positionArray.push(i);
        }
        $scope.deviceModelArray = ['1u', '2u', '4u', '8u', '10u'];

        if (!$.ms.isEmptyObject(items)) {
            $scope.nameEditable = true;
            $scope.proxyEditable = true;

            $http({
                method: 'GET',
                err_title: "查询我的资产",
                url: '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/asset/' + items.id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.assetModel = response.data;
                    $scope.assetModel.machine_status = $scope.assetModel.machine_status.toString();
                    if ($scope.assetModel.networking.length > 0) {
                        angular.forEach($scope.assetModel.networking, function (item) {
                                if (item.default == true) {
                                    $scope.assetModel.netWork = item;
                                }
                            }
                        );
                    }
                }
            });
        } else {
            $scope.assetModel = {
                networking: [],
                networking_g: {},
                power_manage: {
                    power_type: 8
                },
                port: 22,
                netboot_enabled: false,
                is_active: true,
                deployment_enable: true
            };
            if (values) {
                angular.extend($scope.assetModel, values);
            }

        }

        $scope.netWorkModel = {
            static: true
        };

        /**
         * 查询proxy(代理)
         */
        $http({
            method: 'GET',
            err_title: "代理列表查询",
            url: '/v1/proxy-manage/project/' + msLocalStorage.get("projectId") + '/proxy/?limit=all&ordering=proxy_name',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.proxyItems = response.data.results;
            }
        });
        $scope.cabinetColumnItems = [];
        $scope.cabinetRowItems = [];
        /**
         * 级联查询profile(配置文件)
         */
        $scope.$watch('assetModel.proxy', function (newVal, oldVal) {
            $scope.profileItems = [];
            if (!$.ms.isEmptyObject(newVal)) {
                $http({
                    method: 'GET',
                    err_title: "配置文件列表查询",
                    url: '/v1/asset-manage/proxy/' + newVal.id + '/profile/?limit=all',
                    data: ''
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        $scope.profileItems = response.data.results;
                    }
                });

                $http({
                    method: 'GET',
                    err_title: "IDC信息查询",
                    url: '/v1/asset-manage/proxy/' + newVal.id + '/idc/?limit=all',
                    data: ''
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        var cabinet_column = response.data.results.cabinet_column,
                            cabinet_row = response.data.results.cabinet_row;
                        if (cabinet_column) {
                            for (var c = 1; c <= cabinet_column; c++) {
                                $scope.cabinetColumnItems.push(c);
                            }
                        }
                        if (cabinet_row) {
                            for (var r = 1; r <= cabinet_row; r++) {
                                $scope.cabinetRowItems.push(r);
                            }
                        }
                    }
                });
            }
        });

        $scope.$watch('assetModel.networking', function (newVal, oldVal) {
            if (!$.ms.isEmptyObject(newVal)) {
                $scope.delNetWorkDisabled = false;
            } else {
                $scope.delNetWorkDisabled = true;
            }
        }, true);

        $scope.$watch('assetModel.netWork', function (newVal, oldVal) {
            if (!$.ms.isEmptyObject(newVal)) {
                $scope.netWorkModel = newVal;
                $scope.delNetWorkDisabled = false;
            } else {
                $scope.netWorkModel = {};
            }
        }, true);

        $scope.clearNetWork = function () {
            $scope.netWorkModel = {};
        };

        $scope.addNetWork = function () {
            if ($scope.assetModel.networking.length > 0) {
                angular.forEach($scope.assetModel.networking, function (data, index, array) {
                    if (data.ip_address == $scope.assetModel.networking.ip_address &&
                        data.mac_address == $scope.assetModel.networking.mac_address) {
                        $scope.assetModel.networking.splice(index, 1);
                    }
                });
            }
            $scope.netWorkModel.default = false;
            $scope.assetModel.networking.push($scope.netWorkModel);
            $scope.netWorkModel = {};
            $scope.assetModel.netWork = '';
        };

        $scope.delNetWork = function (net) {
            console.log("net", net);
            if ($scope.assetModel.networking.length > 0) {
                angular.forEach($scope.assetModel.networking, function (data, index, array) {
                    console.log("data", data);
                    if (data === net) {
                        console.log("find");
                        $scope.assetModel.networking.splice(index, 1);
                    }
                });
            }
            $scope.netWorkModel = {};
            $scope.assetModel.netWork = '';
        };

        $scope.ok = function () {
            delete $scope.assetModel.netWork;
            $scope.assetModel.netboot_enabled = false;
            $modalInstance.close($scope.assetModel);
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
app.controller('assetChangeModalCtrl', ['$rootScope', '$scope', '$http', '$modalInstance',
    'msLocalStorage', 'toaster', 'items',
    function ($rootScope, $scope, $http, $modalInstance, msLocalStorage, toaster, items) {
        $scope.items = items;
        $scope.assetChangeModule = {};

        /**
         * 查询项目列表
         */
        $http({
            method: 'GET',
            err_title: "项目列表查询",
            url: '/v1/permissions/proxy/' + $scope.items.proxy.id + '/project/?limit=all&ordering=proxy_name',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.projectItems = response.data.results;
            }
        });

        $scope.ok = function () {
            $modalInstance.close({
                assetId: $scope.items.id,
                new_project_id: $scope.assetChangeModule.project,
                old_project_id: $scope.items.project.id
            });
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
/**
 * 链接多用户
 */
app.controller('linkUsersModalCtrl', ['$scope', '$modalInstance', 'options', function ($scope, $modalInstance, options) {
    $scope.options = options;

    $scope.selectUser = function (role) {
        var url = "web_terminal.html?" + "project_id=" + options.project_id + "&asset_id=" + options.asset_id + "&role_id=" + role.id;
        $.ms.setWindowOpen(url, '_blank', 1174, 476);
        $modalInstance.close($scope.options);
    };

    $scope.ok = function () {
        $modalInstance.close($scope.options);
    };

    $scope.clear = function () {
        $scope.items = {};
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
}]);

app.filter('powerType', function () {
    return function (item) {
        if (item == 1) {
            return 'drac5';
        } else if (item == 2) {
            return 'idrac';
        } else if (item == 3) {
            return 'ilo';
        } else if (item == 4) {
            return 'ilo2';
        } else if (item == 5) {
            return 'ilo3';
        } else if (item == 6) {
            return 'ilo4';
        } else if (item == 7) {
            return 'intelmodular';
        } else if (item == 8) {
            return 'ipmilan';
        }
    }
});

app.controller('assetDetailsModalCtrl', ['$rootScope', '$scope', '$modal', '$http', '$modalInstance',
    'msLocalStorage', '$timeout', 'toaster', 'items',
    function ($rootScope, $scope, $modal, $http, $modalInstance,
              msLocalStorage, $timeout, toaster, items) {
        /******************************************************主机详细信息Begin*****************************************************/
        $http({
            method: 'GET',
            err_title: "授权用户信息",
            url: '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/asset/' + items.id + '/',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.assetDetailsModal = response.data;
            }
            else {
                toaster.pop('error', '授权用户信息查询', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
            }
        });
        /******************************************************主机详细信息End*****************************************************/

        /******************************************************授权信息Begin*****************************************************/
        $scope.authInfoPagination = {
            authInfoMaxSize: 5,
            authInfoTotalItems: 0,
            authInfoCurrentPage: 1
        };
        $scope.authInfoTableModal = {};
        $scope.selectAuthInfo = function (offset) {
            var url = '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/asset/' + items.id + '/rules/';
            if (offset !== 0) {
                offset = offset + '0';
            }
            url += '?offset=' + offset + '&limit=10';
            $http({
                method: 'GET',
                err_title: "授权用户信息",
                url: url,
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.authInfoPagination.authInfoTotalItems = response.data.count;
                    $scope.authInfoTableModal = response.data.results;
                }
                else {
                    toaster.pop('error', '授权用户信息查询', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            });
        };

        $scope.$watch('authInfoPagination.authInfoCurrentPage', function (newVal, oldVal) {
            if (!$.ms.isEmptyObject(items)) {
                if (newVal && newVal > -1) {
                    $scope.authInfoPagination.authInfoCurrentPage = newVal;
                    $scope.selectAuthInfo((newVal - 1));
                }
            }
        }, true);
        /******************************************************授权信息End*****************************************************/

        /******************************************************主机修改记录Begin*****************************************************/
        $scope.alertRecordPagination = {
            alertRecordMaxSize: 5,
            alertRecordTotalItems: 0,
            alertRecordCurrentPage: 1
        };
        $scope.alertRecordTableModal = {};
        $scope.selectAlertRecord = function (offset) {
            var url = '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/asset/' + items.id + '/alert/record/';
            if (offset !== 0) {
                offset = offset + '0';
            }
            url += '?offset=' + offset + '&limit=10';
            $http({
                method: 'GET',
                err_title: "主机修改记录查询",
                url: url,
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.alertRecordPagination.alertRecordTotalItems = response.data.count;
                    $scope.alertRecordTableModal = response.data.results;
                }
                else {
                    toaster.pop('error', '主机修改记录查询', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            });
        };

        $scope.$watch('alertRecordPagination.alertRecordCurrentPage', function (newVal, oldVal) {
            if (!$.ms.isEmptyObject(items)) {
                if (newVal && newVal > -1) {
                    $scope.alertRecordPagination.alertRecordCurrentPage = newVal;
                    $scope.selectAlertRecord((newVal - 1));
                }
            }
        }, true);

        /******************************************************主机修改记录End*****************************************************/

        /******************************************************用户登录主机记录Begin*****************************************************/
        $scope.connectRecordPagination = {
            connectRecordMaxSize: 5,
            connectRecordTotalItems: 0,
            connectRecordCurrentPage: 1
        };
        $scope.connectRecordTableModal = {};
        $scope.selectConnectRecord = function (offset) {
            var url = '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/asset/' + items.id + '/connect/record/';
            if (offset !== 0) {
                offset = offset + '0';
            }
            url += '?offset=' + offset + '&limit=10';
            $http({
                method: 'GET',
                url: url,
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.connectRecordPagination.connectRecordTotalItems = response.data.count;
                    $scope.connectRecordTableModal = response.data.results;
                }
                else {
                    toaster.pop('error', '-查询', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            }, function errorCallback(response) {
                toaster.pop('error', '授权用户信息查询', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
            });
        };

        $scope.$watch('connectRecordPagination.connectRecordCurrentPage', function (newVal, oldVal) {
            if (!$.ms.isEmptyObject(items)) {
                if (newVal && newVal > -1) {
                    $scope.connectRecordPagination.connectRecordCurrentPage = newVal;
                    $scope.selectConnectRecord((newVal - 1));
                }
            }
        }, true);
        /******************************************************用户登录主机记录End*****************************************************/

        $scope.items = items;

        $scope.ok = function () {
            $modalInstance.close($scope.items);
        };

        $scope.clear = function () {
            $scope.items = {};
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
app.controller('assetController', ['$rootScope', '$scope', '$compile', '$state', '$http', '$modal', '$log', '$q', '$location', 'msLocalStorage', '$interval', 'toaster',
    function ($rootScope, $scope, $compile, $state, $http, $modal, $log, $q, $location, msLocalStorage, $interval, toaster) {
        $scope.topBtns = [
            {
                name: "批量执行", css_class: "btn-primary",
                perm: "ASSET_BATCH_EXEC_ACTION",
                action: function (button) {
                    var modalInstance = $modal.open({
                        templateUrl: 'assetBatchExecutionTpl',
                        controller: 'assetBatchExecModalCtrl',
                        size: 'batch-exec'
                    });

                    modalInstance.result.then(function (selectedItem) {
                        $scope.selected = selectedItem;
                    }, function () {
                        $log.info('关闭时间: ' + new Date());
                    });
                }
            },
            {
                name: "批量导入", css_class: "btn-success",
                perm: "",
                action: function (button) {
                    $state.go('app.batchupload');
                }
            },
            {
                name: "导出", css_class: "btn-info",
                perm: "",
                action: function (button) {
                    var items = {};
                    var modalInstance = $modal.open({
                        templateUrl: 'exportAssetTpl',
                        controller: 'ModalInstanceCtrl',
                        resolve: {
                            items: function () {
                                return items;
                            }
                        }
                    });

                    modalInstance.result.then(function (selectedItem) {
                        window.open('/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/asset-export/?type=' + selectedItem.exportType,
                            '_self', 'toolbar=no, location=no,resizable=no,copyhistory=yes, scrollbars=no');
                    }, function () {
                        $log.info('关闭时间: ' + new Date());
                    });
                }
            },
            {
                name: "主机探测", css_class: "btn-danger",
                perm: "",
                action: function (button) {
                    $state.go('app.hostdetection');
                }
            }
        ]
        $scope.listUrl = '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/asset/';

        var monitorBtnOpt = {
            text: '监控',
            class: 'color-2',
            action: function () {
                var items = $scope.table_options.getCheckedItems();
                $scope.monitorAsset(items);
            },
            perm: "ASSET_REBUILD_ACTION",
        };
        var updateBtnOpt = {
            name: '更新',
            click: function () {
                var items = $scope.table_options.getCheckedItems();
                $scope.assetBatchUpdate(items);
            },
            perm: "ASSET_UPDATE_ACTION",
        };
        var powerOnBtnOpt = {
            name: '开机',
            click: function () {
                var items = $scope.table_options.getCheckedItems();
                $scope.assetActionBatch(items, "on");
            },
            perm: "ASSET_POWER_ACTION",
        };
        var powerOffBtnOpt = {
            name: '关机',
            click: function () {
                var items = $scope.table_options.getCheckedItems();
                $scope.assetActionBatch(items, "off");
            },
            perm: "ASSET_SHUTDOWN_ACTION",
        };
        var rebootBtnOpt = {
            name: '重启',
            click: function () {
                var items = $scope.table_options.getCheckedItems();
                $scope.assetActionBatch(items, "reboot");
            },
            perm: "ASSET_REBOOT_ACTION",
        };

        var rebuildBtnOpt = {
            name: '重装系统',
            click: function () {
                var items = $scope.table_options.getCheckedItems();
                $scope.assetActionBatch(items, "rebuild");
            },
            perm: "ASSET_REBUILD_ACTION",
        };

        var deleteBtnOpt = {
            text: '删除',
            class: 'color-4',
            perm: "ASSET_DELETE_ACTION",
            color: '#d2181c',
            action: function (e, dt, node, config) {
                var items = $scope.table_options.getCheckedItems();
                $scope.delAsset(items);
            }
        };
        $scope.table_options = new msTables.Option()
            .withButtons([
                {
                    hide: false,
                    disable: false,
                    text: '添加',
                    perm: "ASSET_CREATE_ACTION",
                    class: 'color-1',
                    color: '#2f5398',
                    action: function (button) {
                        $scope.newEditAsset('');
                    }
                },
                deleteBtnOpt,
                monitorBtnOpt,
                {
                    extend: 'more',
                    btns: [updateBtnOpt, powerOnBtnOpt, powerOffBtnOpt, rebootBtnOpt, rebuildBtnOpt
                    ]
                },
                {
                    text: '展示/隐藏',
                    perm: "",
                    extend: 'colvis',
                    class: 'color-0'
                }
            ])
            .setCheckedChangeFunc(function (items) {
                if (items.length > 0) {
                    deleteBtnOpt.disable = false;
                    monitorBtnOpt.disable = false;
                } else {
                    deleteBtnOpt.disable = true;
                    monitorBtnOpt.disable = true;
                }
                if (items.length > 0) {
                    updateBtnOpt.hide = false;
                    powerOnBtnOpt.hide = false;
                    powerOffBtnOpt.hide = false;
                    rebootBtnOpt.hide = false;
                    rebuildBtnOpt.hide = false;
                } else {
                    updateBtnOpt.hide = true;
                    powerOnBtnOpt.hide = true;
                    powerOffBtnOpt.hide = true;
                    rebootBtnOpt.hide = true;
                    rebuildBtnOpt.hide = true;
                }
            })
            .enableSearch(true)
            .withFields(
                [{
                    title: "资产名称",
                    sort_key: "name",
                    can_hide: false,
                    html: function (item) {
                        // $scope.monitorAsset(item);
                        return '<a class="btn btn-link" style="text-decoration:underline;color: blue" ng-click="$ctrl.monitorAsset($item)" ng-bind="$item.name"></a>';
                    }
                }, {
                    key: 'ip',
                    title: "IP地址",
                    sort_key: "ip"
                }, {
                    key: 'proxy__proxy_name',
                    title: "所属代理",
                    sort_key: "proxy"
                }, {
                    key: 'system_type',
                    title: "操作系统",
                    sort_key: "system_type"
                }, {
                    title: "禁用/启用",
                    sort_key: "is_active",
                    html: function (item) {
                        var is_active = item.is_active;
                        if (is_active) {
                            return '启用';
                        }
                        else {
                            return '禁用';
                        }
                    }
                },
                    // {
                    //     title: "资产状态",
                    //     sort_key: "asset_status",
                    //     html: function (item) {
                    //         var code = item.asset_status;
                    //         if (code == '1') {
                    //             return '运行中';
                    //         }
                    //         if (code == '2') {
                    //             return '关机';
                    //         }
                    //     }
                    // },
                    {
                    title: "连接状态",
                    sort_key: "online",
                    html: function (item) {
                        if (item.online) {
                            return '在线';
                        }
                        else {
                            return '离线';
                        }
                    }
                }, {

                    title: "任务状态",
                    sort_key: "task_status",
                    html: function (item) {
                        if (item.task_status == 1) {
                            return "无";
                        }
                        else if (item.task_status == 2) {
                            return "更新中";
                        }
                        else if (item.task_status == 3) {
                            return "开机中";
                        }
                        else if (item.task_status == 4) {
                            return "重启中";
                        }
                        else if (item.task_status == 5) {
                            return "关机中";
                        }
                        else if (item.task_status == 6) {
                            return "重装系统中";
                        }
                    }
                }, {
                    title: "操作",
                    can_hide: false,
                    class: 'ms-table-operate',
                    html: function () {
                        return '<ms-ext-btn buttons="$ctrl.tabBtn" item="$item"/>';
                    }
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                var url = $scope.listUrl + '?offset=' + offset + '&limit=' + limit+ '&asset_type=1';
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "资产列表查询",
                    url: url,
                }).then(function (response) {
                    var relaod = false;
                    response.data.results.forEach(function (item) {
                        if (item.task_status != 1) {
                            relaod = true;
                        }
                    });
                    response.data.auto_reload = relaod;
                    return response.data;
                })
            })
            .enableExternData(false, function (item) {
                // return $scope.projectHtml(item);
            })
            .setCtrlInitFunc(function ($ctrl) {
                $ctrl.monitorAsset = function (item) {
                    $scope.monitorAsset(item);
                };
                $ctrl.tabBtn = [
                    {
                        name: '查看详情',
                        click: $scope.assetDetails,
                        perm: "",
                    },
                    {
                        name: '编辑',
                        click: $scope.newEditAsset,
                        perm: "ASSET_EDIT_ACTION",
                    },
                    {
                        name: '变更项目',
                        click: $scope.assetChange,
                        perm: "ASSET_CHANGE_PROJECT_ACTION",
                    },
                    {
                        name: '连接',
                        click: $scope.assetLinkVerify,
                        perm: "ASSET_CONNECT_ACTION",
                    },
                    {
                        name: '开机',
                        click: $scope.assetActionOn,
                        perm: "ASSET_POWER_ACTION",
                        display: "$item.asset_status == 2"
                    },
                    {
                        name: '关机',
                        click: $scope.assetActionOff,
                        perm: "ASSET_SHUTDOWN_ACTION",
                        display: "$item.asset_status == 1"
                    },
                    {
                        name: '重启',
                        click: $scope.assetActionReboot,
                        perm: "ASSET_REBOOT_ACTION",
                    },
                    {
                        name: '重装系统',
                        click: $scope.assetActionRebuild,
                        perm: "ASSET_REBUILD_ACTION",
                    },
                    {
                        name: '启用',
                        click: $scope.assetEnable,
                        perm: "ASSET_ENABLE_OR_DISABLE_ACTION",
                        display: '!$ctrl.item.is_active'
                    },
                    {
                        name: '禁用',
                        click: $scope.assetDisable,
                        perm: "ASSET_ENABLE_OR_DISABLE_ACTION",
                        display: '$ctrl.item.is_active'
                    },
                    {
                        name: '删除',
                        click: $scope.delAsset,
                        perm: "ASSET_DELETE_ACTION",
                    }
                ];
            });
        /**
         * 新增编辑资产
         * @param assetObj
         */
        $scope.newEditAsset = function (assetObj) {
            $scope.items = (assetObj == null || assetObj == "" ||
            typeof(assetObj) == "undefined") ? {} : assetObj;
            var modalInstance = $modal.open({
                templateUrl: 'tpl/asset_edit_modal.html',
                controller: 'assetModalCtrl',
                size: 'lg',
                resolve: {
                    items: function () {
                        return $scope.items;
                    },
                    values: function () {
                        return null;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var method = "POST", url = '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/asset/';
                if (selectedItem.hasOwnProperty('id')) {
                    method = 'PUT';
                    url += selectedItem.id + '/';
                }
                $http({
                    method: method,
                    err_title: "创建或修改资产",
                    url: url,
                    data: selectedItem
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('success', '修改资产', '保存成功');
                        } else {
                            toaster.pop('success', '新增资产', '保存成功');
                        }
                        $scope.table_options.reload();//重新渲染表格
                    } else {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('error', '修改资产', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        } else {
                            toaster.pop('error', '新增资产', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        }
                    }
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         * 删除资产
         * @param assetObj
         */
        $scope.delAsset = function (assetObj) {
            if (!(assetObj instanceof Array)) {
                assetObj = (assetObj == null || assetObj == "" ||
                typeof(assetObj) == "undefined") ? [] : [assetObj];
            }
            assetObj = (assetObj == null || assetObj == "" ||
            typeof(assetObj) == "undefined") ? [] : assetObj;
            $scope.items = assetObj;
            var modalInstance = $modal.open({
                templateUrl: 'delAssetTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var defered_array = [];
                angular.forEach(selectedItem, function (data, index, array) {
                    defered_array.push($scope.deleteAsset(data.id));
                });
                $q.all(defered_array).then(function () {
                    $scope.table_options.reload();//重新渲染表格
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
        /**
         * 监控资产
         * @param assetObj
         */
        $scope.monitorAsset = function (assetObj) {
            if (!(assetObj instanceof Array)) {
                assetObj = (assetObj == null || assetObj == "" ||
                typeof(assetObj) == "undefined") ? [] : [assetObj];
            }
            assetObj = (assetObj == null || assetObj == "" ||
            typeof(assetObj) == "undefined") ? [] : assetObj;

            var modalInstance = $modal.open({
                templateUrl: 'tpl/ms_project_asset_monitor.html',
                controller: 'MonitorModalCtrl',
                windowClass: "right-box",
                backdropClass: "right-box-modal-backdrop",
                resolve: {
                    items: function () {
                        return assetObj;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {

            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
        /**
         * 删除资产
         * @param id
         */
        $scope.deleteAsset = function (id) {
            var defer = $q.defer();
            $http({
                method: 'DELETE',
                err_title: "删除资产",
                url: $scope.listUrl + id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '删除资产', '删除成功');
                } else {
                    toaster.pop('error', '删除资产', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
                defer.resolve();
            }, function errorCallback(response) {
                defer.resolve();
            });
            return defer.promise;
        };

        /**
         * 批量更新资产
         * @param batchUpdateObj
         */
        $scope.assetBatchUpdate = function (batchUpdateObj) {
            if (!(batchUpdateObj instanceof Array)) {
                batchUpdateObj = (batchUpdateObj == null || batchUpdateObj == "" ||
                typeof(batchUpdateObj) == "undefined") ? [] : [batchUpdateObj];
            }
            batchUpdateObj = (batchUpdateObj == null || batchUpdateObj == "" ||
            typeof(batchUpdateObj) == "undefined") ? [] : batchUpdateObj;
            $scope.items = batchUpdateObj;
            var modalInstance = $modal.open({
                templateUrl: 'assetBatchUpdateTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var defered_array = [];
                if (selectedItem.length > 0) {
                    angular.forEach(selectedItem, function (data, index, array) {
                        defered_array.push($scope.updateAsset(data.id));
                    });
                    $q.all(defered_array).then(function () {
                        $scope.table_options.reload();//重新渲染表格
                    })

                }
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         * 更新资产
         * @param id
         */
        $scope.updateAsset = function (id) {
            return $http({
                method: 'POST',
                err_title: "更新资产",
                url: '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/asset-update/' + id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '更新资产', '请求成功');
                } else {
                    toaster.pop('error', '更新资产', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            });
        };
        $scope.assetActionOn = function (actionBatchObj) {
            $scope.assetActionBatch(actionBatchObj, "on");
        };
        $scope.assetActionOff = function (actionBatchObj) {
            $scope.assetActionBatch(actionBatchObj, "off");
        };
        $scope.assetActionReboot = function (actionBatchObj) {
            $scope.assetActionBatch(actionBatchObj, "reboot");
        };
        $scope.assetActionRebuild = function (actionBatchObj) {
            $scope.assetActionBatch(actionBatchObj, "rebuild");
        };

        function run_func_array(func_array) {
            var deferred = $q.defer();
            deferred.resolve();
            var promise = deferred.promise;
            for (var i = 0; i < func_array.length; i++) {
                promise = promise.then(func_array[i]);
            }
            return promise;
        }

        function assetAction(item) {
            return function () {
                var defer = $q.defer();
                $http({
                    method: 'POST',
                    err_title: item.actionBatchTitle + '操作',
                    url: '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/asset-action/' + item.id + '/',
                    data: {action: item.actionBatchType}
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        toaster.pop('success', item.actionBatchTitle + '操作', '提交成功');
                    } else {
                        toaster.pop('error', item.actionBatchTitle + '操作', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                    }
                    defer.resolve();
                }, function () {
                    defer.resolve();
                });
                return defer.promise;
            }

        }

        /**
         * 开机/关机/重启/重装系统
         * @param actionBatchObj
         * @param type 类型
         */
        $scope.assetActionBatch = function (actionBatchObj, type) {
            if (!(actionBatchObj instanceof Array)) {
                actionBatchObj = (actionBatchObj == null || actionBatchObj == "" ||
                typeof(actionBatchObj) == "undefined") ? [] : [actionBatchObj];
            }
            actionBatchObj = (actionBatchObj == null || actionBatchObj == "" ||
            typeof(actionBatchObj) == "undefined") ? [] : actionBatchObj;
            if (type === 'on') {
                actionBatchObj.forEach(function (item) {
                    item['actionBatchType'] = type;
                    item['actionBatchTitle'] = '开机';
                });
            }
            if (type === 'off') {
                actionBatchObj.forEach(function (item) {
                    item['actionBatchType'] = type;
                    item['actionBatchTitle'] = '关机';
                });
            }
            if (type === 'reboot') {
                actionBatchObj.forEach(function (item) {
                    item['actionBatchType'] = type;
                    item['actionBatchTitle'] = '重启';
                });
            }
            if (type === 'rebuild') {
                actionBatchObj.forEach(function (item) {
                    item['actionBatchType'] = type;
                    item['actionBatchTitle'] = '重装系统';
                });
            }
            $scope.items = actionBatchObj;
            var modalInstance = $modal.open({
                templateUrl: 'assetActionBatchTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var func_array = [];
                selectedItem.forEach(function (item) {
                    func_array.push(assetAction(item));
                });
                run_func_array(func_array).then(function () {
                    $scope.table_options.reload();//重新渲染表格
                })

            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         * 禁用/启用资产
         * @param assetObj
         */
        $scope.assetDisable = function (assetObj) {
            if (!(assetObj instanceof Array)) {
                assetObj = (assetObj == null || assetObj == "" ||
                typeof(assetObj) == "undefined") ? [] : [assetObj];
            }
            assetObj = (assetObj == null || assetObj == "" ||
            typeof(assetObj) == "undefined") ? [] : assetObj;
            $scope.items = assetObj;
            var modalInstance = $modal.open({
                templateUrl: 'assetDisableEnableTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                $http({
                    method: 'POST',
                    err_title: "禁用/启用资产",
                    url: '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/asset-enable/' + selectedItem[0].id + '/',
                    data: {enable: false}
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        if (selectedItem.is_active) {
                            toaster.pop('success', '启用资产', '成功');
                        }
                        if (!selectedItem.is_active) {
                            toaster.pop('success', '禁用资产', '成功');
                        }
                        $scope.table_options.reload();//重新渲染表格
                    } else {
                        if (selectedItem.is_active) {
                            toaster.pop('error', '启用资产', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        }
                        if (!selectedItem.is_active) {
                            toaster.pop('error', '禁用资产', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        }
                    }
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        $scope.assetEnable = function (assetObj) {
            if (!(assetObj instanceof Array)) {
                assetObj = (assetObj == null || assetObj == "" ||
                typeof(assetObj) == "undefined") ? [] : [assetObj];
            }
            assetObj = (assetObj == null || assetObj == "" ||
            typeof(assetObj) == "undefined") ? [] : assetObj;
            $scope.items = assetObj;
            var modalInstance = $modal.open({
                templateUrl: 'assetDisableEnableTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                $http({
                    method: 'POST',
                    err_title: "禁用/启用资产",
                    url: '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/asset-enable/' + selectedItem[0].id + '/',
                    data: {enable: true}
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        if (selectedItem.is_active) {
                            toaster.pop('success', '启用资产', '成功');
                        }
                        if (!selectedItem.is_active) {
                            toaster.pop('success', '禁用资产', '成功');
                        }
                        $scope.table_options.reload();//重新渲染表格
                    } else {
                        if (selectedItem.is_active) {
                            toaster.pop('error', '启用资产', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        }
                        if (!selectedItem.is_active) {
                            toaster.pop('error', '禁用资产', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        }
                    }
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
        /**
         * 资产详情
         * @param assetObj
         */
        $scope.assetDetails = function (assetObj) {
            $scope.items = (assetObj == null || assetObj == "" ||
            typeof(assetObj) == "undefined") ? {} : assetObj;
            var modalInstance = $modal.open({
                templateUrl: 'assetDetailsTpl',
                controller: 'assetDetailsModalCtrl',
                size: 'lg',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {

            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         * 资产变更
         * @param assetObj
         */
        $scope.assetChange = function (assetObj) {
            $scope.items = (assetObj == null || assetObj == "" ||
            typeof(assetObj) == "undefined") ? {} : assetObj;
            var modalInstance = $modal.open({
                templateUrl: 'assetChangeTpl',
                controller: 'assetChangeModalCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                $http({
                    method: 'POST',
                    err_title: "资产变更",
                    url: '/v1/asset-manage/project/' + selectedItem.old_project_id + '/asset/' + selectedItem.assetId + '/change-project/',
                    data: {new_project_id: selectedItem.new_project_id}
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        toaster.pop('success', '资产变更', '成功');
                        $scope.table_options.reload();//重新渲染表格
                    } else {
                        toaster.pop('error', '资产变更', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                    }
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };


        /**
         * 查询多用户
         * @param options
         */
        $scope.assetUsers = function (options) {
            var modalInstance = $modal.open({
                templateUrl: 'assetUsersTpl',
                controller: 'linkUsersModalCtrl',
                resolve: {
                    options: options
                }
            });

            modalInstance.result.then(function (selectedItem) {
                $scope.selected = selectedItem;
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
        /***
         * 连接
         */
        $scope.assetLinkVerify = function (assetObj) {
            $http({
                method: 'GET',
                err_title: "获取用户信息失败",
                url: '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/asset/' + assetObj.id + '/my-role/'
            }).then(function successCallback(response) {
                if (response.data.count == 0) {
                    toaster.pop('error', '连接失败', '未授权系统用户', $rootScope.errorDwellTime);
                }
                else if (response.data.count == 1) {
                    var role = response.data.results[0];
                    var url = "web_terminal.html?" + "project_id=" + msLocalStorage.get("projectId") + "&asset_id=" + assetObj.id + "&role_id=" + role.id;
                    $.ms.setWindowOpen(url, '_blank', 1174, 476);
                }
                else {

                    $scope.assetUsers({
                        roles: response.data.results,
                        project_id: msLocalStorage.get("projectId"),
                        asset_id: assetObj.id
                    });
                }
            });
        };
    }
]);
app.controller('assetBatchExecModalCtrl', ['$rootScope', '$scope', '$http', '$location', '$modalInstance', 'toaster', '$sce', 'msLocalStorage',
    function ($rootScope, $scope, $http, $location, $modalInstance, toaster, $sce, msLocalStorage) {
        $scope.disabled = true;
        var id = 0;
        $scope.content_htmls = [];
        $scope.message = "初始化中...";
        var last_count = 0;
        var proxy_count = 0;

        function add_html(html) {
            $('.batch-exec-msg').append(html);
            $('.batch-exec-msg').append("<br>");
            $scope.$broadcast("scroll-bottom");
        }

        var url = "/v1/proxy-manage/project/" + msLocalStorage.get("projectId") + "/proxy/" + "all" + "/execute-cmd-token/";
        $http({
            method: "POST",
            err_title: "连接失败",
            url: url
        }).then(function successCallback(response) {
            var options = {};
            options.enters = response.data.results;
            proxy_count = response.data.results.length;
            options.onmessage = $scope.onmessage;
            options.onclose = $scope.onclose;
            $scope.executeCmd = new $.ms.ExecuteCmd(options);
            $scope.content_htmls = [];
            $scope.disabled = false;
            $scope.message = "";
        });
        $scope.onclose = function () {
            $scope.disabled = true;
            $scope.message = "连接已关闭";
        };
        $scope.onmessage = function (message) {
            $scope.$apply(function () {
                var data = JSON.parse(message.data);
                var type = data.type;
                var html = "";
                last_count -= 1;
                if (last_count <= 0) {
                    $scope.disabled = false;
                    $scope.message = "";
                }
                else {
                    $scope.message = "执行中...(" + (proxy_count - last_count) + "/" + proxy_count + ")";
                }
                if (type == 'results') {

                    add_html('匹配主机: ' + data.asset_name.join(","));
                    add_html('<span style="color: yellow">Ansible> ' + data.command + '</span>');
                    data.results.forEach(function (item) {
                        if (item.success) {
                            add_html("<span style='color: green'>[ " + item.host + " => success]</span>\n");
                        }
                        else {
                            add_html("<span style='color: red'>[ " + item.host + " => failed]</span>\n");
                        }
                        var info = item.info.replace(/\n/g, "<br>");
                        add_html(info);
                    });
                }
                else if (type == "text") {
                    add_html(data.text);
                }
            })

        };
        $scope.sendMessage = function () {
            last_count = proxy_count;
            $scope.disabled = true;
            $scope.message = "执行中...(" + (proxy_count - last_count) + "/" + proxy_count + ")";

            var data = {
                pattern: $scope.ansible,
                command: $scope.command
            };
            $scope.executeCmd.send(data);
            $scope.command = '';
        };

        $scope.proxyKeyPress = function (event) {
            if (event.keyCode === 13 && !$scope.exec_form.$invalid) {
                $scope.sendMessage();
            }
        };

        $scope.ok = function () {
            $modalInstance.close($scope.items);
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);

/**
 * 批量导入
 */
app.controller('batchUploadController', ['$rootScope', '$scope', '$stateParams', '$http', '$modal', '$log', '$interval', 'toaster', 'Upload', 'msLocalStorage', '$timeout',
    function ($rootScope, $scope, $stateParams, $http, $modal, $log, $interval, toaster, Upload, msLocalStorage, $timeout) {
        $scope.formFlag = true;
        $scope.tableFlag = false;
        $scope.progressbarFlag = false;
        $scope.checkingFlag = false;
        $scope.batchUploadModal = {
            file: null
        };
        $scope.url = '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/';
        /**
         * 下载模板
         */
        $scope.batchoadTemplete = function () {
            window.open($scope.url + 'batch-load-templete/', '_self', 'toolbar=no, location=no,resizable=no,copyhistory=yes, scrollbars=no');
        };
        $http({
            method: 'GET',
            err_title: "查询proxy",
            url: '/v1/proxy-manage/project/' + msLocalStorage.get("projectId") + '/proxy/?limt=all',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.proxyItems = response.data.results;
            }
        });

        $scope.loadTimeout = 1000 * 1;
        $scope.fileUploadProgress = 0;
        $scope.progressFlag = false;
        $scope.progressValue = 0;
        $scope.cancelFlag = false;
        $scope.nextFlag = false;

        function loadData() {
            $http({
                method: 'GET',
                err_title: "查询状态",
                url: $scope.url + 'batch-load/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    if (response.data.status === 'checking') {
                        $scope.formFlag = false;
                        $scope.tableFlag = false;
                        $scope.progressbarFlag = true;
                        $scope.checkingFlag = false;
                        $scope.cancelFlag = true;
                        $scope.nextFlag = false;
                        if (response.data.total > 0) {
                            $scope.fileUploadProgress = response.data.count * 100 / response.data.total;

                        } else {
                            $scope.fileUploadProgress = 0;
                        }
                        $scope.progressFlag = true;
                        $scope.progressValue = '校验中:' + response.data.count + '/' + response.data.total;
                        $timeout(function () {
                            loadData();
                        }, $scope.loadTimeout);
                    }
                    if (response.data.status === 'check_complete') {
                        if (!response.data.has_error) {
                            $scope.formFlag = false;
                            $scope.tableFlag = true;
                            $scope.progressbarFlag = false;
                            $scope.checkingFlag = true;
                            $scope.progressFlag = false;
                            $scope.cancelFlag = true;
                            $scope.nextFlag = true;
                        }
                        else {
                            $scope.formFlag = true;
                            $scope.tableFlag = true;
                            $scope.progressbarFlag = false;
                            $scope.checkingFlag = false;
                            $scope.progressFlag = false;
                            $scope.cancelFlag = true;
                            $scope.nextFlag = false;
                        }

                    }
                    if (response.data.status === 'saving') {
                        $scope.formFlag = false;
                        $scope.tableFlag = false;
                        $scope.progressbarFlag = true;
                        $scope.checkingFlag = false;
                        $scope.cancelFlag = true;
                        $scope.nextFlag = false;

                        $timeout(function () {
                            loadData();
                        }, $scope.loadTimeout);

                        if (response.data.total > 0) {
                            $scope.fileUploadProgress = response.data.count * 100 / response.data.total;

                        } else {
                            $scope.fileUploadProgress = 0;
                        }
                        $scope.progressFlag = true;
                        $scope.progressValue = '保存中:' + response.data.count + '/' + response.data.total;
                    }
                    if (response.data.status === 'complete') {
                        $scope.formFlag = true;
                        $scope.tableFlag = true;
                        $scope.progressbarFlag = false;
                        $scope.checkingFlag = false;
                        $scope.progressFlag = false;
                        $scope.cancelFlag = false;
                        $scope.nextFlag = false;
                    }
                    if (response.data.status === undefined) {
                        $scope.formFlag = true;
                        $scope.tableFlag = false;
                        $scope.progressbarFlag = false;
                        $scope.checkingFlag = false;
                        $scope.progressFlag = false;
                        $scope.cancelFlag = false;
                        $scope.nextFlag = false;
                    }
                    if (response.data.error_message) {
                        $scope.tableFlag = false;
                        $scope.progressbarFlag = false;
                        $scope.checkingFlag = false;
                        $scope.progressFlag = false;
                        $scope.cancelFlag = false;
                        $scope.nextFlag = false;
                        toaster.pop('error', '导入错误', response.data.error_message, $rootScope.errorDwellTime);
                        $http({
                            method: 'DELETE',
                            err_title: "",
                            url: $scope.url + 'batch-load/',
                            data: ''
                        }).then(function successCallback(response) {

                        });
                    }
                    $scope.tableModal = response.data.items;
                }
            });
        };

        //默认执行一次
        loadData();

        /**
         *
         * @param items
         */
        $scope.proxyChange = function (items) {
            if (!$.ms.isEmptyObject(items)) {
                $http({
                    method: 'GET',
                    err_title: "查询用户配置文件",
                    url: '/v1/asset-manage/proxy/' + items.proxy.id + '/profile/?limt=all',
                    data: ''
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        items.profileList = response.data.results;
                    }
                });
            }
        };

        //取消
        $scope.cancel = function () {
            $http({
                method: 'DELETE',
                err_title: "",
                url: $scope.url + 'batch-load/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '提交成功');
                    loadData();
                }
            });
        };

        //下一步
        $scope.next = function () {
            var items = [], lastProxy = null, lastProfile = null;
            for (var i in $scope.tableModal) {
                var data = $scope.tableModal[i];
                var proxy = data.proxy, profile = data.profile;
                if (!proxy) {
                    if (!lastProxy) {
                        toaster.pop('error', '请选择Proxy');
                        return;
                    } else {
                        proxy = lastProxy;
                    }
                } else {
                    lastProxy = proxy;
                }
                if (!profile) {
                    if (!lastProfile) {
                        toaster.pop('error', '请选择Profile');
                        return;
                    } else {
                        profile = lastProfile;
                    }
                } else {
                    lastProfile = profile;
                }
                items.push({id: data.id, proxy_id: proxy.id, profile: profile});
            }
            $http({
                method: 'PUT',
                err_title: "",
                url: $scope.url + 'batch-load/',
                data: {items: items}
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '提交成功');
                    loadData();
                }
            });
        };

        $scope.submit = function () {
            if (!$scope.batchUploadModal.file) {
                toaster.pop('error', '未选择文件');
                return;
            }
            $scope.uploadFile($scope.batchUploadModal.file, $scope.upload)
        };

        $scope.uploadFile = function (file, callback) {
            file.upload = Upload.upload({
                url: '/v1/common-file/upload/',
                data: {file: file}
            });

            file.upload.then(function (response) {
                file.result = response.data;
                callback(file.result.id)
            }, function (response) {
                if (response.status > 0)
                    $scope.errorMsg = response.status + ': ' + response.data;
            }, function (evt) {
                // Math.min is to fix IE which reports 200% sometimes
                file.progress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
            });
        };
        $scope.upload = function (fileid) {
            $http({
                method: 'POST',
                err_title: "上传失败",
                url: $scope.url + 'batch-load/',
                data: {file: fileid}
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '提交成功');
                    loadData();
                }
            });
        };

    }]);

/**
 * 主机探测
 */
app.controller('hostDeteDetailModalCtrl', ['$scope', '$http', '$modalInstance', 'items', 'msLocalStorage',
    function ($scope, $http, $modalInstance, items, msLocalStorage) {
        $scope.items = {};
        $http({
            method: 'GET',
            err_title: "查询主机探测详情",
            url: '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/asset-detection/' + items.id + '/',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.items = response.data;
            } else {
                toaster.pop('error', '查询主机探测详情', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
            }
        });

        $scope.ok = function () {
            $modalInstance.close('');
        };

        $scope.clear = function () {
            $scope.items = {};
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
app.controller('hostDetectionController', ['$rootScope', '$scope', '$stateParams', '$http', '$modal', '$log', '$interval', 'toaster', 'msLocalStorage',
    function ($rootScope, $scope, $stateParams, $http, $modal, $log, $interval, toaster, msLocalStorage) {
        $scope.listUrl = '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/asset-detection/';
        $scope.hostDetectionInquire = {};
        $scope.table_options = new msTables.Option()
            .enableSearch(false)
            .withFields(
                [{
                    key: 'ip',
                    title: "主机IP",
                    sort_key: "ip"
                }, {
                    key: 'mac',
                    title: "MAC地址",
                    sort_key: "mac"
                }, {
                    title: "操作",
                    can_hide: false,
                    class: 'ms-table-operate',
                    html: function () {
                        return '<ms-ext-btn buttons="$ctrl.tabBtn" item="$item"/>';
                    }
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                var url = $scope.listUrl + '?offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "主机探测列表查询",
                    url: url,
                }).then(function (response) {
                    // response.data.auto_reload = true;
                    return response.data;
                })
            })
            .enableExternData(true, function (item) {
                return $scope.proxyHtml(item);
            })
            .setCtrlInitFunc(function ($ctrl) {
                $ctrl.tabBtn = [
                    {
                        name: '添加',
                        click: $scope.addHostDetection,
                        perm: "",
                    },
                    // {
                    //     name: '详情',
                    //     click: $scope.hostDetectionDetail,
                    //     perm: "",
                    // }
                ];
            });
        $scope.proxyHtml = function (data, type, full, meta) {
            var html = '', dt = '', dd = '';
            dt = '<dt>代理:</dt>';
            angular.forEach(data.proxy, function (proxyData, proxyIndex, proxyArray) {
                dd += '<dd>' + proxyData.proxy_name + '</dd>';
            });
            html += '<dl class="user-project">' + dt + dd + '</dl>';
            return html;
        };
        /**
         * 刷新
         */
        $scope.refreshHostDetection = function () {
            $http({
                method: 'POST',
                err_title: "主机探测刷新",
                url: $scope.listUrl,
                data: {ip_segment: $scope.hostDetectionInquire.ip_segment}
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '主机探测刷新', '主机探测刷新成功');
                } else {
                    toaster.pop('error', '主机探测刷新', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            }, function errorCallback(response) {
            });
        };

        /**
         * 添加
         */
        $scope.addHostDetection = function (hdObj) {
            var modalInstance = $modal.open({
                templateUrl: 'tpl/asset_edit_modal.html',
                controller: 'assetModalCtrl',
                size: 'lg',
                resolve: {
                    items: function () {
                        return {};
                    },
                    values: function () {
                        return {ip: hdObj.ip}
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                var method = "POST", url = '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/asset/';
                $http({
                    method: method,
                    err_title: "创建资产",
                    url: url,
                    data: selectedItem
                }).then(function successCallback(response) {
                    toaster.pop('success', '新增资产', '保存成功');
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         * 详情
         * @param hdObj
         */
        $scope.hostDetectionDetail = function (hdObj) {
            $scope.items = (hdObj == null || hdObj == "" ||
            typeof(hdObj) == "undefined") ? {} : hdObj;
            var modalInstance = $modal.open({
                templateUrl: 'hostDeteDetailsTpl',
                controller: 'hostDeteDetailModalCtrl',
                size: 'lg',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {

            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
    }]);
app.controller('MonitorModalCtrl', ['$scope', '$modalInstance', 'items', 'msLocalStorage', '$http', 'toaster',
    function ($scope, $modalInstance, items, msLocalStorage, $http, toaster) {
        $scope.globalParam = {
            assets: items,
            cf: 'AVERAGE',
            graph_type: 'h'
        };
        $('.app-header').css('z-index', '1050');
        $scope.items = items;
        $scope.listUrl = '/v1/open-falcon/project/' + msLocalStorage.get("projectId") + '/chat/';
        $http({
            method: 'GET',
            err_title: "查询参数组",
            url: '/v1/open-falcon/counter-group/',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.parameterList = response.data.results;
                $scope.globalParam.counter = $scope.parameterList[0].pattern;
            } else {
                toaster.pop('error', '查询参数组', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
            }
        }, function errorCallback(response) {
        }).then(function () {
            $scope.selectShow();
        });

        $scope.ok = function () {
            $modalInstance.close($scope.items);
        };

        $scope.resetForm = function () {
            $scope.globalParam = {
                cf: 'AVERAGE',
                graph_type: 'h'
            };
        };

        $scope.cancel = function () {
            $('.app-header').css('z-index', '');
            $modalInstance.dismiss('cancel');
        };

        Array.prototype.map = function (fn, thisObj) {
            var scope = thisObj || window;
            var a = [];
            for (var i = 0, j = this.length; i < j; ++i) {
                a.push(fn.call(scope, this[i], i, this));
            }
            return a;
        };

        var getRandomColor = function () {
            return '#' + '0123456789abcdef'.split('').map(function (v, i, a) {
                    return i > 5 ? null : a[Math.floor(Math.random() * 16)]
                }).join('');
        };

        function mAvg(mArray) {
            var value;
            var sum = 0;
            var count = 0;
            mArray.forEach(function (item) {
                value = item[1];
                if (value != null) {
                    sum += value;
                    count += 1;
                }
            });
            var avg = sum / count;
            return avg.toFixed(2);
        }


        //查看
        $scope.selectShow = function () {
            var parm = angular.copy($scope.globalParam);
            if (parm.start) {
                parm.start = moment(parm.start).unix();
            }
            if (parm.end) {
                parm.end = moment(parm.end).unix();
            }
            $scope.chartsArray = [];
            $http({
                method: 'POST',
                err_title: "查询监控数据",
                url: $scope.listUrl + parm.graph_type + '/',
                data: parm
            }).then(function successCallback(response) {
                if (!response.data.length) {
                    toaster.pop('info', '提示', '没有符合条件的数据', 1500);
                }
                angular.forEach(response.data, function (data1, index1, array1) {
                    var tableDatas = [], datas = [], title = '', lineColorArray = [], chartConfig = {};

                    title = data1.title;
                    angular.forEach(data1.series, function (data2, index2, array2) {
                        var color = getRandomColor();
                        lineColorArray.push(color);
                        tableDatas.push(
                            {
                                name: data2.name,
                                color: color,
                                max: _.max(data2.data, function (stooge) {
                                    return stooge[1];
                                })[1] ? _.max(data2.data, function (stooge) {
                                        return stooge[1];
                                    })[1].toFixed(3) : 0,
                                min: _.min(data2.data, function (stooge) {
                                    return stooge[1];
                                })[1] ? _.min(data2.data, function (stooge) {
                                        return stooge[1];
                                    })[1].toFixed(3) : 0,
                                last: _.last(data2.data)[1] ? _.last(data2.data)[1].toFixed(3) : 0,
                                avg: mAvg(data2.data)
                            }
                        );
                        datas.push({
                            showInLegend: false,
                            name: data2.name,
                            data: data2.data
                        });
                        chartConfig = {
                            colors: lineColorArray,
                            chart: {
                                type: 'line'
                            },
                            title: {
                                text: title
                            },
                            subtitle: {
                                text: ''
                            },
                            credits: {
                                enabled: false
                            },
                            xAxis: {
                                type: 'datetime',
                                labels: {
                                    overflow: 'justify'
                                },
                                dateTimeLabelFormats: {
                                    millisecond: '%H:%M:%S.%L',
                                    second: '%H:%M:%S',
                                    minute: '%H:%M',
                                    hour: '%H:%M',
                                    day: '%m-%d',
                                    week: '%m-%d',
                                    month: '%Y-%m',
                                    year: '%Y'
                                }
                            },
                            tooltip: {
                                xDateFormat: '%Y-%m-%d %H:%M:%S'
                            },
                            plotOptions: {
                                line: {
                                    lineWidth: 1,
                                    states: {
                                        hover: {
                                            lineWidth: 1
                                        }
                                    },
                                    marker: {
                                        enabled: false
                                    }
                                }
                            },
                            series: datas,
                            navigation: {
                                menuItemStyle: {
                                    fontSize: '10px'
                                }
                            }
                        };
                    });
                    $scope.chartsArray.push({chartConfig: chartConfig, tables: tableDatas});
                    if (!tableDatas.length) {
                        toaster.pop('info', '提示', '没有符合条件的数据', 1500);
                    }
                });

            });
        };
    }]);