/**
 * Created by 李杜康 on 2016/11/9.
 * app
 */
'use strict';
app.controller('appController', ['$rootScope', '$scope', '$http', '$state',
    '$window', '$modal', '$log', '$interval', 'toaster', 'msLocalStorage', 'permission',
    function ($rootScope, $scope, $http, $state, $window,
              $modal, $log, $interval, toaster, msLocalStorage, permission) {
        $rootScope.username = msLocalStorage.get("username");
        $rootScope.projectId = msLocalStorage.get("projectId");
        $rootScope.projectName = msLocalStorage.get("projectName");

        //自动刷新时间
        $rootScope.autoRefreshTime = 1000 * 5;
        $rootScope.errorDwellTime = 1000 * 60 * 60 * 1;

        $http({
            method: 'GET',
            no_error: true,
            url: '/v1/permissions/version/',
            data: ''
        }).then(function successCallback(response) {
            $scope.server_version = response.data.version;
        });
        /**
         * 登录检查
         */
        function checkLogin() {
            $http({
                method: 'GET',
                no_error: true,
                url: '/v1/permissions/check_login',
                data: ''
            }).then(function successCallback(response) {
                $rootScope.SESSION_KEY = response.data.session_key;
                setTimeout(function () {
                    checkLogin();
                }, $rootScope.autoRefreshTime);
            }, function errorCallback(response) {
                if (response.status != 403) {
                    setTimeout(function () {
                        checkLogin();
                    }, $rootScope.autoRefreshTime);
                }
            });
        };

        $scope.userData = {};
        $scope.myUserUrl = '/v1/user-manage/my-user/';
        $scope.getUserInfo = function () {
            $http({
                method: 'GET',
                err_title: "查询个人信息",
                url: $scope.myUserUrl,
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.userData = response.data;
                }
            });
        };

        /**
         * 修改用户信息
         * @param userObj
         */
        $scope.myUser = function (userObj) {
            $scope.items = (userObj == null || userObj == "" ||
            typeof(userObj) == "undefined") ? {} : userObj;
            var modalInstance = $modal.open({
                templateUrl: 'myUserTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                $http({
                    method: 'PUT',
                    err_title: "修改个人信息",
                    url: $scope.myUserUrl,
                    data: selectedItem
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        $scope.getUserInfo();
                        toaster.pop('success', '修改个人信息', '保存成功');
                    } else {
                        toaster.pop('error', '修改个人信息', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                    }
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         * 登出
         */
        $scope.logout = function () {
            $http({
                method: 'POST',
                url: '/v1/permissions/logout',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    msLocalStorage.remove("userId");
                    msLocalStorage.remove("isSuperuser");
                    msLocalStorage.remove("username");
                    msLocalStorage.remove("projectId");
                    msLocalStorage.remove("projectName");
                    msLocalStorage.remove("myProjectList");
                    window.location.href="/";

                }
            });
        };
        var start, end;

        $scope.getMyProjectList = function () {
            $http({
                method: 'GET',
                url: '/v1/permissions/my-project/?offset=0&limit=10',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299 && !$.ms.isEmptyObject(response.data.results)) {
                    $scope.myProjectList = response.data.results;
                    msLocalStorage.set("myProjectList", JSON.stringify(response.data.results));
                }
            });
        };


        /**
         * 监听 是否登录成功
         */
        function start_login() {
            if (msLocalStorage.get("userId")) {
                start = Date.now();
                $scope.getUserInfo();//默认加载一次
                if (msLocalStorage.get("myProjectList")) {
                    $scope.myProjectList = JSON.parse(msLocalStorage.get("myProjectList"));
                }
                // $rootScope.permissionsObj =msLocalStorage.get("permissionsObj");//权限暂时注释
                $scope.$watch("myProjectList", function (newVal, oldVal) {
                    if (newVal) {
                        end = Date.now();
                        console.log(end - start);
                    }
                }, true);
                checkLogin();
            }
        }

        start_login();
        /**
         * 普通刷新后默认执行一次监听
         */
        /**
         * 选择项目
         * @param projectObj
         */
        $scope.selectProject = function (projectObj) {
            msLocalStorage.set("projectId", projectObj.id);
            msLocalStorage.set("projectName", projectObj.name);
            $rootScope.projectId = msLocalStorage.get("projectId");
            $rootScope.projectName = msLocalStorage.get("projectName");
            $window.location.reload();
        };

    }]);

/**
 * Created by lidukang on 2017/1/9.
 */
'use strict';
app.controller('contentLayoutController', ['$rootScope', '$scope', '$state', 'tabs',
    function ($rootScope, $scope, $state, tabs) {
        $scope.tabs = tabs;
        $scope.$on("$stateChangeSuccess", function (event, toState, toParams, fromState, fromParams) {
            var find = false;
            var i, tab;
            for (i in tabs) {
                tab = tabs[i];
                if (tab.stateName == toState.name) {
                    if ($.ms.checkPermissions(tab.perm)) {
                        find = true;
                        break;
                    }
                }
            }
            if (!find) {
                for (i in tabs) {
                    tab = tabs[i];
                    if ($.ms.checkPermissions(tab.perm)) {
                        $state.go(tab.stateName);
                        break;
                    }
                }
            }
        })

    }]);