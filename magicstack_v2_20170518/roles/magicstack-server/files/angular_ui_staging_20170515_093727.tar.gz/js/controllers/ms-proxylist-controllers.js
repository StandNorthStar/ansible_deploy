/**
 * Created by lidukang on 2016/8/5.
 * 代理管理-代理列表
 */
'use strict';
app.controller('batchExecModalCtrl', ['$rootScope', '$scope', '$http', '$location', '$modalInstance', 'toaster', '$sce', 'items',
    function ($rootScope, $scope, $http, $location, $modalInstance, toaster, $sce, items) {
        $scope.disabled = true;
        var id = 0;
        $scope.content_htmls = [];
        $scope.message = "初始化中...";
        var last_count = 0;
        var proxy_count = 0;

        function add_html(html) {
            $('.batch-exec-msg').append(html);
            $('.batch-exec-msg').append("<br>");
            $scope.$broadcast("scroll-bottom");
        }

        var url = "/v1/proxy-manage/project/" + 'all' + "/proxy/" + items.id + "/execute-cmd-token/";
        $http({
            method: "POST",
            err_title: "连接失败",
            url: url
        }).then(function successCallback(response) {
            var options = {};
            options.enters = response.data.results;
            proxy_count = response.data.results.length;
            options.onmessage = $scope.onmessage;
            options.onclose = $scope.onclose;
            $scope.executeCmd = new $.ms.ExecuteCmd(options);
            $scope.content_htmls = [];
            $scope.disabled = false;
            $scope.message = "";
        });
        $scope.onclose = function () {
            $scope.disabled = true;
            $scope.message = "连接已关闭";
        };
        $scope.onmessage = function (message) {
            $scope.$apply(function () {
                console.log(message);
                var data = JSON.parse(message.data);
                var type = data.type;
                var html = "";
                last_count -= 1;
                if (last_count <= 0) {
                    $scope.disabled = false;
                    $scope.message = "";
                }
                if (type == 'results') {

                    add_html('匹配主机: ' + data.asset_name.join(","));
                    add_html('<span style="color: yellow">Ansible> ' + data.command + '</span>');
                    data.results.forEach(function (item) {
                        if (item.success) {
                            add_html("<span style='color: green'>[ " + item.host + " => success]</span>\n");
                        }
                        else {
                            add_html("<span style='color: red'>[ " + item.host + " => failed]</span>\n");
                        }
                        var info = item.info.replace(/\n/g, "<br>");
                        add_html(info);
                    });
                }
                else if (type == "text") {
                    add_html(data.text);
                }
            })

        };
        $scope.sendMessage = function () {
            last_count = proxy_count;
            $scope.disabled = true;
            $scope.message = "执行中...";

            var data = {
                pattern: $scope.ansible,
                command: $scope.command
            };
            $scope.executeCmd.send(data);
            $scope.command = '';
        };

        $scope.proxyKeyPress = function (event) {
            if (event.keyCode === 13 && !$scope.exec_form.$invalid) {
                $scope.sendMessage();
            }
        };

        $scope.ok = function () {
            $modalInstance.close($scope.items);
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
/**
 * 新增编辑
 */
app.controller('proxyModalCtrl', ['$scope', '$http', '$modalInstance', 'toaster', 'items',
    function ($scope, $http, $modalInstance, toaster, items) {
        if (items) {
            $scope.items = angular.copy(items);
        } else {
            $scope.items = {};
        }
        $http({
            method: 'GET',
            err_title: "IDC列表查询",
            url: '/v1/idc-manage/idc/?limit=all',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.IDCItems = response.data.results;
            }
        });

        $scope.clearIDC = function () {
            console.log($scope.items);
            $scope.proxy_form.$setPristine();
            $scope.proxy_form.$setUntouched();
            angular.element("#proxy_form")[0].reset();
        };

        $scope.ok = function () {
            $modalInstance.close($scope.items);
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
app.controller('proxylistController', ['$rootScope', '$scope', '$http', '$state', '$modal', '$log', 'toaster', '$q',
    function ($rootScope, $scope, $http, $state, $modal, $log, toaster, $q) {
        $scope.listUrl = '/v1/proxy-manage/proxy/';
        var editBtnOpt = {
            text: '编辑',
            class: 'color-2',
            perm: "PROXY_EDIT_ACTION",
            color: '#004740',
            action: function () {
                var items = $scope.table_options.getCheckedItems();
                $scope.newEditProxy(items[0]);
            }
        };
        var deleteBtnOpt = {
            text: '删除',
            class: 'color-4',
            perm: "PROXY_DELETE_ACTION",
            color: '#d2181c',
            action: function (e, dt, node, config) {
                var items = $scope.table_options.getCheckedItems();
                $scope.delProxy(items);
            }
        };
        $scope.table_options = new msTables.Option()
            .withButtons([
                //     {
                //     hide: false,
                //     disable: false,
                //     text: '添加',
                //     class: 'color-1',
                //     perm: "PROXY_CREATE_ACTION",
                //     color: '#2f5398',
                //     action: function (button) {
                //         $scope.newEditProxy('');
                //     }
                // },
                editBtnOpt, deleteBtnOpt, {
                    text: '展示/隐藏',
                    extend: 'colvis',
                    perm: "",
                    class: 'color-0'
                }
            ])
            .setCheckedChangeFunc(function (items) {
                if (items.length == 1) {
                    editBtnOpt.disable = false;
                } else {
                    editBtnOpt.disable = true;
                }
                if (items.length > 0) {
                    deleteBtnOpt.disable = false;
                } else {
                    deleteBtnOpt.disable = true;
                }
            })
            .enableSearch(true)
            .withFields(
                [{
                    key: "proxy_name",
                    title: "代理名",
                    sort_key: "proxy_name",
                    can_hide: false
                }, {
                    key: 'idc__name',
                    title: "IDC",
                    sort_key: "idc__name"
                }, {
                    title: "连接状态",
                    sort_key: "status",
                    html: function (item) {
                        if (item.status == 1) {
                            return "<span class='label label-success'>已连接</span>"
                        }
                        else if (item.status == 0) {
                            return "<span class='label label-danger'>已断开</span>"
                        }
                    }
                }, {
                    key: "version",
                    title: "版本"
                }, {
                    key: 'comment',
                    title: "备注",
                    can_hide: false,
                    class: 'long-text',
                    toolTip: function (item) {
                        return item.comment;
                    }
                }, {
                    title: "操作",
                    can_hide: false,
                    class: 'ms-table-operate',
                    html: function () {
                        return '<ms-ext-btn buttons="$ctrl.tabBtn" item="$item"/>';
                    }
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                var url = $scope.listUrl + '?offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "Proxy列表查询",
                    url: url,
                }).then(function (response) {
                    return response.data;
                })
            })
            .enableExternData(false, function (item) {
                // return $scope.projectHtml(item);
            })
            .setCtrlInitFunc(function ($ctrl) {
                $ctrl.tabBtn = [
                    {
                        name: '批量执行',
                        click: $scope.batchExecution,
                        perm: "PROXY_EXEC_COMMAND_ACTION",
                    },
                    {
                        name: '编辑',
                        click: $scope.newEditProxy,
                        perm: "PROXY_EDIT_ACTION",
                    },
                    {
                        name: '删除',
                        click: $scope.delProxy,
                        perm: "PROXY_DELETE_ACTION",
                    }
                ];
            });

        /**
         * 新增、修改代理
         * @param proxyObj
         */
        $scope.newEditProxy = function (proxyObj) {
            $scope.items = (proxyObj == null || proxyObj == "" ||
            typeof(proxyObj) == "undefined") ? {} : proxyObj;
            var modalInstance = $modal.open({
                templateUrl: 'newEditProxyTpl',
                controller: 'proxyModalCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var method = "POST", url = $scope.listUrl;
                if (selectedItem.hasOwnProperty('id')) {
                    method = 'PUT';
                    url += selectedItem.id + '/';
                }
                $http({
                    method: method,
                    err_title: "创建或修改Proxy",
                    url: url,
                    data: selectedItem
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('success', '修改Proxy', '保存成功');
                        } else {
                            toaster.pop('success', '新增Proxy', '保存成功');
                        }
                        $scope.table_options.reload();//重新渲染表格
                    } else {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('error', '修改Proxy', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        } else {
                            toaster.pop('error', '新增Proxy', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        }
                    }
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         * 删除代理
         * @param proxyObj
         */
        $scope.delProxy = function (proxyObj) {
            if (!(proxyObj instanceof Array)) {
                proxyObj = (proxyObj == null || proxyObj == "" ||
                typeof(proxyObj) == "undefined") ? [] : [proxyObj];
            }
            proxyObj = (proxyObj == null || proxyObj == "" ||
            typeof(proxyObj) == "undefined") ? [] : proxyObj;
            $scope.items = proxyObj;
            var modalInstance = $modal.open({
                templateUrl: 'delProxyTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var defered_array = [];
                angular.forEach(selectedItem, function (data, index, array) {
                    defered_array.push($scope.deleteProxy(data.id));
                });
                $q.all(defered_array).then(function () {
                    $scope.table_options.reload();//重新渲染表格
                })

            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         * 删除代理
         * @param id
         */
        $scope.deleteProxy = function (id) {
            var defer = $q.defer();
            $http({
                method: 'DELETE',
                err_title: "删除代理",
                url: $scope.listUrl + id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '删除代理', '删除成功');
                } else {
                    toaster.pop('error', '删除代理', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
                defer.resolve();
            }, function errorCallback(response) {
                defer.resolve();
            });
            return defer.promise;
        };


        /**
         * 批量执行
         * @param batchExecObj
         */
        $scope.batchExecution = function (batchExecObj) {
            var modalInstance = $modal.open({
                templateUrl: 'batchExecutionTpl',
                controller: 'batchExecModalCtrl',
                size: 'batch-exec',
                resolve: {
                    items: batchExecObj
                }
            });

            modalInstance.result.then(function (selectedItem) {
                $scope.selected = selectedItem;
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
    }
]);