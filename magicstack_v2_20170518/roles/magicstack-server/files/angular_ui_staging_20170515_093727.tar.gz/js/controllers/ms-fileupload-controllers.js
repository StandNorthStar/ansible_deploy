/**
 * Created by lidukang on 2016/10/11.
 * 文件上传
 */
'use strict';
app.controller('fileUploadModalCtrl', ['$rootScope', '$scope', '$http', '$modalInstance', 'msLocalStorage', 'toaster', 'items', 'Upload',
    function ($rootScope, $scope, $http, $modalInstance, msLocalStorage, toaster, items, Upload) {
        $scope.fileUploadModel = {};

        $http({
            method: 'GET',
            err_title: "代理列表查询",
            url: '/v1/proxy-manage/project/' + msLocalStorage.get("projectId") + '/proxy/?limit=all&ordering=proxy_name',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.proxyItems = response.data.results;
            }
        });

        /**
         * 获取资产列表
         */
        $scope.$watch('fileUploadModel.proxy', function (newVal, oldVal) {
            if (!$.ms.isEmptyObject(newVal)) {
                $http({
                    method: 'GET',
                    err_title: "代理列表查询",
                    url: '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/proxy/' + newVal.id + '/asset/?limit=all',
                    data: ''
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        $scope.assetItems = response.data.results;
                    }
                });
            } else {
                $scope.assetItems = [];
            }
        }, true);
        $scope.assetsFlag = true;
        /**
         * 监听资产
         */
        $scope.$watch('fileUploadModel.assets', function (newVal, oldVal) {
            if (newVal) {
                $scope.assetsFlag = false;
            }
        }, true);


        $scope.submit = function () {
            $scope.uploadFile($scope.file, $scope.upload)
        };

        $scope.uploadFile = function (file, callback) {
            file.upload = Upload.upload({
                url: '/v1/common-file/upload/',
                data: {file: file}
            });

            file.upload.then(function (response) {
                file.result = response.data;
                callback(file.result.id)
            }, function (response) {
                if (response.status > 0)
                    $scope.errorMsg = response.status + ': ' + response.data;
            }, function (evt) {
                // Math.min is to fix IE which reports 200% sometimes
                $scope.fileUploadProgress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
            });
        };

        $scope.upload = function (fileid) {
            $scope.fileUploadModel.file = fileid;
            $http({
                method: 'POST',
                err_title: "上传失败",
                url: '/v1/file/project/' + msLocalStorage.get("projectId") + '/upload/',
                data: $scope.fileUploadModel
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '提交成功');
                    $modalInstance.close($scope.items);
                }
            });
        };

        $scope.clear = function () {
            $scope.fileUploadModel = {};
            $scope.file = null;
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
app.controller('fileuploadController', ['$rootScope', '$scope', '$http', 'msLocalStorage', '$modal', '$log', 'toaster', 'Upload',
    function ($rootScope, $scope, $http, msLocalStorage, $modal, $log, toaster, Upload) {
        $scope.listUrl = '/v1/file/project/' + msLocalStorage.get("projectId") + '/upload/';
        $scope.table_options = new msTables.Option()
            .withButtons([{
                hide: false,
                disable: false,
                text: '上传文件',
                perm: "FILE_UPLOAD_ACTION",
                class: 'color-1',
                action: function (button) {
                    $scope.fileUploadOpen();
                }
            }])
            .enableSearch(true)
            .enableItemChecks(false)
            .withFields(
                [
                    {
                        key: 'file__name',
                        title: '文件名',
                        sort_key: 'file__name'
                    },
                    {
                        key: 'path',
                        title: '目标目录',
                        sort_key: 'path'
                    },
                    {
                        key: 'create_time',
                        title: '上传时间',
                        sort_key: 'create_time'
                    },
                    {
                        title: '上传结果',
                        sort_key: 'result',
                        html: function (item) {
                            if (item.result) {
                                return item.result.replace(/\n/g, '<br>');
                            } else {
                                return '';
                            }
                        }
                    }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                var url = $scope.listUrl + '?offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "上传列表查询",
                    url: url,
                }).then(function (response) {
                    var relaod = false;
                    response.data.results.forEach(function (item) {
                        if (!item.result) {
                            relaod = true;
                        }
                    });
                    response.data.auto_reload = relaod;
                    return response.data;
                })
            })
            .enableExternData(false, function (item) {
                return "";
            });
        /**
         * 文件上传
         * @param fileObj
         */
        $scope.fileUploadOpen = function (fileObj) {
            $scope.items = (fileObj == null || fileObj == "" ||
            typeof(fileObj) == "undefined") ? {} : fileObj;
            var modalInstance = $modal.open({
                templateUrl: 'fileUploadTpl',
                controller: 'fileUploadModalCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                $scope.table_options.reload();
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
    }]);