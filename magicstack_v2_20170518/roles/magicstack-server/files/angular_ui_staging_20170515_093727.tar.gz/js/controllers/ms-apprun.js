/**
 * 应用管理-模板剧本-部署
 */
'use strict';
app.controller('appRunController', ['$rootScope', '$scope', '$stateParams', '$http', '$modal', '$log', '$interval', 'toaster', 'msLocalStorage', '$timeout', 'msItemSelect', '$q',
    function ($rootScope, $scope, $stateParams, $http, $modal, $log, $interval, toaster, msLocalStorage, $timeout, msItemSelect, $q) {

        $scope.deployURL = '/v1/application/project/' + msLocalStorage.get("projectId") + '/deploy/';
        $scope.assetItems = null;
        $scope.formData = {
            groups: {},
            host_vars: []
        };

        $scope.groups = [];
        $scope.aceOption = {
            theme: 'monokai',
            mode: "yaml"
        };
        $scope.changeInventory = function () {
            $scope.formData.groups = {};
            $scope.groups = $scope.appData.groups[$scope.formData.inventory];
        };
        $scope.proxyChange = function () {
            if ($scope.formData.proxy) {
                $http({
                    method: 'GET',
                    err_title: "资产列表查询",
                    url: '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/proxy/' + $scope.formData.proxy.id + '/asset/?is_active=1&limit=all',
                    data: ''
                }).then(function successCallback(response) {
                    $scope.assetItems = response.data.results;
                });
            } else {
                $scope.assetItems = null;
            }
            for (var i in $scope.formData.groups) {
                $scope.formData.groups[i] = [];
            }
            $scope.formData.host_vars = [];
        }
        $scope.editHostVars = function (item) {
            var assetItems = get_groups_asset_objs() || [];
            var showAsset = [];
            assetItems.forEach(function (i) {
                var has_add = $scope.formData.host_vars.some(function (j) {
                    return i.id == j.asset.id && i.id != (item && item.asset.id);
                });
                if (!has_add) {
                    showAsset.push(i);
                }
            });
            if (true/*showAsset.length > 0*/) {
                var modalInstance = $modal.open({
                    templateUrl: 'tpl/host_vars_edit_modal.html',
                    controller: 'hostVarsEditModalController',
                    resolve: {
                        args: function () {
                            return {
                                assetItems: showAsset,
                                formData: angular.copy(item || {})
                            }
                        }
                    }
                });
                modalInstance.result.then(function (result) {
                    if (item) {
                        angular.extend(item, result);
                    }
                    else {
                        $scope.formData.host_vars.push(result);
                    }

                })
            }

        }
        $scope.delHostVars = function (item, event) {
            event.stopPropagation();
            for (var i in $scope.formData.host_vars) {
                var d = $scope.formData.host_vars[i];
                if (d === item) {
                    $scope.formData.host_vars.splice(i, 1);
                    break;
                }
            }
        }
        $scope.deploy = function () {
            var postData = {};
            postData.project = msLocalStorage.get("projectId");
            postData.proxy = $scope.formData.proxy.id;
            postData.application = $stateParams.id;
            postData.assets = get_asset_list();
            postData.groups = get_groups();
            postData.host_vars = get_host_vars();
            postData.group_vars = $scope.appData.group_vars;
            postData.inventory = $scope.formData['inventory'];
            postData.playbook = $scope.formData.playbook;
            console.log(postData);
            $http({
                method: "POST",
                err_title: "部署",
                url: $scope.deployURL,
                data: postData
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    var modalInstance = $modal.open({
                        templateUrl: 'tpl/apprun_process_modal.html',
                        controller: 'deployPlaybookModalCtrl',
                        size: 'batch-exec',
                        keyboard: false,
                        resolve: {
                            items: {
                                'proxy_id': response.data.proxy.id,
                                'ws_url': response.data.url
                            }
                        }
                    });

                    modalInstance.result.then(function (selectedItem) {
                        $scope.selected = selectedItem;
                    }, function () {
                        $log.info('关闭时间: ' + new Date());
                    });

                } else {
                    toaster.pop('error', '部署失败', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            });
        }
        init();
        function watchs() {
            $scope.$watch("formData.groups", function (newValue, oldValue) {
                if (JSON.stringify(newValue) != JSON.stringify(oldValue)) {
                    $scope.formData.host_vars = [];
                }
            }, true);
        }

        function init() {
            var init_funcs = [];
            init_funcs.push($http({
                method: 'GET',
                err_title: "代理列表查询",
                url: '/v1/proxy-manage/project/' + msLocalStorage.get("projectId") + '/proxy/?limit=all&ordering=proxy_name',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.proxyItems = response.data.results;
                }
            }));

            init_funcs.push($http({
                method: 'GET',
                err_title: "查询应用",
                url: '/v1/application/app/' + $stateParams.id + "/",
                data: ''
            }).then(function successCallback(response) {
                $scope.appData = response.data;
                $scope.appData.groups_list = [];
                for (var key in $scope.appData.groups) {
                    $scope.appData.groups_list.push(key);
                }

            }));

            $q.all(init_funcs).then(function () {
                setTimeout(function () {
                    if ($stateParams.deploy_id) {
                        $http({
                            method: 'GET',
                            err_title: "查询部署记录",
                            url: '/v1/application/project/' + msLocalStorage.get("projectId") + '/deploy/' + $stateParams.deploy_id + "/",
                            data: ''
                        }).then(function successCallback(deploy_response) {
                            $scope.formData.proxy = deploy_response.data.proxy;

                            $http({
                                method: 'GET',
                                err_title: "资产列表查询",
                                url: '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/proxy/' + $scope.formData.proxy.id + '/asset/?is_active=1&limit=all',
                            }).then(function successCallback(assets_response) {
                                $scope.assetItems = assets_response.data.results;
                                $scope.formData.inventory = deploy_response.data.inventory;
                                $scope.changeInventory();
                                $scope.formData.groups = {};
                                for (var group_key in deploy_response.data.groups) {
                                    var host_name_list = deploy_response.data.groups[group_key];
                                    var list = [];
                                    for (var index in host_name_list) {
                                        var host = host_name_list[index];
                                        var find = _($scope.assetItems).find(function (item) {
                                            return item.networking_g.hostname === host;
                                        });
                                        list.push(find)
                                    }
                                    $scope.formData.groups[group_key] = list;
                                }
                                $scope.appData.group_vars = deploy_response.data.group_vars;
                                $scope.formData.playbook = deploy_response.data.playbook;
                                $scope.formData.host_vars = [];
                                for (var host_key in deploy_response.data.host_vars) {
                                    var config = deploy_response.data.host_vars[host_key];
                                    var find = _($scope.assetItems).find(function (item) {
                                        return item.networking_g.hostname === host_key;
                                    });
                                    $scope.formData.host_vars.push({asset: find, config: config});
                                }
                                watchs();
                            })

                        })
                    }
                    else {
                        watchs();
                    }
                }, 200);

            })
        }


        function get_groups_asset_objs() {
            var map = {};
            for (var key in $scope.formData.groups) {
                var asseets = $scope.formData.groups[key];
                if (asseets) {
                    asseets.forEach(function (item) {

                        map[item.id] = item;
                    })
                }

            }
            var result = [];
            for (key in map) {
                result.push(map[key]);
            }
            return result;
        }

        function get_asset_list() {
            var map = {};
            for (var key in $scope.formData.groups) {
                var asseets = $scope.formData.groups[key];
                if (asseets) {
                    asseets.forEach(function (item) {

                        map[item.id] = "";
                    })
                }

            }
            var result = [];
            for (key in map) {
                result.push(key);
            }
            return result;
        }

        function get_groups() {
            var map = {};
            $scope.groups.forEach(function (key) {
                var asseets = $scope.formData.groups[key];
                var group = [];
                if (asseets) {
                    asseets.forEach(function (item) {
                        group.push(item.networking_g.hostname);
                    })
                }
                map[key] = group;
            });
            return map;
        }

        function get_host_vars() {
            var map = {};
            if ($scope.formData.host_vars) {
                $scope.formData.host_vars.forEach(function (item) {
                    map[item.asset.networking_g.hostname] = item.config;
                });
            }
            return map;
        }

    }]);

app.controller('hostVarsEditModalController', ['$rootScope', '$scope', '$http', '$state', '$modalInstance', 'args',
    function ($rootScope, $scope, $http, $state, $modalInstance, args) {
        $scope.formData = args.formData;
        $scope.assetItems = args.assetItems;
        $scope.aceOption = {
            theme: 'monokai',
            mode: "yaml"
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };

        $scope.ok = function () {
            $modalInstance.close($scope.formData);
        };

    }]
);

app.controller('deployPlaybookModalCtrl', ['$rootScope', '$scope', '$http', '$location', '$modalInstance', 'toaster', '$sce', 'msLocalStorage', 'items',
    function ($rootScope, $scope, $http, $location, $modalInstance, toaster, $sce, msLocalStorage, items) {
        var ws;
        var url = '/v1/proxy-manage/project/' + msLocalStorage.get("projectId") + '/proxy/' + items.proxy_id + '/';
        var ws_url = items.ws_url;

        $scope.disabled = true;

        $scope.deploy = function () {
            // 重新部署时，清空内容
            $('.batch-exec-msg').html("");
            $scope.disabled = true;

            function add_html(html) {
                $('.batch-exec-msg').append(html);
                $scope.$broadcast("scroll-bottom");
            }

            var protocol = '';
            if (window.location.protocol == 'https:') {
                protocol = 'wss:';
            } else {
                protocol = 'ws:';
            }
            var url_run = protocol + ws_url;

            if (window.WebSocket) {
                ws = new WebSocket(url_run);
            }
            else if (window.MozWebSocket) {
                ws = MozWebSocket(url_run);
            }
            else {
                add_html("浏览器不支持websocket");
                return;
            }
            ws.onopen = function (event) {
                console.log('WebSocket Opened');
                ws.send('start');
            }

            ws.onclose = function (event) {
                console.log('WebSocket Closed');
            }

            ws.onmessage = function (event) {
                if (event.data == "-end-") {
                    $scope.disabled = false;
                    return
                }
                var result_key = {
                    "ok:": "Chartreuse",
                    "skipping:": "RoyalBlue",
                    "inclueded:": "RoyalBlue",
                    "fatal:": "Red"
                };
                var color = undefined;
                for (var key in result_key) {
                    var t = event.data.slice(0, key.length);
                    if (t == key) {
                        color = result_key[key];
                        break
                    }
                }
                if (color == undefined) {
                    add_html(event.data.replace(/\n/g, "<br>"));
                } else {
                    add_html("<span style='color: " + color + "'>" + event.data.replace(/\n/g, "<br>") + "</span>\n")
                }
            }
        };

        $scope.deploy();

        $scope.ok = function () {
            $modalInstance.close($scope.items);
        };

        $scope.cancel = function () {
            ws.send('kill');
            $modalInstance.dismiss('cancel');
        };

        $scope.kill = function () {
            $scope.disabled = false;
            ws.send('stop');
        };

        $scope.redeploy = function () {
            $scope.disabled = true;
            $scope.deploy();
        };
    }]);