/**
 * Created by lidukang on 2016/11/3.
 * 已完成的
 */
'use strict';
app.controller('wokerFlowMyCompleteCtrl',  ['$rootScope', '$scope', '$http','msLocalStorage',
    function ($rootScope, $scope, $http,msLocalStorage) {
        $scope.listUrl = '/v1/workflow/project/' + msLocalStorage.get("projectId") + '/approve-complete/';
        $scope.table_options = new msTables.Option()
            .enableItemChecks(false)
            .enableSearch(true)
            .withFields(
                [{
                    key: "name",
                    title: "名称",
                    sort_key: "name",
                    can_hide: false
                }, {
                    key: 'create_user__username',
                    title: "创建者",
                    sort_key: "create_user__username"
                }, {
                    key: 'do_user__username',
                    title: "审批者",
                    sort_key: "do_user__username"
                },{
                    key: 'module',
                    title: "模块",
                    sort_key: "module"
                },{
                    key: 'status',
                    title: "状态",
                    sort_key: "status"
                },{
                    key: 'comment',
                    title: "批注",
                    can_hide: false
                },{
                    key:'create_time',
                    title: "创建时间",
                    sort_key: "create_time"
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                var url = $scope.listUrl + '?offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "已完成任务查询",
                    url: url,
                }).then(function (response) {
                    return response.data;
                })
            })
            .enableExternData(true, function (item) {
                return $scope.descriptionHtml(item);
            });

        $scope.descriptionHtml = function (data, type, full, meta) {
            var dd='';
            angular.forEach(data.kwargs, function (data, index, array) {
                dd+='<dd>'+data.key+':'+data.value+'</dd>'
            });
            return '<dl class="user-project"><dt>描述:</dt>'+dd+'</dl>';
        };
    }]);