/**
 * Created by lidukang on 2017/3/9.
 */
'use strict';
app.controller('emergencyMonitorController', ['$rootScope', '$scope', '$compile', '$state', '$http', '$modal', '$q', '$log', '$cookies', 'msLocalStorage', '$interval', 'toaster',
    function ($rootScope, $scope, $compile, $state, $http, $modal, $q, $log, $cookies, msLocalStorage, $interval, toaster) {
        $scope.listUrl = '/v1/open-falcon/project/' + msLocalStorage.get("projectId") + '/host-strategy/';
        var editBtnOpt = {
            text: '编辑',
            class: 'color-2',
            color: '#004740',
            action: function () {
                var items = $scope.table_options.getCheckedItems();
                $scope.editAlarm(items[0]);
            }
        };
        var deleteBtnOpt = {
            text: '删除',
            class: 'color-4',

            color: '#d2181c',
            action: function (e, dt, node, config) {
                var items = $scope.table_options.getCheckedItems();
                $scope.delAlarmMonitor(items);
            }
        };
        $scope.table_options = new msTables.Option()
            .withButtons([{
                hide: false,
                disable: false,
                text: '添加',

                class: 'color-1',
                color: '#2f5398',
                action: function (button) {
                    $state.go('app.newmonitor');
                }
            },
                editBtnOpt, deleteBtnOpt, {
                    text: '展示/隐藏',
                    extend: 'colvis',
                    class: 'color-0'
                }
            ])
            .setCheckedChangeFunc(function (items) {
                if (items.length == 1) {
                    editBtnOpt.disable = false;
                } else {
                    editBtnOpt.disable = true;
                }
                if (items.length > 0) {
                    deleteBtnOpt.disable = false;
                } else {
                    deleteBtnOpt.disable = true;
                }
            })
            .enableSearch(true)
            .withFields(
                [{
                    key: "name",
                    title: "名称",
                    sort_key: "name",
                    can_hide: false
                }, {
                    key: "creator__username",
                    title: "创建者",
                    sort_key: "creator__username",
                }, {
                    title: "监控资产",
                    sort_key: "assets",
                    html: function (item) {
                        var names = [];
                        if (item.assets) {
                            item.assets.forEach(function (i) {
                                names.push(i.name);
                            });
                        }
                        return names.join(",");
                    }
                }, {
                    title: "接收告警用户",
                    sort_key: "users",
                    html: function (item) {
                        var names = [];
                        if (item.users) {
                            item.users.forEach(function (i) {
                                names.push(i.username);
                            });
                        }
                        return names.join(",");
                    }
                }, {
                    title: "操作",
                    can_hide: false,
                    class: 'ms-table-operate',
                    html: function () {
                        return '<ms-ext-btn buttons="$ctrl.tabBtn" item="$item"/>';
                    }
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                var url = $scope.listUrl + '?offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "监控告警查询",
                    url: url,
                }).then(function (response) {
                    return response.data;
                })
            })
            .enableExternData(false, function (item) {
                // return $scope.advTaskConfigHtml(item);
            })
            .setCtrlInitFunc(function ($ctrl) {
                $ctrl.tabBtn = [
                    {
                        name: '编辑',
                        click: $scope.editAlarm,

                    },
                    {
                        name: '删除',
                        click: $scope.delAlarmMonitor,

                    }
                ];
            });

        /**
         * 新增、编辑监控告警
         * @param alarmId
         */
        $scope.editAlarm = function (item) {
            var id = item.id;
            $state.go('app.editmonitor', {id: id});
        };


        /**
         * 删除监控告警
         * @param alarmObj
         */
        $scope.delAlarmMonitor = function (alarmObj) {
            if (!(alarmObj instanceof Array)) {
                alarmObj = (alarmObj == null || alarmObj == "" ||
                typeof(alarmObj) == "undefined") ? [] : [alarmObj];
            }
            alarmObj = (alarmObj == null || alarmObj == "" ||
            typeof(alarmObj) == "undefined") ? [] : alarmObj;
            $scope.items = alarmObj;
            var modalInstance = $modal.open({
                templateUrl: 'delMonAlarmTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var defered_array = [];
                angular.forEach(selectedItem, function (data, index, array) {
                    defered_array.push($scope.deleteAlarmMonitor(data.id));
                });
                $q.all(defered_array).then(function () {
                    $scope.table_options.reload();//重新渲染表格
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
        /**
         * 删除监控告警
         * @param id
         */
        $scope.deleteAlarmMonitor = function (id) {
            var defer = $q.defer();
            $http({
                method: 'DELETE',
                err_title: "删除监控告警",
                url: $scope.listUrl + id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '删除监控告警', '删除成功');
                } else {
                    toaster.pop('error', '删除监控告警', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
                defer.resolve();
            }, function errorCallback(response) {
                defer.resolve();
            });
            return defer.promise;
        };
    }
]);

//新增编辑
app.controller('emergencyNewEditMonitorController', ['$rootScope', '$scope', '$compile', '$state', '$http', '$log', 'toaster', '$templateCache', 'msLocalStorage',
    function ($rootScope, $scope, $compile, $state, $http, $log, toaster, $templateCache, msLocalStorage) {
        $http({
            method: 'GET',
            err_title: "资产列表查询",
            url: '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/asset/?limit=all',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.assetItems = response.data.results;
            }
        });

        $http({
            method: 'GET',
            err_title: "任务查询",
            url: '/v1/task-tpl/project/' + msLocalStorage.get("projectId") + '/tasktpl/?limit=all',
            data: ''
        }).then(function successCallback(response) {
            $scope.taskTpls = response.data.results;
        });
        $http({
            method: 'GET',
            err_title: "监控告警列表查询",
            url: '/v1/alarm/project/' + msLocalStorage.get("projectId") + '/type/?limit=all',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.mediaTypeItems = response.data.results;
            }
        });
        $http({
            method: 'GET',
            err_title: "系统用户列表查询",
            url: '/v1/user-manage/project/' + msLocalStorage.get("projectId") + '/user/?limit=all',
            data: ''
        }).then(function successCallback(response) {
            $scope.users = response.data.results;
        });
        $http({
            method: 'GET',
            err_title: "查询告警参数",
            url: '/v1/open-falcon/counter/?limit=all',
            data: ''
        }).then(function successCallback(response) {
            $scope.counterItems = response.data.results;
        });
        $scope.newEditUrl = '/v1/buildbot/project/' + msLocalStorage.get("projectId") + '/config_builders/';
        $scope.newsCount = 0;
        $scope.policylist = [];//策略列表
        $scope.addBtnFlag = false;//增加按钮样式
        $scope.operators = [
            "==",
            "!=",
            "<",
            "<=",
            ">",
            ">="
        ];
        $scope.prioritys = [
            0, 1, 2, 3, 4, 5, 6
        ];
        if ($state.params.id) {
            $scope.title = '编辑监控告警规则';
            $http({
                method: 'GET',
                err_title: "监控告警查询",
                url: '/v1/open-falcon/project/' + msLocalStorage.get("projectId") + '/host-strategy/' + $state.params.id + "/",
                data: ''
            }).then(function successCallback(response) {
                $scope.alarmModel = response.data;
            });
        } else {
            $scope.title = '新增监控告警规则';
            $scope.alarmModel = {
                strategies: []
            };
        }
        $scope.createForm = function (type, dataObj) {
            if (type == 'edit') {
                $scope.newsModel = dataObj;
            }
            if (type == 'copy') {
                $scope.newsModel = angular.copy(dataObj);
            }
            if (type == 'new') {
                $scope.newsModel = {
                    func_name: 'all',
                    operator: '>',
                    max_step: 3,
                    func_step: 3,
                    priority: 0,
                };
            }
            if ($scope.newsModel.task_tpl) {
                $scope.taskTpls.forEach(function (item) {
                    if (item.id === $scope.newsModel.task_tpl.id) {
                        $scope.newsModel.task_tpl = item;
                    }
                })
            }

            $scope.show_items_edit = true;
        };

        $scope.deleteForm = function (dataObj) {
            angular.forEach($scope.alarmModel.strategies, function (data, index, array) {
                if (data === dataObj) {
                    $scope.alarmModel.strategies.splice(index, 1);
                }
            });
        };

        /**
         * 保存
         */
        $scope.saveCondition = function () {
            var int_field = ["max_step", "priority", "func_step"];
            int_field.forEach(function (i) {
                $scope.newsModel[i] = parseInt($scope.newsModel[i]);
            });

            var float_field = ["right_value"];
            float_field.forEach(function (i) {
                $scope.newsModel[i] = parseFloat($scope.newsModel[i]);
            });
            $scope.newsModel.node = $scope.newsModel.node || "";
            var find = false;
            $scope.alarmModel.strategies.some(function (data, index, array) {
                if (data === $scope.newsModel) {
                    find = true;
                    $scope.alarmModel[index] = $scope.newsModel;
                }
            });
            if (!find) {
                $scope.alarmModel.strategies.push($scope.newsModel);
            }
            $scope.addBtnFlag = false;
            $scope.show_items_edit = false;
        };
        $scope.conditionError = function () {
            var required_fields = ["metric", "max_step", "priority", "func_name", "func_step", "operator", "right_value"];
            return required_fields.some(function (field) {
                var value = $scope.newsModel[field];
                if (value === null || value === "" || value === undefined) {
                    return true;
                }
            });
        };
        $scope.submitForm = function () {
            var url = "/v1/open-falcon/project/" + msLocalStorage.get("projectId") + "/host-strategy/";
            if ($state.params.id) {
                $http({
                    method: 'PUT',
                    err_title: "编辑监控告警规则",
                    url: url + $state.params.id + "/",
                    data: $scope.alarmModel
                }).then(function successCallback(response) {
                    $state.go("app.emergency.monitor");
                });
            }
            else {
                $http({
                    method: 'POST',
                    err_title: "新建监控告警规则",
                    url: url,
                    data: $scope.alarmModel
                }).then(function successCallback(response) {
                    $state.go("app.emergency.monitor");
                });
            }

        };
    }
]);