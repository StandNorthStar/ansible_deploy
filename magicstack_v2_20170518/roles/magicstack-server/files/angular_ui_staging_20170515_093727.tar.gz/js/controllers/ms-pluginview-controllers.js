/**
 * 插件展示视图
 */
'use strict';
app.controller('pluginViewController', ['$rootScope', '$scope', '$stateParams', '$http', '$sce', function ($rootScope, $scope, $stateParams, $http, $sce) {
    $scope.pluginUrl = $sce.trustAsResourceUrl(decodeURIComponent($stateParams.url));
}]);