/**
 * Created by lidukang on 2016/11/15.
 * 插件管理
 */
'use strict';
app.controller('pluginManageModalCtrl', ['$rootScope', '$scope', '$http', '$modalInstance', '$timeout', 'toaster', 'msLocalStorage', 'items',
    function ($rootScope, $scope, $http, $modalInstance, $timeout, toaster, msLocalStorage, items) {
        $scope.pluginManageModel = {};
        if (!$.ms.isEmptyObject(items)) {
            $http({
                method: 'GET',
                err_title: "插件详情查询",
                url: '/v1/plugin-manage/project/' + msLocalStorage.get("projectId") + '/plugin/' + items.id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.pluginManageModel = response.data;
                    $scope.pluginManageModel.password = '';
                }
            });
        }

        $scope.ok = function () {
            $modalInstance.close($scope.pluginManageModel);
        };

        $scope.clear = function () {
            $scope.items = {};
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
app.controller('pluginmanageController', ['$rootScope', '$scope', '$http', '$state', '$modal', '$log', 'toaster', '$q', 'msLocalStorage',
    function ($rootScope, $scope, $http, $state, $modal, $log, toaster, $q, msLocalStorage) {
        $rootScope.app.settings.asideFolded = false;
        $scope.listUrl = '/v1/plugin-manage/project/' + msLocalStorage.get("projectId") + '/plugin/';
        var editBtnOpt = {
            text: '编辑',
            class: 'color-2',
            perm: "PLUGIN_EDIT_ACTION",
            color: '#004740',
            action: function () {
                var items = $scope.table_options.getCheckedItems();
                $scope.newEditPluginManage(items[0]);
            }
        };
        var deleteBtnOpt = {
            text: '删除',
            class: 'color-4',
            perm: "PLUGIN_DELETE_ACTION",
            color: '#d2181c',
            action: function (e, dt, node, config) {
                var items = $scope.table_options.getCheckedItems();
                $scope.delPluginManage(items);
            }
        };
        $scope.table_options = new msTables.Option()
            .withButtons([{
                hide: false,
                disable: false,
                text: '添加',
                class: 'color-1',
                perm: "PLUGIN_CREATE_ACTION",
                color: '#2f5398',
                action: function (button) {
                    $scope.newEditPluginManage('');
                }
            },
                editBtnOpt, deleteBtnOpt, {
                    text: '展示/隐藏',
                    extend: 'colvis',
                    perm: "",
                    class: 'color-0'
                }
            ])
            .setCheckedChangeFunc(function (items) {
                if (items.length == 1) {
                    editBtnOpt.disable = false;
                } else {
                    editBtnOpt.disable = true;
                }
                if (items.length > 0) {
                    deleteBtnOpt.disable = false;
                } else {
                    deleteBtnOpt.disable = true;
                }
            })
            .enableSearch(true)
            .withFields(
                [{
                    key: "name",
                    title: "插件名字",
                    sort_key: "name",
                    can_hide: false
                }, {
                    key: 'type',
                    title: '类型',
                    sort_key: 'type'
                }, {
                    key: 'protocol',
                    title: '接口协议',
                    sort_key: 'protocol'
                }, {
                    key: 'request_method',
                    title: '参数类型',
                    sort_key: 'request_method'
                }, {
                    key: 'domain_name',
                    title: '域名',
                    sort_key: 'domain_name'
                }, {
                    key: 'username',
                    title: "用户名",
                    sort_key: "username"
                }, {
                    title: "操作",
                    can_hide: false,
                    class: 'ms-table-operate',
                    html: function () {
                        return '<ms-ext-btn buttons="$ctrl.tabBtn" item="$item"/>';
                    }
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                var url = $scope.listUrl + '?offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "插件列表查询",
                    url: url,
                }).then(function (response) {
                    var relaod = false;
                    response.data.results.forEach(function (item) {
                        if (item.push_status == 1) {
                            relaod = true;
                        }
                    });
                    response.data.auto_reload = relaod;
                    return response.data;
                })
            })
            .enableExternData(false, function (item) {
                return "";
            })
            .setCtrlInitFunc(function ($ctrl) {
                $ctrl.tabBtn = [
                    {
                        name: '打开',
                        click: $scope.openPluginUrl,
                        perm: "PLUGIN_CONNECT_ACTION",
                    },
                    {
                        name: '编辑',
                        click: $scope.newEditPluginManage,
                        perm: "PLUGIN_EDIT_ACTION",
                    },
                    {
                        name: '删除',
                        click: $scope.delPluginManage,
                        perm: "PLUGIN_DELETE_ACTION",
                    }
                ];
            });

        /**
         * 新增、修改插件
         * @param pluginManageObj
         */
        $scope.newEditPluginManage = function (pluginManageObj) {
            $scope.items = (pluginManageObj == null || pluginManageObj == "" ||
            typeof(pluginManageObj) == "undefined") ? {} : pluginManageObj;
            var modalInstance = $modal.open({
                templateUrl: 'newEditPluginManageTpl',
                controller: 'pluginManageModalCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var method = "POST", url = $scope.listUrl;
                if (selectedItem.hasOwnProperty('id')) {
                    method = 'PUT';
                    url += selectedItem.id + '/';
                }
                $http({
                    method: method,
                    err_title: "创建或修改插件",
                    url: url,
                    data: selectedItem
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('success', '修改插件', '保存成功');
                        } else {
                            toaster.pop('success', '新增插件', '保存成功');
                        }
                        $scope.table_options.reload();//重新渲染表格
                    } else {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('error', '修改插件', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        } else {
                            toaster.pop('error', '新增插件', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        }
                    }
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         * 删除插件
         * @param pluginManageObj
         */
        $scope.delPluginManage = function (pluginManageObj) {
            if (!(pluginManageObj instanceof Array)) {
                pluginManageObj = (pluginManageObj == null || pluginManageObj == "" ||
                typeof(pluginManageObj) == "undefined") ? [] : [pluginManageObj];
            }
            pluginManageObj = (pluginManageObj == null || pluginManageObj == "" ||
            typeof(pluginManageObj) == "undefined") ? [] : pluginManageObj;
            $scope.items = pluginManageObj;
            var modalInstance = $modal.open({
                templateUrl: 'delPluginManageTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var defered_array = [];
                angular.forEach(selectedItem, function (data, index, array) {
                    defered_array.push($scope.deletePlugin(data.id));
                });
                $q.all(defered_array).then(function () {
                    $scope.table_options.reload();//重新渲染表格
                })

            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         * 删除插件
         * @param id
         */
        $scope.deletePlugin = function (id) {
            var defer = $q.defer();
            $http({
                method: 'DELETE',
                err_title: "删除插件",
                url: $scope.listUrl + id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '删除插件', '删除成功');
                } else {
                    toaster.pop('error', '删除插件', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
                defer.resolve();
            }, function errorCallback(response) {
                defer.resolve();
            });
            return defer.promise;
        };

        /**
         * 打开插件
         * @param pluginManageObj
         */
        $scope.openPluginUrl = function (pluginManageObj) {
            if (!$.ms.isEmptyObject(pluginManageObj)) {
                $http({
                    method: 'GET',
                    err_title: "打开插件",
                    url: $scope.listUrl + 'connect/' + pluginManageObj.id + '/',
                    data: ''
                }).then(function successCallback(response) {
                    if (response.data.results.url) {
                        $state.go('pluginView', {url: response.data.results.url});
                        // $state.go('app.pluginmanage.plugindetail',{url:response.data.results.url});
                    }
                    else {
                        toaster.pop('error', '打开插件', '无法获取插件地址', $rootScope.errorDwellTime);
                    }
                });
            }
        };
    }
]);

/**
 * 插件页面
 */
app.controller('pluginDetailController', ['$rootScope', '$scope', '$stateParams', '$http', '$sce', function ($rootScope, $scope, $stateParams, $http, $sce) {
    $scope.pluginUrl = $sce.trustAsResourceUrl(decodeURIComponent($stateParams.url));
    $rootScope.app.settings.asideFolded = true;
}]);