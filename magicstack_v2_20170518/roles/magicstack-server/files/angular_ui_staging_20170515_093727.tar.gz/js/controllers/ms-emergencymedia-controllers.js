/**
 * Created by lidukang on 2016/8/5.
 * 警告管理-警告媒介类型
 */
'use strict';
app.controller('alarmTypeModalCtrl', ['$rootScope', '$scope', '$http',
    'msLocalStorage', '$modalInstance', 'toaster', 'items',
    function ($rootScope, $scope, $http, msLocalStorage, $modalInstance, toaster, items, is_admin) {
        if (is_admin) {
            $scope.listUrl = '/v1/alarm/type/';
        }
        else {
            $scope.listUrl = '/v1/alarm/project/' + msLocalStorage.get("projectId") + '/type/';
        }
        $scope.alarmModel = {
            type: 'email',
            smtp_server_port: 25,
            email_use: 'tls',
            status: true
        };
        $scope.alarmTypeEmail = false;
        $scope.alarmTypeWeChat = false;
        $scope.alarmTypeSms = false;
        $scope.alarmTypePhone = false;
        if (!$.ms.isEmptyObject(items)) {
            $http({
                method: 'GET',
                err_title: "查询sudo",
                url: $scope.listUrl + items.id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.alarmModel = response.data;
                    $scope.alarmModel.type = $scope.CodeToType($scope.alarmModel.type);
                    if ($scope.alarmModel.email_use_ssl) {
                        $scope.alarmModel.email_use = 'ssl';
                    }
                    if ($scope.alarmModel.email_use_tls) {
                        $scope.alarmModel.email_use = 'tls';
                    }
                }
            });
        }

        /**
         * Code编码转换类型
         * @param code
         * @returns {string}
         */
        $scope.CodeToType = function (code) {
            var type = '';
            if (code == 1) {
                type = 'email';
            }
            if (code == 2) {
                type = 'wechat';
            }
            if (code == 3) {
                type = 'sms';
            }
            return type;
        };

        /**
         * 类型转换Code编码
         * @param type
         * @returns {string}
         */
        $scope.typeToCode = function (type) {
            var code = 0;
            if (type == 'email') {
                code = 1;
            }
            if (type == 'wechat') {
                code = 2;
            }
            if (type == 'sms') {
                code = 3;
            }
            return code;
        };

        $scope.$watch('alarmModel.type', function (newVal, oldVal) {
            if (newVal === 'email') {
                $scope.alarmTypeEmail = true;
                $scope.alarmTypeWeChat = false;
                $scope.alarmTypeSms = false;
                $scope.alarmTypePhone = false;
                delete $scope.alarmModel.corpid;
                delete $scope.alarmModel.corpsecret;
            }
            if (newVal === 'wechat') {
                $scope.alarmTypeEmail = false;
                $scope.alarmTypeWeChat = true;
                $scope.alarmTypeSms = false;
                $scope.alarmTypePhone = false;
                delete $scope.alarmModel.smtp_server;
                delete $scope.alarmModel.smtp_server_port;
                delete $scope.alarmModel.email_username;
                delete $scope.alarmModel.password;
                delete $scope.alarmModel.email_username;
                delete $scope.alarmModel.password;
            }
            if (newVal === 'sms') {
                $scope.alarmTypeEmail = false;
                $scope.alarmTypeWeChat = false;
                $scope.alarmTypeSms = true;
                $scope.alarmTypePhone = false;
            }
            if (newVal === 'phone') {
                $scope.alarmTypeEmail = false;
                $scope.alarmTypeWeChat = false;
                $scope.alarmTypeSms = false;
                $scope.alarmTypePhone = true;
            }
        }, true);

        $scope.clear = function () {
            $scope.alarmModel = {
                type: 'email',
                status: true
            }
        };

        $scope.ok = function () {
            if ($scope.alarmModel.type === 'email') {
                delete $scope.alarmModel.corpid;
                delete $scope.alarmModel.corpsecret;
            }
            if ($scope.alarmModel.type === 'wechat') {
                delete $scope.alarmModel.smtp_server;
                delete $scope.alarmModel.smtp_server_port;
                delete $scope.alarmModel.email_username;
                delete $scope.alarmModel.password;
                delete $scope.alarmModel.email_username;
                delete $scope.alarmModel.password;
            }

            $scope.alarmModel.type = $scope.typeToCode($scope.alarmModel.type);
            $modalInstance.close($scope.alarmModel);
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
app.controller('emergencymediaController', ['$rootScope', '$scope', '$compile', '$state', '$http', '$modal', '$q', '$log', '$cookies', 'msLocalStorage', '$interval', 'toaster', 'is_admin',
    function ($rootScope, $scope, $compile, $state, $http, $modal, $q, $log, $cookies, msLocalStorage, $interval, toaster, is_admin) {
        if (is_admin) {
            $scope.listUrl = '/v1/alarm/type/';
        }
        else {
            $scope.listUrl = '/v1/alarm/project/' + msLocalStorage.get("projectId") + '/type/';
        }
        var editBtnOpt = {
            text: '编辑',
            class: 'color-2',
            perm: "ALARM_TYPE_EDIT_ACTION",
            color: '#004740',
            action: function () {
                var items = $scope.table_options.getCheckedItems();
                $scope.newEditAlarmMedium(items[0]);
            }
        };
        var deleteBtnOpt = {
            text: '删除',
            class: 'color-4',
            perm: "ALARM_TYPE_DELETE_ACTION",
            color: '#d2181c',
            action: function (e, dt, node, config) {
                var items = $scope.table_options.getCheckedItems();
                $scope.delAlarm(items);
            }
        };
        $scope.table_options = new msTables.Option()
            .withButtons([{
                hide: false,
                disable: false,
                text: '添加',
                perm: "ALARM_TYPE_CREATE_ACTION",
                class: 'color-1',
                color: '#2f5398',
                action: function (button) {
                    $scope.newEditAlarmMedium('');
                }
            },
                editBtnOpt, deleteBtnOpt, {
                    text: '展示/隐藏',
                    extend: 'colvis',
                    perm: "",
                    class: 'color-0'
                }
            ])
            .setCheckedChangeFunc(function (items) {
                if (items.length == 1) {
                    editBtnOpt.disable = false;
                } else {
                    editBtnOpt.disable = true;
                }
                if (items.length > 0) {
                    deleteBtnOpt.disable = false;
                } else {
                    deleteBtnOpt.disable = true;
                }
            })
            .enableSearch(true)
            .withFields(
                [{
                    key: "name",
                    title: "名称",
                    sort_key: "name",
                    can_hide: false
                }, {
                    title: '类型',
                    sort_key: 'type',
                    html: function (item) {
                        var code = item.type;
                        var type = '';
                        if (code == 1) {
                            type = '电子邮件';
                        }
                        if (code == 2) {
                            type = '微信';
                        }
                        if (code == 3) {
                            type = '短信';
                        }
                        return type;
                    }
                }, {
                    key: "detail",
                    title: "详情",
                    sort_key: "detail"
                }, {
                    title: "启用状态",
                    sort_key: "status",
                    html: function (item) {
                        var status = item.status;
                        if (status) {
                            return '启用';
                        } else {
                            return '禁用';
                        }
                    }
                }, {
                    key: "comment",
                    title: "备注",
                    sort_key: "comment"
                }, {
                    title: "操作",
                    can_hide: false,
                    class: 'ms-table-operate',
                    html: function () {
                        return '<ms-ext-btn buttons="$ctrl.tabBtn" item="$item"/>';
                    }
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                var url = $scope.listUrl + '?offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "告警媒介类型查询",
                    url: url,
                }).then(function (response) {
                    return response.data;
                })
            })
            .enableExternData(false, function (item) {
                // return $scope.advTaskConfigHtml(item);
            })
            .setCtrlInitFunc(function ($ctrl) {
                $ctrl.tabBtn = [
                    {
                        name: '编辑',
                        click: $scope.newEditAlarmMedium,
                        perm: "ALARM_TYPE_EDIT_ACTION",
                    },
                    {
                        name: '测试',
                        click: $scope.testAlarm,
                    },
                    {
                        name: '删除',
                        click: $scope.delAlarm,
                        perm: "ALARM_TYPE_DELETE_ACTION",
                    },

                ];
            });

        /**
         * 新增、编辑告警媒介类型
         * @param alarmId
         */
        $scope.newEditAlarmMedium = function (alarmId) {
            $scope.items = (alarmId == null || alarmId == "" ||
            typeof(alarmId) == "undefined") ? {} : alarmId;
            var modalInstance = $modal.open({
                templateUrl: 'newEditAlarmMediumTpl',
                controller: 'alarmTypeModalCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    },
                    is_admin: function () {
                        return is_admin;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var method = "POST", url = $scope.listUrl;
                if (selectedItem.hasOwnProperty('id')) {
                    method = 'PUT';
                    url += selectedItem.id + '/';
                }
                $http({
                    method: method,
                    err_title: "创建或修改告警媒介类型",
                    url: url,
                    data: selectedItem
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('success', '修改告警媒介类型', '保存成功');
                        } else {
                            toaster.pop('success', '新增告警媒介类型', '保存成功');
                        }
                        $scope.table_options.reload();//重新渲染表格
                    } else {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('error', '修改告警媒介类型', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        } else {
                            toaster.pop('error', '新增告警媒介类型', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        }
                    }
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        $scope.testAlarm = function (alarmObj) {
            var url = $scope.listUrl + alarmObj.id + "/test/";
            $http({
                method: "GET",
                err_title: "告警媒介类型测试",
                url: url,
            }).then(function (response) {
                toaster.pop('success', '告警媒介类型测试', '测试成功');
            })
        };

        /**
         * 删除告警媒介类型
         * @param alarmObj
         */
        $scope.delAlarm = function (alarmObj) {
            if (!(alarmObj instanceof Array)) {
                alarmObj = (alarmObj == null || alarmObj == "" ||
                typeof(alarmObj) == "undefined") ? [] : [alarmObj];
            }
            alarmObj = (alarmObj == null || alarmObj == "" ||
            typeof(alarmObj) == "undefined") ? [] : alarmObj;
            $scope.items = alarmObj;
            var modalInstance = $modal.open({
                templateUrl: 'delAlarmTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var defered_array = [];
                angular.forEach(selectedItem, function (data, index, array) {
                    defered_array.push($scope.deleteAlarm(data.id));
                });
                $q.all(defered_array).then(function () {
                    $scope.table_options.reload();//重新渲染表格
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
        /**
         * 删除告警媒介类型
         * @param id
         */
        $scope.deleteAlarm = function (id) {
            var defer = $q.defer();
            $http({
                method: 'DELETE',
                err_title: "删除告警媒介类型",
                url: $scope.listUrl + id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '删除告警媒介类型', '删除成功');
                } else {
                    toaster.pop('error', '删除告警媒介类型', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
                defer.resolve();
            }, function errorCallback(response) {
                defer.resolve();
            });
            return defer.promise;
        };
    }
]);