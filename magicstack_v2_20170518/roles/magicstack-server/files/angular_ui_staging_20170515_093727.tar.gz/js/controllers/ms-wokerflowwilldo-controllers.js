/**
 * Created by 李杜康 on 2016/11/3.
 * 待处理的
 */
'use strict';
app.controller('wokerFlowWillDoCtrl', ['$rootScope', '$scope', '$http', 'msLocalStorage','$modal', '$log', 'toaster', '$q',
    function ($rootScope, $scope, $http, msLocalStorage, $modal, $log, toaster,$q) {
        $scope.listUrl = '/v1/workflow/project/' + msLocalStorage.get("projectId") + '/approve-will-do/';
        $scope.table_options = new msTables.Option()
            .enableItemChecks(false)
            .enableSearch(true)
            .withFields(
                [{
                    key: "name",
                    title: "名称",
                    sort_key: "name",
                    can_hide: false
                }, {
                    key: 'create_user__username',
                    title: "创建者",
                    sort_key: "create_user__username"
                }, {
                    key: 'do_user__username',
                    title: "审批者",
                    sort_key: "do_user__username"
                },{
                    key: 'module',
                    title: "模块",
                    sort_key: "module"
                },{
                    key: 'status',
                    title: "状态",
                    sort_key:'status'
                },{
                    key: 'create_time',
                    title: "创建时间",
                    sort_key:'create_time'
                },{
                    title: "操作",
                    can_hide: false,
                    class:'ms-table-operate',
                    html: function () {
                        return '<div class="btn-group dropdown">' +
                            '<button class="btn btn-primary borderradius0">高级</button>' +
                            '<button class="btn btn-primary" data-toggle="dropdown"><span class="caret"></span></button>' +
                            '<ul class="dropdown-menu">' +
                            '<li><a ng-click="$ctrl.willDoPass($item)">通过</a></li>' +
                            '<li><a ng-click="$ctrl.willDoReject($item)">拒绝</a></li>' +
                            '</ul></div>';
                    }
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                var url = $scope.listUrl + '?offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "待处理的任务查询",
                    url: url,
                }).then(function (response) {
                    return response.data;
                })
            })
            .enableExternData(true, function (item) {
                return $scope.descriptionHtml(item);
            })
            .setCtrlInitFunc(function ($ctrl) {
                $ctrl.willDoPass = $scope.willDoPass;
                $ctrl.batchExecution = $scope.batchExecution;
                $ctrl.willDoReject = $scope.willDoReject;
            });

        $scope.descriptionHtml = function (data, type, full, meta) {
            var dd = '';
            angular.forEach(data.kwargs, function (data, index, array) {
                dd += '<dd>' + data.key + ':' + data.value + '</dd>'
            });
            return '<dl class="user-project"><dt>描述:</dt>' + dd + '</dl>';
        };

        function approvePass(item) {
            var defer = $q.defer();
            var url = '/v1/workflow/project/' + msLocalStorage.get("projectId") + '/approve/' + item.id + "/pass/";
            $http({
                method: 'POST',
                err_title:'通过审批',
                url: url,
                data: {comment: item.comment}
            }).then(function successCallback(response) {
                toaster.pop('success', '通过审批成功');
                defer.resolve();
            }, function errorCallback(response) {
                defer.resolve();
            });
            return defer.promise;
        }

        /**
         * 通过
         * @param willDoObj
         */
        $scope.willDoPass = function (willDoObj) {
            $scope.items = (willDoObj == null || willDoObj == "" ||
            typeof(willDoObj) == "undefined") ? {} : willDoObj;
            var modalInstance = $modal.open({
                templateUrl: 'willDoPassTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                approvePass(selectedItem).then(function () {
                    $scope.table_options.reload();//重新渲染表格
                });

            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         *
         * @param item
         * @returns {*|promise.promise|jQuery.promise|promise|d.promise|Promise}
         */
        function approveReject(item) {
            var defer = $q.defer();
            var url = '/v1/workflow/project/' + msLocalStorage.get("projectId") + '/approve/' + item.id + "/reject/";
            $http({
                method: 'POST',
                err_title:'拒绝审批',
                url: url,
                data: {comment: item.comment}
            }).then(function successCallback(response) {
                toaster.pop('success', '拒绝审批成功');
                defer.resolve();
            }, function errorCallback(response) {
                defer.resolve();
            });
            return defer.promise;
        }

        /**
         * 拒绝
         * @param willDoObj
         */
        $scope.willDoReject = function (willDoObj) {
            $scope.items = (willDoObj == null || willDoObj == "" ||
            typeof(willDoObj) == "undefined") ? {} : willDoObj;
            var modalInstance = $modal.open({
                templateUrl: 'willDoRejectTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                approveReject(selectedItem).then(function () {
                    $scope.table_options.reload();//重新渲染表格
                });

            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

    }]);