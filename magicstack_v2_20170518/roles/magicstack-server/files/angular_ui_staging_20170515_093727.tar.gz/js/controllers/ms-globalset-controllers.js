/**
 * Created by lidukang on 2016/8/5.
 * 全局设置
 */
'use strict';
app.controller('globalsetController',['$rootScope','$scope', '$filter', '$http', 'editableOptions', 'editableThemes',
    function ($rootScope,$scope, $filter, $http, editableOptions, editableThemes) {
        editableThemes.bs3.inputClass = 'input-sm';
        editableThemes.bs3.buttonsClass = 'btn-sm';
        editableOptions.theme = 'bs3';

        $scope.alarmTimes = [
            {value: 1, text: '全部'},
            {value: 2, text: '工作日'},
            {value: 3, text: '周末'}
        ];

        $scope.alarmTimeShowStatus = function (user) {
            var selected = [];
            if (user && user.alarmTime) {
                selected = $filter('filter')($scope.alarmTimes, {value: user.alarmTime});
            }
            return selected.length ? selected[0].text : '暂无';
        };

        $scope.jurisdictions = [
            {value: 0, text: '添加'},
            {value: 1, text: '修改'},
            {value: 2, text: '删除'}
        ];

        $scope.jurisdictionShowStatus=function(user) {
            var selected = [];
            angular.forEach($scope.jurisdictions, function(jur) {
                if (user.jurisdiction.indexOf(jur.value) >= 0) {
                    selected.push(jur.text);
                }
            });
            return selected.length ? selected.join(', ') : '暂无';
        };

        $scope.alarmStatuses = [
            {value: 1, text: '启用'},
            {value: 2, text: '禁用'}
        ];

        $scope.alarmStatusShowStatus = function (user) {
            var selected = [];
            if (user && user.alarmStatus) {
                selected = $filter('filter')($scope.alarmStatuses, {value: user.alarmStatus});
            }
            return selected.length ? selected[0].text : '暂无';
        };


        // editable table
        $scope.users = [
            {id: 1,content:'用户变更',
                jurisdiction:[0,1,2], name: '张三', alarmTime: 2,alarmStatus:1, group: 4, groupName: '微信'},
            {id: 2,content:'资产变更',
                jurisdiction:[0,1], name: '李四', alarmTime: -1,alarmStatus:2, group: 3, groupName: '短信'},
            {id: 3,content:'应用变更',
                jurisdiction:[1,2], name: '王五', alarmTime: 2,alarmStatus:2, group: '微信'},
            {id: 4,content:'任务变更',
                jurisdiction:[0,2], name: '赵红', alarmTime: 2,alarmStatus:1, group: 4, groupName: '电话'},
            {id: 5,content:'备份变更',
                jurisdiction:[], name: '王刚', alarmTime: -1,alarmStatus:1, group: 3, groupName: '邮件'}
        ];

        $scope.showStatus = function () {
            var selected = $filter('filter')($scope.alarmTimes, {value: $scope.user.alarmTime});
            return ($scope.user.alarmTime && selected.length) ? selected[0].text : '暂无';
        };

        $scope.showAgenda = function () {
            var selected = $filter('filter')($scope.agenda, {value: $scope.user.agenda});
            return ($scope.user.agenda && selected.length) ? selected[0].text : '暂无';
        };

        $scope.groups = [];
        $scope.loadGroups = function () {
            return $scope.groups.length ? null : $http.get('data/groups').success(function (data) {
                $scope.groups = data;
            });
        };

        $scope.showGroup = function (user) {
            if (user.group && $scope.groups.length) {
                var selected = $filter('filter')($scope.groups, {id: user.group});
                return selected.length ? selected[0].text : '暂无';
            } else {
                return user.groupName || '暂无';
            }
        };
        $scope.checkName = function (data, id) {
            if (id === 2 && data !== 'awesome') {
                return "Username 2 should be `awesome`";
            }
        };

        $scope.saveUser = function (data, id) {
            //$scope.user not updated yet
            angular.extend(data, {id: id});
            // return $http.post('api/saveUser', data);
        };

        // remove user
        $scope.removeUser = function (index) {
            $scope.users.splice(index, 1);
        };

        // add user
        $scope.addUser = function () {
            $scope.inserted = {
                id: $scope.users.length + 1,
                name: '',
                status: null,
                group: null
            };
            $scope.users.push($scope.inserted);
        };

        $scope.addCloum = function () {
            $scope.clum = {}
        };

    }]);
