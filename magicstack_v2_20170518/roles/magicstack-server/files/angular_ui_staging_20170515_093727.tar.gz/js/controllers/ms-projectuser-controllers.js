/**
 * Created by lidukang on 2016/8/5.
 * 用户列表
 */
'use strict';
/***
 * 模态框控制器
 */
app.controller('userModalCtrl', ['$rootScope', '$scope', '$http', '$modalInstance', '$timeout', 'toaster', 'items', 'ldapauth_type',
    function ($rootScope, $scope, $http, $modalInstance, $timeout, toaster, items, ldapauth_type) {
        $scope.ldapauth_type = ldapauth_type;
        if (!$.ms.isEmptyObject(items)) {
            $http({
                method: 'GET',
                err_title: "用户列表查询",
                url: '/v1/user-manage/user/' + items.id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.userModel = response.data;
                }
            });
        } else {
            $scope.userModel = {
                is_active: true,
                projects: []
            };
        }

        $scope.projectItems = [];
        $scope.roleItems = [];

        $http({
            method: 'GET',
            err_title: "项目列表查询",
            url: '/v1/permissions/project/?limit=all&ordering=name',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.projectItems = response.data.results;
            }
        });

        $http({
            method: 'GET',
            err_title: "角色列表查询",
            url: '/v1/permissions/role/?limit=all&ordering=name',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.roleItems = response.data.results;
            }
        });

        /**
         * 添加
         */
        $scope.saveProject = function () {
            if ($scope.userModel.projects.length > 0) {
                angular.forEach($scope.userModel.projects, function (data, index, array) {
                    if (data.id === $scope.userModel.project.id) {
                        $scope.userModel.projects.splice(index, 1);
                    }
                });
            }
            if ($scope.userModel.role) {
                var tempProject = [], tempRole = [];
                delete $scope.userModel.project.$$hashKey;
                tempProject = $scope.userModel.project;
                angular.forEach($scope.userModel.role, function (data, index, array) {
                    delete $scope.userModel.role[index].$$hashKey;
                    tempRole.push(data);
                });
                tempProject.roles = tempRole;
                $scope.userModel.projects.push(tempProject);
                $scope.userModel.project = {};
                $scope.userModel.role = [];
            } else {
                toaster.pop('error', '新增用户角色', '添加失败原因:为用户添加项目时角色不允许为空', $rootScope.errorDwellTime);
                return;
            }
        };

        $scope.$watch('userModel.projectlist', function (newVal, oldVal) {
            if (!$.ms.isEmptyObject(newVal)) {
                var reverseTempRole = newVal.roles;
                // delete newVal.roles;
                $scope.userModel.project = newVal;
                $scope.userModel.role = reverseTempRole;
            }
        });

        /**
         * 删除
         */
        $scope.delProject = function () {
            if ($scope.userModel.projects.length > 0) {
                angular.forEach($scope.userModel.projects, function (data, index, array) {
                    if (data.id === $scope.userModel.projectlist.id) {
                        $scope.userModel.projects.splice(index, 1);
                    }
                });
                if ($scope.userModel.projects.length > 0) {
                    $scope.userModel.projectlist = $scope.userModel.projects[0];
                }
            }
        };

        $scope.clearUser = function () {
            $scope.userModel = {};
            $scope.confirmpwd = '';
        };

        $scope.ok = function () {
            if (true || $scope.userModel.is_superuser || $scope.userModel.projectlist) {
                $modalInstance.close($scope.userModel);
            } else {
                toaster.pop('error', '新增用户', '失败原因:请至少为用户添加一个项目', $rootScope.errorDwellTime);
            }
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);

app.controller('userRoleModalCtrl', ['$rootScope', '$scope', '$http', '$modalInstance', '$timeout', 'toaster', 'items', 'msLocalStorage',
    function ($rootScope, $scope, $http, $modalInstance, $timeout, toaster, items, msLocalStorage) {
        if (!$.ms.isEmptyObject(items)) {
            $http({
                method: 'GET',
                err_title: "用户列表查询",
                url: '/v1/user-manage/project/' + msLocalStorage.get("projectId") + '/user/' + items.id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.userModel = response.data;
                }
            });
        }
        $scope.roleItems = [];
        $http({
            method: 'GET',
            err_title: "角色列表查询",
            url: '/v1/permissions/role/?limit=all&ordering=name',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.roleItems = response.data.results;
            }
        });

        $scope.clearUser = function () {
            $scope.userModel = {};
            $scope.confirmpwd = '';
        };

        $scope.ok = function () {
            $modalInstance.close($scope.userModel);
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
app.controller('userlistController', ['$rootScope', '$scope', '$compile', '$state', '$http', '$modal', '$log', '$q', 'toaster', 'msLocalStorage', 'ldapauth_type', 'is_admin',
    function ($rootScope, $scope, $compile, $state, $http, $modal, $log, $q, toaster, msLocalStorage, ldapauth_type, is_admin) {
        if (is_admin) {
            $scope.listUrl = '/v1/user-manage/user/';
        } else {
            $scope.listUrl = '/v1/user-manage/project/' + msLocalStorage.get("projectId") + '/user/';
        }

        var editBtnOpt = {
            text: '编辑',
            class: 'color-2',
            perm: "USER_EDIT_ACTION",
            color: '#004740',
            action: function () {
                var items = $scope.table_options.getCheckedItems();
                roleUser(items[0]);
            }
        };
        var deleteBtnOpt = {
            text: '删除',
            class: 'color-4',
            hide: ldapauth_type,
            perm: "USER_DELETE_ACTION",
            color: '#d2181c',
            action: function (e, dt, node, config) {
                var items = $scope.table_options.getCheckedItems();
                $scope.delUser(items);
            }
        };

        function get_top_buttons() {
            if (is_admin) {
                return [{
                    hide: ldapauth_type,
                    disable: false,
                    text: '添加',
                    perm: "USER_CREATE_ACTION",
                    class: 'color-1',
                    color: '#2f5398',
                    action: function (button) {
                        $scope.newEditUserOpen('');
                    }
                },
                    editBtnOpt, deleteBtnOpt, {
                        text: '展示/隐藏',
                        perm: "",
                        extend: 'colvis',
                        class: 'color-0'
                    }
                ];
            }
            else {
                return [editBtnOpt,
                    {
                        text: '展示/隐藏',
                        perm: "",
                        extend: 'colvis',
                        class: 'color-0'
                    }
                ];
            }
        }

        $scope.table_options = new msTables.Option()
            .withButtons(get_top_buttons())
            .setCheckedChangeFunc(function (items) {
                if (items.length == 1) {
                    editBtnOpt.disable = false;
                } else {
                    editBtnOpt.disable = true;
                }
                if (items.length > 0) {
                    deleteBtnOpt.disable = false;
                } else {
                    deleteBtnOpt.disable = true;
                }
            })
            .enableSearch(true)
            .withFields(
                [{
                    key: "username",
                    title: "用户名",
                    sort_key: "username",
                    can_hide: false
                }, {
                    title: "激活",
                    sort_key: "is_active",
                    html: function (item) {
                        return item.is_active ? '已激活' : '未激活';
                    }
                }, {
                    key: "date_joined",
                    title: "创建时间",
                    sort_key: "date_joined"
                }, {
                    title: "操作",
                    can_hide: false,
                    class: 'ms-table-operate',
                    html: function () {
                        return '<ms-ext-btn buttons="$ctrl.tabBtn" item="$item"/>';
                    }
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                var url = $scope.listUrl + '?offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "用户查询",
                    url: url,
                }).then(function (response) {
                    return response.data;
                })
                //这里是ajax请求
            })
            // .enableExternData(true, function (item) {
            //     if (is_admin) {
            //         return $scope.projectHtml(item);
            //     } else {
            //         return $scope.roleHtml(item);
            //     }
            //
            // })
            .setCtrlInitFunc(function ($ctrl) {
                if (ldapauth_type) {
                    $ctrl.tabBtn = [
                        {
                            name: '查看详情',
                            click: $scope.userDetails,
                            perm: "",
                        },
                        {
                            name: '编辑',
                            click: roleUser,
                            perm: "USER_EDIT_ACTION"
                        }
                    ];

                } else {
                    if (is_admin) {
                        $ctrl.tabBtn = [
                            {
                                name: '查看详情',
                                click: $scope.userDetails,
                                perm: "",
                            },
                            {
                                name: '编辑',
                                click: roleUser,
                                perm: "USER_EDIT_ACTION"
                            },
                            {
                                name: '删除',
                                click: $scope.delUser,
                                perm: "USER_DELETE_ACTION",
                            }
                        ];
                    }
                    else {
                        $ctrl.tabBtn = [
                            {
                                name: '查看详情',
                                click: $scope.userDetails,
                                perm: "",
                            },
                            {
                                name: '编辑',
                                click: roleUser,
                                perm: "USER_EDIT_ACTION"
                            }

                        ];
                    }

                }

            });

        function roleUser(item) {
            if (is_admin) {
                $scope.newEditUserOpen(item);
            } else {
                $scope.roleEditUserOpen(item);
            }
        }

        $scope.projectHtml = function (data, type, full, meta) {
            var html = '', dt = '', dd = '';
            angular.forEach(data.projects, function (projectData, projectIndex, projectArray) {
                dt = '';
                dd = '';
                dt = '<dt>项目:' + projectData.name + '</dt>';
                angular.forEach(projectData.roles, function (roleData, roleIndex, roleArray) {
                    dd += '<dd>' + roleData.name + '</dd>'
                });
                html += '<dl class="user-project">' + dt + '<dd>角色:</dd>' + dd + '</dl>';
            });
            return html;
        };
        /**
         *
         * @param data
         * @param type
         * @param full
         * @param meta
         * @returns {string}
         */
        $scope.roleHtml = function (data, type, full, meta) {
            var html = '', dd = '';
            angular.forEach(data.roles, function (data, index, array) {
                dd += '<dd>' + data.name + '</dd>';
            });
            html += '<dl class="user-project"><dt>角色</dt>' + dd + '</dl>';
            return html;
        };


        /**
         * 新增、编辑用户
         * @param userObj
         */
        $scope.newEditUserOpen = function (userObj) {
            $scope.items = (userObj == null || userObj == "" ||
            typeof(userObj) == "undefined") ? {} : userObj;
            var modalInstance = $modal.open({
                templateUrl: 'newEditUserTpl',
                controller: 'userModalCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    },
                    ldapauth_type: ldapauth_type
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var method = "POST", url = $scope.listUrl;
                if (selectedItem.hasOwnProperty('id')) {
                    method = 'PUT';
                    url += selectedItem.id + '/';
                }
                $http({
                    method: method,
                    err_title: "创建或修改用户",
                    url: url,
                    data: {
                        username: selectedItem.username,
                        password: selectedItem.password,
                        email: selectedItem.email,
                        projects: selectedItem.projects,
                        is_superuser: selectedItem.is_superuser,
                        is_active: selectedItem.is_active,
                        is_send_mail: selectedItem.is_send_mail
                    }
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('success', '修改用户', '保存成功');
                        } else {
                            toaster.pop('success', '新增用户', '保存成功');
                        }
                        $scope.table_options.reload();//重新渲染表格
                    } else {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('error', '修改用户', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        } else {
                            toaster.pop('error', '新增用户', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        }
                    }
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         * 权限编辑用户
         * @param userObj
         */
        $scope.roleEditUserOpen = function (userObj) {
            $scope.items = (userObj == null || userObj == "" ||
            typeof(userObj) == "undefined") ? {} : userObj;
            var modalInstance = $modal.open({
                templateUrl: 'roleEditUserTpl',
                controller: 'userRoleModalCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                $http({
                    method: 'PUT',
                    err_title: "创建或修改用户",
                    url: $scope.listUrl + selectedItem.id + '/',
                    data: {
                        roles: selectedItem.roles
                    }
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        toaster.pop('success', '修改用户', '保存成功');
                        $scope.table_options.reload();//重新渲染表格
                    } else {
                        toaster.pop('error', '修改用户', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                    }
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         * 删除用户
         * @param userObj
         */
        $scope.delUser = function (userObj) {
            if (!(userObj instanceof Array)) {
                userObj = (userObj == null || userObj == "" ||
                typeof(userObj) == "undefined") ? [] : [userObj];
            }
            userObj = (userObj == null || userObj == "" ||
            typeof(userObj) == "undefined") ? [] : userObj;
            $scope.items = userObj;
            var modalInstance = $modal.open({
                templateUrl: 'delUserTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var defered_array = [];
                angular.forEach(selectedItem, function (data, index, array) {
                    defered_array.push($scope.deleteUser(data.id));
                });
                $q.all(defered_array).then(function () {
                    $scope.table_options.reload();//重新渲染表格
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         * 删除用户
         * @param id
         */
        $scope.deleteUser = function (id) {
            var defer = $q.defer();
            $http({
                method: 'DELETE',
                err_title: "删除用户",
                url: $scope.listUrl + id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '删除用户', '删除成功');
                } else {
                    toaster.pop('error', '删除用户', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
                defer.resolve();
            }, function errorCallback(response) {
                defer.resolve();
            });
            return defer.promise;
        };

        /**
         * 用户详情
         * @param userObj
         */
        $scope.userDetails = function (userObj) {
            $scope.items = (userObj == null || userObj == "" ||
            typeof(userObj) == "undefined") ? {} : userObj;
            var modalInstance = $modal.open({
                templateUrl: 'userDetailsTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                console.log(selectedItem);
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
    }
]);