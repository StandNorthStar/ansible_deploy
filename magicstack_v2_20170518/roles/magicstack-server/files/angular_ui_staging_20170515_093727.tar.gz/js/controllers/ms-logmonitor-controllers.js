/**
 * Created by dukang on 2017/3/16.
 */
'use strict';
app.controller('logMonitorController', ['$rootScope', '$scope', '$http', 'msLocalStorage', 'msPlayback',
    function ($rootScope, $scope, $http, msLocalStorage, msPlayback) {
        $scope.listUrl = '/v1/open-falcon/project/' + msLocalStorage.get("projectId") + '/alarm/';

        $scope.table_options = new msTables.Option()
            .enableItemChecks(false)
            .enableSearch(false)
            .withFields(
                [{
                    title: "资产名称",
                    sort_key: "name",
                    can_hide: false,
                    html: function (item) {
                        return item.asset.name;
                    }
                }, {
                    key: 'metric',
                    title: "指标",
                    sort_key: "metric"
                }, {
                    key: 'event_time',
                    title: "告警时间",
                    sort_key: "event_time"
                }, {
                    key: 'note',
                    title: "说明",
                    sort_key: "note"
                }, {
                    key: 'priority',
                    title: "级别",
                    sort_key: "priority"

                }, {
                    title: "条件",
                    html: function (item) {
                        return item.func + item.operator + item.right_value;
                    }
                }, {
                    title: "当前值",
                    sort_key: "left_value",
                    html: function (item) {
                        return item.left_value.toFixed(2)
                    }

                }, {
                    title: "操作",
                    can_hide: false,
                    class: 'ms-table-operate',
                    html: function () {
                        return '<ms-ext-btn ng-if="$item.task_id" buttons="$ctrl.tabBtn" item="$item"/>';
                    }
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                var url = $scope.listUrl + '?offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "我创建的任务列表查询",
                    url: url,
                }).then(function (response) {
                    return response.data;
                })
            })
            .enableExternData(true, function (item) {
                return $scope.descriptionHtml(item);
            })
            .setCtrlInitFunc(function ($ctrl) {
                $ctrl.tabBtn = [

                    {
                        name: '回放',
                        click: $scope.playback,
                        perm: ""
                    }
                ];
            });

        $scope.descriptionHtml = function (data, type, full, meta) {
            var dd = '';
            angular.forEach(data.kwargs, function (data, index, array) {
                dd += '<dd>' + data.key + ':' + data.value + '</dd>'
            });
            return '<dl class="user-project"><dt>描述:</dt>' + dd + '</dl>';
        };

        $scope.playback = function (lmObject) {
            console.log(lmObject);
            $http({
                method: "GET",
                url: '/v1/open-falcon/project/' + msLocalStorage.get("projectId") + '/alarm-task/' + lmObject.task_id + '/replay'
            }).then(function successCallback(response) {
                msPlayback({data: response.data});

            }, function errorCallback(response) {

            });
        }
    }]);