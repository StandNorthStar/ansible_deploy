/**
 * Created by lidukang on 2016/10/11.
 * 文件下载
 */
'use strict';
app.controller('filedownloadController', ['$rootScope', '$scope', '$http', '$state',
    'msLocalStorage', '$modal', '$log', 'toaster',
    function ($rootScope, $scope, $http, $state,
              msLocalStorage, $modal, $log, toaster) {
        $scope.fileDownloadModel = {};
        $http({
            method: 'GET',
            err_title: "代理列表查询",
            url: '/v1/proxy-manage/project/' + msLocalStorage.get("projectId") + '/proxy/?limit=all&ordering=proxy_name',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.proxyItems = response.data.results;
            }
        });

        /**
         * 获取资产列表
         */
        $scope.$watch('fileDownloadModel.proxy', function (newVal, oldVal) {
            if (newVal) {
                $http({
                    method: 'GET',
                    err_title: "代理列表查询",
                    url: '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/proxy/' + newVal.id + '/asset/?limit=all',
                    data: ''
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        $scope.assetItems = response.data.results;
                    }
                });
            }
            else {
                $scope.assetItems = [];
            }
        }, true);

        $scope.downloadFile = function () {
            var data = {
                path: $scope.fileDownloadModel.path,
                proxy_id: $scope.fileDownloadModel.proxy.id,
                asset_id: $scope.fileDownloadModel.asset.id
            };
            $http({
                method: 'POST',
                err_title: "获取下载地址",
                url: '/v1/file/project/' + msLocalStorage.get("projectId") + '/download/',
                data: data
            }).then(function successCallback(response) {
                window.open(response.data.link, '_self', 'toolbar=no, location=no,resizable=no,copyhistory=yes, scrollbars=no');
            });
        }
    }]);