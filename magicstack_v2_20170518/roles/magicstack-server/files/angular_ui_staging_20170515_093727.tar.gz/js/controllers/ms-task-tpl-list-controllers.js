/**
 * Created by lidukang on 2016/8/5.
 * 任务管理-常规任务
 */
'use strict';

app.controller('taskTplModalCtrl', ['$rootScope', '$scope', '$http', '$q','$modalInstance',
    'msLocalStorage', '$timeout', 'toaster', 'items',
    function ($rootScope, $scope, $http, $q, $modalInstance, msLocalStorage, $timeout, toaster, items) {
        /**
         * 类型
         */
        $http({
            method: 'GET',
            err_title: "查询任务类型",
            url: '/v1/task/module/',
            data: ''
        }).then(function successCallback(response) {
            $scope.taskTypeModal = _(response.data.results).groupBy('group_name');
            $scope.taskGroupArray = [];
            for (var taskGroup in $scope.taskTypeModal) {
                $scope.taskGroupArray.push(taskGroup);
            }
        });

        /**
         * 根据组查询类型
         */
        $scope.$watch('taskModal.taskTypeGroup', function (newVal, oldVal) {
            if (newVal) {
                for (var taskGroup in $scope.taskTypeModal) {
                    if (taskGroup == newVal) {
                        $scope.taskModuleArray = $scope.taskTypeModal[newVal];
                        return;
                    }
                }
            }
        }, true);

        $scope.assetsFlag = true;
        if (!$.ms.isEmptyObject(items)) {
            $http({
                method: 'GET',
                err_title: "查询任务",
                url: '/v1/task-tpl/project/' + msLocalStorage.get("projectId") + '/common-tasktpl/' + items.id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.taskModal = response.data;
                    $scope.taskModal.taskTypeGroup = $scope.taskModal.module.group_name;
                    $scope.taskModal.module = $scope.taskModal.module.module_name;
                }
            });
        } else {
            $scope.taskModal = {
                trigger_kwargs: {}
            };
        };

        $scope.ok = function () {
            delete $scope.taskModal.taskTypeGroup;
            $modalInstance.close($scope.taskModal);
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }
]);
app.controller('tasklistTplController', ['$rootScope', '$scope', '$compile', '$state', '$http', '$modal', '$q', '$log',
    'msLocalStorage', '$interval', 'toaster',
    function ($rootScope, $scope, $compile, $state, $http, $modal, $q, $log,
              msLocalStorage, $interval, toaster) {
        var editBtnOpt = {
            text: '编辑',
            class: 'color-2',
            perm: "",
            color: '#004740',
            action: function () {
                var items = $scope.table_options.getCheckedItems();
                $scope.newEditTaskTpl(items[0]);
            }
        };
        var deleteBtnOpt = {
            text: '删除',
            class: 'color-4',
            perm: "",
            color: '#d2181c',
            action: function (e, dt, node, config) {
                var items = $scope.table_options.getCheckedItems();
                $scope.delTaskTpl(items);
            }
        };
        $scope.table_options = new msTables.Option()
            .withButtons([{
                hide: false,
                disable: false,
                text: '添加',
                perm: "",
                class: 'color-1',
                color: '#2f5398',
                action: function (button) {
                    $scope.newEditTaskTpl('');
                }
            },
                editBtnOpt, deleteBtnOpt, {
                    text: '展示/隐藏',
                    extend: 'colvis',
                    perm: "",
                    class: 'color-0'
                }
            ])
            .setCheckedChangeFunc(function (items) {
                if (items.length == 1) {
                    editBtnOpt.disable = false;
                } else {
                    editBtnOpt.disable = true;
                }
                if (items.length > 0) {
                    deleteBtnOpt.disable = false;
                } else {
                    deleteBtnOpt.disable = true;
                }
            })
            .enableSearch(true)
            .withFields(
                [{
                    key: "name",
                    title: "任务名称",
                    sort_key: "name",
                    can_hide: false
                },{
                    title: "模块名称",
                    sort_key: "module__module_name",
                    html: function (item) {
                        return item.module.module_name;
                    }
                }, {
                    title: "操作",
                    can_hide: false,
                    class: 'ms-table-operate',
                    html: function () {
                        return '<ms-ext-btn buttons="$ctrl.tabBtn" item="$item"/>';
                    }
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {

                var url = '/v1/task-tpl/project/' + msLocalStorage.get("projectId") + '/common-tasktpl/?offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "查询任务列表",
                    url: url,
                }).then(function (response) {
                    var relaod = false;
                    response.data.results.forEach(function (item) {
                        if (item.job_next_run_time || item.last_exec_status == 'running') {
                            relaod = true;
                        }
                    });
                    response.data.auto_reload = relaod;
                    return response.data;
                })
            })
            .enableExternData(false, function (item) {
                // return $scope.taskConfigHtml(item);
            })
            .setCtrlInitFunc(function ($ctrl) {
                $ctrl.tabBtn = [
                    {
                        name: '编辑',
                        click: $scope.newEditTaskTpl,
                        perm: "",
                    },
                    {
                        name: '删除',
                        click: $scope.delTaskTpl,
                        perm: "",
                    }
                ];
            });

        /**
         * 新增、修改任务模版
         * @param taskId
         */
        $scope.newEditTaskTpl = function (taskId) {
            $scope.items = (taskId == null || taskId == "" ||
            typeof(taskId) == "undefined") ? {} : taskId;
            var modalInstance = $modal.open({
                templateUrl: 'taskListTplTpl',
                controller: 'taskTplModalCtrl',
                size: 'lg',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var method = "POST",
                    url = '/v1/task-tpl/project/' + msLocalStorage.get("projectId") + '/common-tasktpl/';
                if (selectedItem.hasOwnProperty('id')) {
                    method = 'PUT';
                    url += selectedItem.id + '/';

                    var trigger_flag = true;
                    for (var key in selectedItem.trigger_kwargs) {
                        if(key !== 'start_date' && key !== 'end_date') {
                            if(selectedItem.trigger_kwargs[key] !== '') {
                                trigger_flag = false;
                                break;
                            }
                        }
                    }
                    if(trigger_flag) {
                        toaster.pop('error', '修改任务', '保存失败原因: 触发器至少需要添加一项');
                        return;
                    }

                }


                $http({
                    method: method,
                    err_title: "创建或修改任务模版",
                    url: url,
                    data: selectedItem
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('success', '修改任务', '保存成功');
                        } else {
                            toaster.pop('success', '新增任务', '保存成功');
                        }
                        $scope.table_options.reload();
                    } else {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('error', '修改任务', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        } else {
                            toaster.pop('error', '新增任务', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        }
                    }
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
        /**
         * 删除任务模版
         * @param taskObj
         */
        $scope.delTaskTpl = function (taskObj) {
            if (!(taskObj instanceof Array)) {
                taskObj = (taskObj == null || taskObj == "" ||
                typeof(taskObj) == "undefined") ? [] : [taskObj];
            }
            taskObj = (taskObj == null || taskObj == "" ||
            typeof(taskObj) == "undefined") ? [] : taskObj;
            $scope.items = taskObj;
            var modalInstance = $modal.open({
                templateUrl: 'delTaskTplTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var defered_array = [];
                angular.forEach(selectedItem, function (data, index, array) {
                    defered_array.push($scope.deleteTaskTpl(data.id));
                });
                $q.all(defered_array).then(function() {
                    $scope.table_options.reload();
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
        /**
         * 删除任务模版
         * @param id
         */
        $scope.deleteTaskTpl = function (id) {
            var defer = $q.defer();
            $http({
                method: 'DELETE',
                err_title: "删除任务模版",
                url: '/v1/task-tpl/project/' + msLocalStorage.get("projectId") + '/common-tasktpl/' + id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '删除任务模版', '删除成功');
                } else {
                    toaster.pop('error', '删除任务模版', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
                defer.resolve();
            }, function errorCallback(response) {
                defer.resolve();
            });
            return defer.promise;
        };
    }
]);
