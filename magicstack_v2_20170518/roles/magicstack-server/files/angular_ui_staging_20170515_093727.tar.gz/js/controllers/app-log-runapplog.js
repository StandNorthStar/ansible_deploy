'use strict';
app.controller('apprunLogController', ['$rootScope', '$scope', '$http', 'msLocalStorage', '$modal', '$log', 'toaster', '$state',
    function ($rootScope, $scope, $http, msLocalStorage, $modal, $log, toaster, $state) {
        //project/(?P<project_id>[\w\-]+)/deploy/
        $scope.listUrl = '/v1/application/project/' + msLocalStorage.get("projectId") + '/deploy/';
        $scope.table_options = new msTables.Option()
            .setCheckedChangeFunc(function (items) {

            })
            .enableItemChecks(false)
            .enableSearch(true)
            .withFields(
                [{
                    key: "application__desc",
                    title: "应用",
                    sort_key: "application__desc",
                    can_hide: false
                }, {
                    key: "proxy__proxy_name",
                    title: "代理",
                    sort_key: "proxy__proxy_name",

                }, {
                    key: "create_time",
                    title: "部署时间",
                    sort_key: "create_time",

                }, {
                    title: "操作",
                    can_hide: false,
                    class: 'ms-table-operate',
                    html: function () {
                        return '<ms-ext-btn buttons="$ctrl.tabBtn" item="$item"/>';
                    }
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                var url = $scope.listUrl + '?offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "资产列表查询",
                    url: url,
                }).then(function (response) {
                    return response.data;
                })
            })
            .setCtrlInitFunc(function ($ctrl) {
                $ctrl.tabBtn = [
                    {
                        name: '查看日志',
                        click: $scope.assetLogs,
                        perm: ""
                    },
                    {
                        name: '再次部署',
                        click: $scope.deploy_again,
                        perm: ""
                    }
                ];
            });

        $scope.assetLogs = function (item) {


            $modal.open({
                templateUrl: 'tpl/apprun_log_modal.html',
                controller: 'apprunLogModalCtrl',
                size: 'batch-exec',
                keyboard: false,
                resolve: {
                    items: item
                }
            });
        };
        $scope.deploy_again = function (item) {
            $state.go("app.apprun", {id: item.application.id, deploy_id: item.id});
        }
    }]);

app.controller('apprunLogModalCtrl', ['$rootScope', '$scope', '$http', '$location', '$modalInstance', 'toaster', '$sce', 'msLocalStorage', 'items',
    function ($rootScope, $scope, $http, $location, $modalInstance, toaster, $sce, msLocalStorage, items) {
        var ws;
        var url = '/v1/application/project/' + msLocalStorage.get("projectId") + '/deploy/' + items.id + "/";

        function main() {
            $http({
                method: "GET",
                err_title: "连接失败",
                url: url
            }).then(function successCallback(response) {
                console.log(response.data);
                var result = response.data.result;
                if (result) {

                    var result_key = {
                        "ok:": "Chartreuse",
                        "skipping:": "RoyalBlue",
                        "inclueded:": "RoyalBlue",
                        "fatal:": "Red"
                    };
                    var lines = result.split("\n");
                    for (var line_index in lines) {
                        var line = lines[line_index];
                        var color = null;
                        for (var key in result_key) {
                            var t = line.slice(0, key.length);
                            if (t == key) {
                                color = result_key[key];
                                break
                            }
                        }
                        lines[line_index] = {
                            text: line,
                            color: color
                        };
                    }
                    $scope.lines = lines;

                }


            });
        }

        $scope.ok = function () {
            $modalInstance.close($scope.items);
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };

        main();
    }]);
