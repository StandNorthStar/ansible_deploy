/**
 * Created by 李杜康 on 2016/12/2.
 * ldap设置
 */
'use strict';
app.controller('certificationSetController', ['$rootScope','$scope','$state','$http','toaster',
    function($rootScope,$scope,$state,$http,toaster) {
        $scope.authType = 'default';
        $http({
            method: 'GET',
            err_title: "查询LDAP",
            url: '/v1/global-settings/ldap/list/',
            data: ''
        }).then(function successCallback(response) {
            $scope.ldapModal=response.data.results[0];
            if($scope.ldapModal.ldap_auth){
                $scope.authType = 'ldap';
            }
        });

        /**
         * 认证更新
         */
        $scope.updateLDAP=function () {
            var update='/v1/global-settings/ldap/update/';
            if($scope.authType=='default'){
                authFun(update,{authType:$scope.authType},'认证更新');
            }
            if($scope.authType=='ldap'){
                $scope.ldapModal.authType=$scope.authType;
                authFun(update,$scope.ldapModal,'认证更新');
            }
        };

        /**
         * 认证ajax方法调用
         * @param url
         * @param data
         * @param err_title
         */
        function authFun(url,data,err_title) {
            $http({
                method: 'POST',
                err_title: err_title,
                url: url,
                data: data
            }).then(function successCallback(response) {
                toaster.pop('success', err_title, '执行成功');
            });
        }

        /**
         * 测试LDAP
         */
        $scope.testLDAP=function () {
            authFun('/v1/global-settings/ldap/test/',$scope.ldapModal,'测试LDAP');
        };

    }
]);