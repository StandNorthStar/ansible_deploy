/**
 * Created by lidukang on 2016/8/5.
 * 任务管理-常规任务
 */
'use strict';
app.controller('taskModalCtrl', ['$rootScope', '$scope', '$http', '$q','$modalInstance',
    'msLocalStorage', '$timeout', 'toaster', 'items',
    function ($rootScope, $scope, $http, $q, $modalInstance, msLocalStorage, $timeout, toaster, items) {
        /**
         * 类型
         */
        $http({
            method: 'GET',
            err_title: "查询任务类型",
            url: '/v1/task/module/',
            data: ''
        }).then(function successCallback(response) {
            $scope.taskTypeModal = _(response.data.results).groupBy('group_name');
            $scope.taskGroupArray = [];
            for (var taskGroup in $scope.taskTypeModal) {
                $scope.taskGroupArray.push(taskGroup);
            }
        });

        /**
         * 根据组查询类型
         */
        $scope.$watch('taskModal.taskTypeGroup', function (newVal, oldVal) {
            if (newVal) {
                for (var taskGroup in $scope.taskTypeModal) {
                    if (taskGroup == newVal) {
                        $scope.taskModuleArray = $scope.taskTypeModal[newVal];
                        return;
                    }
                }
            }
        }, true);

        $scope.assetsFlag = true;
        if (!$.ms.isEmptyObject(items)) {
            $http({
                method: 'GET',
                err_title: "查询任务",
                url: '/v1/task/project/' + msLocalStorage.get("projectId") + '/common-task/' + items.id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.taskModal = response.data;
                    $scope.taskModal.taskTypeGroup = $scope.taskModal.module.group_name;
                    $scope.taskModal.module = $scope.taskModal.module.module_name;
                    $scope.taskModal.assetNames = '';
                    angular.forEach($scope.taskModal.assets, function (data, index, array) {
                        if ($scope.taskModal.assetNames) {
                            $scope.taskModal.assetNames += ',' + data.name;
                        } else {
                            $scope.taskModal.assetNames = data.name;
                        }
                    });
                }
            });
        } else {
            $scope.taskModal = {
                trigger_kwargs: {}
            };
        }
        $scope.taskTypeModal = {};

        /**
         * 代理
         */
        $http({
            method: 'GET',
            err_title: "代理列表查询",
            url: '/v1/proxy-manage/project/' + msLocalStorage.get("projectId") + '/proxy/?limit=all',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.proxyItems = response.data.results;
            }
        });

        /**
         * 监听任务主机
         */
        $scope.$watch('taskModal.assets', function (newVal, oldVal) {
            if (newVal) {
                $scope.assetsFlag = false;
            }
        }, true);

        /**
         * 获取资产列表
         */
        $scope.$watch('taskModal.proxy', function (newVal, oldVal) {
            if (!$.ms.isEmptyObject(newVal)) {
                $http({
                    method: 'GET',
                    err_title: "资产列表查询",
                    url: '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/proxy/' + newVal.id + '/asset/?is_active=1&limit=all',
                    data: ''
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        $scope.assetItems = response.data.results;
                    }
                });
            }
        }, true);

        $scope.ok = function () {
            delete $scope.taskModal.taskTypeGroup;
            $modalInstance.close($scope.taskModal);
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }
]);
app.controller('tasklistController', ['$rootScope', '$scope', '$compile', '$state', '$http', '$modal', '$q', '$log',
    'msLocalStorage', '$interval', 'toaster',
    function ($rootScope, $scope, $compile, $state, $http, $modal, $q, $log,
              msLocalStorage, $interval, toaster) {
        var editBtnOpt = {
            text: '编辑',
            class: 'color-2',
            perm: "TASK_COMMON_EDIT_ACTION",
            color: '#004740',
            action: function () {
                var items = $scope.table_options.getCheckedItems();
                $scope.newEditTask(items[0]);
            }
        };
        var deleteBtnOpt = {
            text: '删除',
            class: 'color-4',
            perm: "TASK_COMMON_DELETE_ACTION",
            color: '#d2181c',
            action: function (e, dt, node, config) {
                var items = $scope.table_options.getCheckedItems();
                $scope.delTask(items);
            }
        };
        $scope.table_options = new msTables.Option()
            .withButtons([{
                hide: false,
                disable: false,
                text: '添加',
                perm: "TASK_COMMON_CREATE_ACTION",
                class: 'color-1',
                color: '#2f5398',
                action: function (button) {
                    $scope.newEditTask('');
                }
            },
                editBtnOpt, deleteBtnOpt, {
                    text: '展示/隐藏',
                    extend: 'colvis',
                    perm: "",
                    class: 'color-0'
                }
            ])
            .setCheckedChangeFunc(function (items) {
                if (items.length == 1) {
                    editBtnOpt.disable = false;
                } else {
                    editBtnOpt.disable = true;
                }
                if (items.length > 0) {
                    deleteBtnOpt.disable = false;
                } else {
                    deleteBtnOpt.disable = true;
                }
            })
            .enableSearch(true)
            .withFields(
                [{
                    key: "name",
                    title: "任务名称",
                    sort_key: "name",
                    can_hide: false
                }, {
                    title: "代理名称",
                    sort_key: "proxy__proxy_name",
                    html: function (item) {
                        return item.proxy.proxy_name;
                    }
                }, {
                    title: "模块名称",
                    sort_key: "module__module_name",
                    html: function (item) {
                        return item.module.module_name;
                    }
                }, {
                    key: "last_exec_time",
                    title: "最后执行时间",
                    sort_key: "last_exec_time"
                }, {
                    title: "执行状态",
                    sort_key: "last_exec_status",
                    html: function (item) {
                        return $.ms.complyStatusConversion(item.last_exec_status);
                    }
                }, {
                    title: "任务状态",
                    sort_key: "approve_status,status",
                    html: function (item) {
                        var statusText = '';
                        if (item.approve_status == 0) {
                            if (item.status == 1) {
                                statusText = '启用';
                            } else if (item.status == 0) {
                                statusText = '禁用';
                            }
                        }
                        else if (item.approve_status == 1) {
                            statusText = '审批中';
                        }
                        else if (item.approve_status == 2) {
                            statusText = '审批拒绝';
                        }
                        return statusText;
                    }
                }, {
                    key: "comment",
                    title: "备注",
                    sort_key: "comment"
                }, {
                    title: "操作",
                    can_hide: false,
                    class: 'ms-table-operate',
                    html: function () {
                        return '<ms-ext-btn buttons="$ctrl.tabBtn" item="$item"/>';
                    }
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {

                var url = '/v1/task/project/' + msLocalStorage.get("projectId") + '/common-task/?offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "查询任务列表",
                    url: url,
                }).then(function (response) {
                    var relaod = false;
                    response.data.results.forEach(function (item) {
                        if (item.job_next_run_time || item.last_exec_status == 'running') {
                            relaod = true;
                        }
                    });
                    response.data.auto_reload = relaod;
                    return response.data;
                })
            })
            .enableExternData(true, function (item) {
                return $scope.taskConfigHtml(item);
            })
            .setCtrlInitFunc(function ($ctrl) {
                $ctrl.tabBtn = [
                    {
                        name: '查看明细',
                        click: $scope.execDetails,
                        perm: "TASK_COMMON_EXEC_INFO_QUERY",
                    },
                    {
                        name: '编辑',
                        click: $scope.newEditTask,
                        perm: "TASK_COMMON_EDIT_ACTION",
                    },
                    {
                        name: '禁用',
                        click: $scope.pauseTask,
                        perm: "TASK_COMMON_PAUSE_ACTION",
                        display: "$item.status == 1"
                    },
                    {
                        name: '启用',
                        click: $scope.resumeTask,
                        perm: "TASK_COMMON_RESUME_ACTION",
                        display: "$item.status == 0"
                    },
                    {
                        name: '删除',
                        click: $scope.delTask,
                        perm: "TASK_COMMON_DELETE_ACTION",
                    }
                ];
            });

        $scope.taskConfigHtml = function (data, type, full, meta) {
            var dd = '';
            if (data.trigger_kwargs.hasOwnProperty('start_date')) {
                dd += '<dd>开始时间:' + data.trigger_kwargs.start_date + '</dd>';
            }
            if (data.trigger_kwargs.hasOwnProperty('end_date')) {
                dd += '<dd>结束时间:' + data.trigger_kwargs.end_date + '</dd>';
            }
            if (data.trigger_kwargs.hasOwnProperty('month')) {
                dd += '<dd>月:' + data.trigger_kwargs.month + '</dd>';
            }
            if (data.trigger_kwargs.hasOwnProperty('day')) {
                dd += '<dd>日:' + data.trigger_kwargs.day + '</dd>';
            }
            if (data.trigger_kwargs.hasOwnProperty('week')) {
                dd += '<dd>星期:' + data.trigger_kwargs.week + '</dd>';
            }
            if (data.trigger_kwargs.hasOwnProperty('day_of_week')) {
                dd += '<dd>周第几天:' + data.trigger_kwargs.day_of_week + '</dd>';
            }
            if (data.trigger_kwargs.hasOwnProperty('hour')) {
                dd += '<dd>时:' + data.trigger_kwargs.hour + '</dd>';
            }
            if (data.trigger_kwargs.hasOwnProperty('minute')) {
                dd += '<dd>分:' + data.trigger_kwargs.minute + '</dd>';
            }
            return '<dl class="user-project"><dt>任务配置:</dt>' + dd + '</dl>';
        };


        /**
         * 自动刷新
         */
        // $interval(function () {
        //     $scope.dtInstance.rerender();//重新渲染表格
        // },$rootScope.autoRefreshTime);

        function compareObject(o1, o2) {
            if (typeof o1 != typeof o2) return false;
            if (typeof o1 == 'object') {
                for (var o in o1) {
                    if (typeof o2[o] == 'undefined') return false;
                    if (!compareObject(o1[o], o2[o])) return false;
                }
                return true;
            } else {
                return o1 === o2;
            }
        };
        /**
         * 新增、修改任务
         * @param taskId
         */
        $scope.newEditTask = function (taskId) {
            $scope.items = (taskId == null || taskId == "" ||
            typeof(taskId) == "undefined") ? {} : taskId;
            var modalInstance = $modal.open({
                templateUrl: 'taskListTpl',
                controller: 'taskModalCtrl',
                size: 'lg',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var method = "POST",
                    url = '/v1/task/project/' + msLocalStorage.get("projectId") + '/common-task/';
                if (selectedItem.hasOwnProperty('id')) {
                    method = 'PUT';
                    url += selectedItem.id + '/';

                    var trigger_flag = true;
                    for (var key in selectedItem.trigger_kwargs) {
                        if(key !== 'start_date' && key !== 'end_date') {
                            if(selectedItem.trigger_kwargs[key] !== '') {
                                trigger_flag = false;
                                break;
                            }
                        }
                    }
                    if(trigger_flag) {
                        toaster.pop('error', '修改任务', '保存失败原因: 触发器至少需要添加一项');
                        return;
                    }

                }


                $http({
                    method: method,
                    err_title: "创建或修改任务",
                    url: url,
                    data: selectedItem
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('success', '修改任务', '保存成功');
                        } else {
                            toaster.pop('success', '新增任务', '保存成功');
                        }
                        $scope.table_options.reload();
                    } else {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('error', '修改任务', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        } else {
                            toaster.pop('error', '新增任务', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        }
                    }
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
        /**
         * 删除任务
         * @param taskObj
         */
        $scope.delTask = function (taskObj) {
            if (!(taskObj instanceof Array)) {
                taskObj = (taskObj == null || taskObj == "" ||
                typeof(taskObj) == "undefined") ? [] : [taskObj];
            }
            taskObj = (taskObj == null || taskObj == "" ||
            typeof(taskObj) == "undefined") ? [] : taskObj;
            $scope.items = taskObj;
            var modalInstance = $modal.open({
                templateUrl: 'delTaskTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var defered_array = [];
                angular.forEach(selectedItem, function (data, index, array) {
                    defered_array.push($scope.deleteTask(data.id));
                });
                $q.all(defered_array).then(function() {
                    $scope.table_options.reload();
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
        /**
         * 删除任务
         * @param id
         */
        $scope.deleteTask = function (id) {
            var defer = $q.defer();
            $http({
                method: 'DELETE',
                err_title: "删除任务",
                url: '/v1/task/project/' + msLocalStorage.get("projectId") + '/common-task/' + id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '删除任务', '删除成功');
                } else {
                    toaster.pop('error', '删除任务', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
                defer.resolve();
            }, function errorCallback(response) {
                defer.resolve();
            });
            return defer.promise;
        };

        $scope.execDetails = function (obj) {
            $scope.items = obj || {};
            var modalInstance = $modal.open({
                templateUrl: 'executionDetailsTpl',
                controller: 'taskExecModalCtrl',
                size: 'lg',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                $scope.selected = selectedItem;
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         * 启用任务
         * @param taskObj
         */
        $scope.resumeTask = function (taskObj) {
            $scope.disabledTask(taskObj.id, true);
        };

        /**
         * 禁用任务
         * @param taskObj
         */
        $scope.pauseTask = function (taskObj) {
            $scope.disabledTask(taskObj.id, false);
        };

        /**
         * 禁用/启用任务
         */
        $scope.disabledTask = function (id, enable) {
            var action, action_str;
            if (enable) {
                action = "resume";
                action_str = "启用任务";
            } else {
                action = "pause";
                action_str = "禁用任务";
            }
            $http({
                method: 'POST',
                err_title: action_str,
                url: '/v1/task/project/' + msLocalStorage.get("projectId") + '/common-task/' + id + '/action/',
                data: {
                    action: action
                }
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.table_options.reload();
                    toaster.pop('success', action_str, action_str + '成功');
                } else {
                    toaster.pop('error', action_str, '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            });
        }
    }
]);
app.controller('taskExecModalCtrl', ['$rootScope', '$scope', '$modal', '$http', '$modalInstance',
    'msLocalStorage', '$timeout', 'toaster', 'items','msPlayback',
    function ($rootScope, $scope, $modal, $http, $modalInstance,
              msLocalStorage, $timeout, toaster, items, msPlayback) {
        //分页
        $scope.taskExecPagination = {
            taskExecMaxSize: 5,
            taskExecTotalItems: 0,
            taskExecCurrentPage: 1
        };
        $scope.taskExecTableModal = {};

        $scope.selectTaskExec = function (offset) {
            var url = '/v1/task/project/' + msLocalStorage.get("projectId") + '/common-task/' + items.id + '/execinfo/';
            if (offset !== 0) {
                offset = offset + '0';
            }
            url += '?offset=' + offset + '&limit=10';
            $http({
                method: 'GET',
                err_title: '任务执行明细',
                url: url,
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.taskExecPagination.taskExecTotalItems = response.data.count;
                    $scope.taskExecTableModal = response.data.results;
                } else {
                    toaster.pop('error', '任务执行明细错误', response.data.message, $rootScope.errorDwellTime);
                }
            });
        };

        $scope.$watch('taskExecPagination.taskExecCurrentPage', function (newVal, oldVal) {
            if (!$.ms.isEmptyObject(items)) {
                if (newVal && newVal > -1) {
                    $scope.taskExecPagination.taskExecCurrentPage = newVal;
                    $scope.selectTaskExec((newVal - 1));
                }
            }
        }, true);


        $scope.ok = function () {
            $modalInstance.close($scope.items);
        };

        $scope.replay = function (obj) {
            obj = angular.copy(obj);
            obj.task_id = items.id;
            $modalInstance.close($scope.items);

            $http({
                method: 'GET',
                err_title: '获取回放信息',
                url: '/v1/task/project/' + msLocalStorage.get("projectId") + '/common-task/' + obj.task_id + '/replay/' + obj.id
            }).then(function successCallback(response) {
                msPlayback({data: response.data});
            });
        };

        $scope.clear = function () {
            $scope.items = {};
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }
]);
