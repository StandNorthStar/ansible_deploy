/**
 * Created by lidukang on 2016/8/5.
 * 日志审计-
 */
'use strict';
app.controller('historyCountModalCtrl', ['$rootScope', 'msLocalStorage', '$scope', '$http', '$modalInstance', '$timeout', 'toaster', 'items',
    function ($rootScope, msLocalStorage, $scope, $http, $modalInstance, $timeout, toaster, items) {
        $scope.items = items;
        if (!$.ms.isEmptyObject($scope.items)) {
            $http({
                method: 'GET',
                err_title: "命令统计查询",
                url: '/v1/log/project/' + msLocalStorage.get("projectId") + '/connect-log/' + $scope.items.id + '/history/',
                data: ''
            }).then(function successCallback(response) {
                $scope.data = response.data;
            });
        }

        $scope.ok = function () {
            $modalInstance.close($scope.items);
        };

        $scope.clear = function () {
            $scope.items = {};
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
app.controller('logOnLineController', ['$rootScope', '$scope', '$http', 'msLocalStorage', '$modal', '$log', 'toaster',
    function ($rootScope, $scope, $http, msLocalStorage, $modal, $log, toaster) {
        $scope.limit = 10;

        /**
         * select联想查询
         * @param user
         * @returns {*}
         */
        $scope.refreshUser = function (user) {
            return $http({
                method: 'GET',
                err_title: "用户列表查询",
                url: '/v1/user-manage/user/?limit=all&search=' + user,
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.userItems = response.data.results;
                }
            });
        };
        /*******************************************在线Begin**************************************/
        //在线分页
        $scope.onlinePagination = {
            onlineMaxSize: 5,
            onlineTotalItems: 0,
            onlineCurrentPage: 1
        };
        $scope.onlineTableModal = {};
        $scope.onlineInquire = {};
        $scope.clearOnline = function () {
            $scope.onlineInquire = {};
            $scope.onlineSelect($scope.onlinePagination.onlineCurrentPage - 1);
        };

        $scope.inquireOnline = function () {
            $scope.onlineSelect($scope.onlinePagination.onlineCurrentPage - 1);
        };

        $scope.$watch('onlinePagination.onlineCurrentPage', function (newVal, oldVal) {
            if (newVal && newVal > -1) {
                $scope.onlinePagination.onlineCurrentPage = newVal;
                $scope.onlineSelect((newVal - 1));
            }
        }, true);

        $scope.onlineSelect = function (offset) {
            var url = '/v1/log/project/' + msLocalStorage.get("projectId") + '/online-connect/';
            if (offset !== 0) {
                offset = offset + '0';
            }
            url += '?offset=' + offset + '&limit=' + $scope.limit;
            if ($scope.onlineInquire.hasOwnProperty('user')) {
                url += '&search=' + $scope.onlineInquire.user;
            }
            $http({
                method: "GET",
                err_title: "查询在线",
                url: url,
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.onlinePagination.onlineTotalItems = response.data.count;
                    $scope.onlineTableModal = response.data.results;
                } else {
                    toaster.pop('error', '查询在线', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            });
        };

        /**
         * 阻断
         * @param killObj
         */
        $scope.onlineKill = function (killObj) {
            $scope.items = (killObj == null || killObj == "" ||
            typeof(killObj) == "undefined") ? {} : killObj;
            var modalInstance = $modal.open({
                templateUrl: 'delKillTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var url = '/v1/log/project/' + msLocalStorage.get("projectId") + '/online-connect/' + selectedItem.id + '/kill/';
                $http({
                    method: "POST",
                    err_title: "阻断命令",
                    url: url
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        toaster.pop('success', '阻断命令', '成功');
                    } else {
                        toaster.pop('error', '阻断命令', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                    }
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
        /*******************************************在线Begin**************************************/
    }]);
app.controller('logHistoryController', ['$rootScope', '$scope', '$http', 'msLocalStorage', '$modal', '$log', 'toaster', 'msPlayback',
    function ($rootScope, $scope, $http, msLocalStorage, $modal, $log, toaster, msPlayback) {
        $scope.limit = 10;
        /*******************************************历史登录Begin**************************************/
        //历史登录分页
        $scope.historyPagination = {
            historyMaxSize: 5,
            historyTotalItems: 0,
            historyCurrentPage: 1
        };
        /**
         * select联想查询
         * @param user
         * @returns {*}
         */
        $scope.refreshUser = function (user) {
            return $http({
                method: 'GET',
                err_title: "用户列表查询",
                url: '/v1/user-manage/user/?limit=all&search=' + user,
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.userItems = response.data.results;
                }
            });
        };

        /**
         * 资产列表查询
         */
        $http({
            method: 'GET',
            err_title: "资产列表查询",
            url: '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/asset/?is_active=1&limit=all',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.assetItems = response.data.results;
            }
        });


        $scope.historyTableModal = {};
        $scope.historyInquire = {};

        $scope.clearHistory = function () {
            $scope.historyInquire = {};
            $scope.historySelect($scope.historyPagination.historyCurrentPage - 1);
        };

        $scope.inquireHistory = function () {
            $scope.historySelect($scope.historyPagination.historyCurrentPage - 1);
        };

        $scope.$watch('historyPagination.historyCurrentPage', function (newVal, oldVal) {
            if (newVal && newVal > -1) {
                $scope.historyPagination.historyCurrentPage = newVal;
                $scope.historySelect((newVal - 1));
            }
        }, true);

        $scope.historySelect = function (offset) {
            var url = '/v1/log/project/' + msLocalStorage.get("projectId") + '/connect-log/';
            if (offset !== 0) {
                offset = offset + '0';
            }
            url += '?offset=' + offset + '&limit=' + $scope.limit;
            if ($scope.historyInquire.hasOwnProperty('start_date')) {
                url += '&start_date=' + $scope.historyInquire.start_date;
            }
            if ($scope.historyInquire.hasOwnProperty('end_date')) {
                url += '&end_date=' + $scope.historyInquire.end_date;
            }
            if (!$.ms.isEmptyObject($scope.historyInquire.user)) {
                url += '&user_id=' + $scope.historyInquire.user.id;
            }
            if (!$.ms.isEmptyObject($scope.historyInquire.asset)) {
                url += '&asset_id=' + $scope.historyInquire.asset.id;
            }
            $http({
                method: "GET",
                err_title: "历史登录",
                url: url,
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.historyPagination.historyTotalItems = response.data.count;
                    $scope.historyTableModal = response.data.results;
                } else {
                    toaster.pop('error', '历史登录', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            });
        };

        //统计模态框
        $scope.historyCount = function (historyObj) {
            $scope.items = (historyObj == null || historyObj == "" ||
            typeof(historyObj) == "undefined") ? {} : historyObj;
            var modalInstance = $modal.open({
                templateUrl: 'historyCountTpl',
                controller: 'historyCountModalCtrl',
                size: 'count',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                $scope.selected = selectedItem;
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        //回放模态框
        $scope.playBackCount = function (historyObj) {
            var title = 'MagicStack录像回放 用户名:<span class="text-info" ng-bind="args.obj.role_name"></span>' +
                '主机:<span class="text-info" ng-bind="args.obj.asset_name"></span>' +
                '时间:<span class="text-info" ng-bind="args.obj.start_time"></span>-' +
                '<span class="text-info" ng-bind="args.obj.connect_length"></span>';
            var url = '/v1/log/project/' + msLocalStorage.get("projectId") + '/connect-log/' + historyObj.id + '/replay/';

            $http({
                method: 'GET',
                err_title: "获取回放信息",
                url: url,
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }).then(function successCallback(response) {
                msPlayback({data: response.data.cmds, title: title,obj:response.data});
            });


        };

        /*******************************************历史登录End**************************************/
    }]);
app.controller('logAlarmEventController', ['$rootScope', '$scope', '$http', 'msLocalStorage', '$modal', '$log', 'toaster',
    function ($rootScope, $scope, $http, msLocalStorage, $modal, $log, toaster) {
        $scope.limit = 10;

        /**
         * select联想查询
         * @param user
         * @returns {*}
         */
        $scope.refreshUser = function (user) {
            return $http({
                method: 'GET',
                err_title: "用户列表查询",
                url: '/v1/user-manage/user/?limit=all&search=' + user,
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.userItems = response.data.results;
                }
            });
        };
        /*******************************************告警事件Begin**************************************/
        $scope.alarmEventTableModal = {};
        $scope.alarmEventInquire = {};

        $scope.alarmEventPagination = {
            alarmEventMaxSize: 5,
            alarmEventTotalItems: 0,
            alarmEventCurrentPage: 1
        };

        $scope.inquireAlarmEvent = function () {
            $scope.alarmEventSelect($scope.alarmEventPagination.alarmEventCurrentPage - 1);
        };

        $scope.$watch('alarmEventPagination.alarmEventCurrentPage', function (newVal, oldVal) {
            if (newVal && newVal > -1) {
                $scope.alarmEventPagination.alarmEventCurrentPage = newVal;
                $scope.alarmEventSelect((newVal - 1));
            }
        }, true);

        /**
         *
         * @param offset
         */
        $scope.alarmEventSelect = function (offset) {
            var url = '/v1/log/project/' + msLocalStorage.get("projectId") + '/alarm/';
            if (offset !== 0) {
                offset = offset + '0';
            }
            url += '?offset=' + offset + '&limit=' + $scope.limit;
            if ($scope.alarmEventInquire.username) {
                url += '&username=' + $scope.alarmEventInquire.username.username;
            }
            if ($scope.alarmEventInquire.id) {
                url += '&id=' + $scope.alarmEventInquire.id;
            }
            $http({
                method: "GET",
                err_title: "告警事件",
                url: url,
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.alarmEventPagination.alarmEventTotalItems = response.data.count;
                    $scope.alarmEventTableModal = response.data.results;
                } else {
                    toaster.pop('error', '告警事件', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            });
        };

        /**
         * 告警事件重试
         * @param alarmEventObj
         */
        $scope.retryAlarmEvent = function (alarmEventObj) {
            if (!(alarmEventObj instanceof Array)) {
                alarmEventObj = (alarmEventObj == null || alarmEventObj == "" ||
                typeof(alarmEventObj) == "undefined") ? [] : [alarmEventObj];
            }
            alarmEventObj = (alarmEventObj == null || alarmEventObj == "" ||
            typeof(alarmEventObj) == "undefined") ? [] : alarmEventObj;
            $scope.items = alarmEventObj;
            var modalInstance = $modal.open({
                templateUrl: 'retryAlarmEventTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                $http({
                    method: "POST",
                    err_title: "重试",
                    url: '/v1/log/project/' + msLocalStorage.get("projectId") + '/alarm/' + selectedItem[0].id + '/retry/',
                    data: ''
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        toaster.pop('success', '重试', '已执行');
                    } else {
                        toaster.pop('error', '重试', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                    }
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
        /*******************************************告警事件Begin**************************************/
    }]);
app.controller('logUsersRecordController', ['$rootScope', '$scope', '$http', 'msLocalStorage', '$modal', '$log', 'toaster',
    function ($rootScope, $scope, $http, msLocalStorage, $modal, $log, toaster) {
        $scope.limit = 10;
        /**
         * select联想查询
         * @param user
         * @returns {*}
         */
        $scope.refreshUser = function (user) {
            return $http({
                method: 'GET',
                err_title: "用户列表查询",
                url: '/v1/user-manage/user/?limit=all&search=' + user,
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.userItems = response.data.results;
                }
            });
        };
        /*******************************************操作记录Begin**************************************/
        $scope.usersRecordTableModal = {};
        $scope.usersRecordInquire = {};

        $scope.usersRecordPagination = {
            usersRecordMaxSize: 5,
            usersRecordTotalItems: 0,
            usersRecordCurrentPage: 1
        };

        $scope.inquireUsersRecord = function () {
            $scope.usersRecordSelect($scope.usersRecordPagination.usersRecordCurrentPage - 1);
        };

        $scope.$watch('usersRecordPagination.usersRecordCurrentPage', function (newVal, oldVal) {
            if (newVal && newVal > -1) {
                $scope.usersRecordPagination.usersRecordCurrentPage = newVal;
                $scope.usersRecordSelect((newVal - 1));
            }
        }, true);

        $scope.usersRecordSelect = function (offset) {
            var url = '/v1/log/project/' + msLocalStorage.get("projectId") + '/operator-record/';
            if (offset !== 0) {
                offset = offset + '0';
            }
            url += '?offset=' + offset + '&limit=' + $scope.limit;
            if (($scope.usersRecordInquire.hasOwnProperty('username'))) {
                url += '&username=' + $scope.usersRecordInquire.username.username;
            }
            if ($scope.usersRecordInquire.hasOwnProperty('operating')) {
                url += '&operating=' + $scope.usersRecordInquire.operating;
            }

            $http({
                method: "GET",
                err_title: "操作记录",
                url: url,
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.usersRecordPagination.usersRecordTotalItems = response.data.count;
                    $scope.usersRecordTableModal = response.data.results;
                } else {
                    toaster.pop('error', '操作记录', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            });
        };
        $scope.usersRecordSelect($scope.usersRecordPagination.usersRecordCurrentPage);
        /*******************************************操作记录Begin**************************************/
    }]);