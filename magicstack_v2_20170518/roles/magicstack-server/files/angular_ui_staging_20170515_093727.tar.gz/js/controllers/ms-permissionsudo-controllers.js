/**
 * Created by lidukang on 2016/8/5.
 * 授权管理-sudo
 */
'use strict';
app.controller('sudoModalCtrl', ['$rootScope', '$scope', '$http', '$modalInstance','msLocalStorage', 'toaster', 'items',
    function ($rootScope, $scope, $http, $modalInstance, msLocalStorage, toaster, items) {
        if (!$.ms.isEmptyObject(items)) {
            $http({
                method: 'GET',
                err_title:"查询sudo",
                url: '/v1/asset_auth/project/' + msLocalStorage.get("projectId") + '/sudo/' + items.id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.items = response.data;
                }
            });
        } else {
            $scope.items = items;
        }
        $scope.ok = function () {
            $modalInstance.close($scope.items);
        };

        $scope.clear = function () {
            $scope.items = {};
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
app.controller('aliasesDetailsModalCtrl', ['$rootScope', '$scope', '$modal', '$http', '$modalInstance',
    'msLocalStorage', '$timeout', 'toaster', 'items',
    function ($rootScope, $scope, $modal, $http, $modalInstance,  msLocalStorage, $timeout, toaster, items) {
        /******************************************************PROXY创建记录Begin*****************************************************/
        $scope.proxyCreatePagination = {
            proxyCreateMaxSize: 5,
            proxyCreateTotalItems: 0,
            proxyCreateCurrentPage: 1
        };
        $scope.proxyCreateTableModal = {};
        $scope.selectProxyCreate = function (offset) {
            var url = '/v1/asset_auth/project/' + msLocalStorage.get("projectId") + '/sudo/' + items.id + '/proxy/create/';
            if (offset !== 0) {
                offset = offset + '0';
            }
            url += '?offset=' + offset + '&limit=10';
            $http({
                method: 'GET',
                err_title:"PROXY创建记录查询",
                url: url,
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.proxyCreatePagination.proxyCreateTotalItems = response.data.count;
                    $scope.proxyCreateTableModal = response.data.results;
                }
                else {
                    toaster.pop('error', 'PROXY创建记录查询', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            });
        };

        $scope.$watch('proxyCreatePagination.proxyCreateCurrentPage', function (newVal, oldVal) {
            if (!$.ms.isEmptyObject(items)) {
                if (newVal && newVal > -1) {
                    $scope.proxyCreatePagination.proxyCreateCurrentPage = newVal;
                    $scope.selectProxyCreate((newVal - 1));
                }
            }
        }, true);
        /******************************************************PROXY创建记录End*****************************************************/

        /******************************************************PROXY推送记录Begin*****************************************************/
        $scope.proxyPushPagination = {
            proxyPushMaxSize: 5,
            proxyPushTotalItems: 0,
            proxyPushCurrentPage: 1
        };
        $scope.proxyPushTableModal = {};
        $scope.selectProxyPush = function (offset) {
            var url = '/v1/asset_auth/project/' + msLocalStorage.get("projectId") + '/sudo/' + items.id + '/proxy/push/';
            if (offset !== 0) {
                offset = offset + '0';
            }
            url += '?offset=' + offset + '&limit=10';
            $http({
                method: 'GET',
                err_title:"PROXY推送记录查询",
                url: url,
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.proxyPushPagination.proxyPushTotalItems = response.data.count;
                    $scope.proxyPushTableModal = response.data.results;
                }
                else {
                    toaster.pop('error', 'PROXY推送记录查询', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            });
        };

        $scope.$watch('proxyPushPagination.proxyPushCurrentPage', function (newVal, oldVal) {
            if (!$.ms.isEmptyObject(items)) {
                if (newVal && newVal > -1) {
                    $scope.proxyPushPagination.proxyPushCurrentPage = newVal;
                    $scope.selectProxyPush((newVal - 1));
                }
            }
        }, true);
        /******************************************************PROXY推送记录End*****************************************************/

        $scope.ok = function () {
            $modalInstance.close($scope.items);
        };

        $scope.clear = function () {
            $scope.items = {};
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
app.controller('permissionsudoController', ['$rootScope', '$scope','$state', '$http', '$modal', '$q', '$log','msLocalStorage', '$interval', 'toaster',
    function ($rootScope, $scope,$state, $http, $modal, $q, $log,msLocalStorage, $interval, toaster) {
        $scope.listUrl = '/v1/asset_auth/project/' + msLocalStorage.get("projectId") + '/sudo/';
        var editBtnOpt = {
            text: '编辑',
            class: 'color-2',
            perm: "AUTH_SUDO_EDIT_ACTION",
            color:'#004740',
            action: function () {
                var items = $scope.table_options.getCheckedItems();
                $scope.newEditAliases(items[0]);
            }
        };
        var deleteBtnOpt = {
            text: '删除',
            class: 'color-4',
            perm: "AUTH_SUDO_DELETE_ACTION",
            color:'#d2181c',
            action: function (e, dt, node, config) {
                var items = $scope.table_options.getCheckedItems();
                $scope.delAliases(items);
            }
        };
        $scope.table_options = new msTables.Option()
            .withButtons([{
                hide: false,
                disable: false,
                text: '添加',
                perm: "AUTH_SUDO_CREATE_ACTION",
                class: 'color-1',
                color:'#2f5398',
                action: function (button) {
                    $scope.newEditAliases('');
                }
            },
                editBtnOpt, deleteBtnOpt, {
                    text: '展示/隐藏',
                    extend: 'colvis',
                    perm: "",
                    class: 'color-0'
                }
            ])
            .setCheckedChangeFunc(function (items) {
                if (items.length == 1) {
                    editBtnOpt.disable = false;
                } else {
                    editBtnOpt.disable = true;
                }
                if (items.length > 0) {
                    deleteBtnOpt.disable = false;
                } else {
                    deleteBtnOpt.disable = true;
                }
            })
            .enableSearch(true)
            .withFields(
                [{
                    key: "name",
                    title: "命令别名",
                    sort_key: "name",
                    can_hide: false
                }, {
                    key: 'commands',
                    title: "系统命令",
                    class:'long-text',
                    sort_key: "commands",
                    toolTip:function (item) {
                        return item.commands;
                    }
                }, {
                    key: 'comment',
                    title: "备注",
                    sort_key: "comment"
                },  {
                    key: 'create_time',
                    title: "创建时间",
                    sort_key: "create_time"
                },{
                    title: "操作",
                    can_hide: false,
                    class:'ms-table-operate',
                    html: function () {
                        return '<ms-ext-btn buttons="$ctrl.tabBtn" item="$item"/>';
                    }
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                var url = $scope.listUrl + '?offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "sudo列表查询",
                    url: url,
                }).then(function (response) {
                    return response.data;
                })
            })
            .enableExternData(false, function (item) {
                // return $scope.projectHtml(item);
            })
            .setCtrlInitFunc(function ($ctrl) {
                $ctrl.tabBtn = [
                    // {
                    //     name: '查看详情',
                    //     click: $scope.aliasesDetails,
                    //     perm: "",
                    // },
                    {
                        name: '编辑',
                        click: $scope.newEditAliases,
                        perm: "AUTH_SUDO_EDIT_ACTION",
                    },
                    {
                        name: '删除',
                        click: $scope.delAliases,
                        perm: "AUTH_SUDO_DELETE_ACTION",
                    }
                ];
            });

        /**
         * 新增、编辑sudo
         * @param aliasesObj
         */
        $scope.newEditAliases = function (aliasesObj) {
            $scope.items = (aliasesObj == null || aliasesObj == "" ||
            typeof(aliasesObj) == "undefined") ? {} : aliasesObj;
            var modalInstance = $modal.open({
                templateUrl: 'newEditAliasesTpl',
                controller: 'sudoModalCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                var method = "POST", url = $scope.listUrl;
                if (selectedItem.hasOwnProperty('id')) {
                    method = 'PUT';
                    url += selectedItem.id + '/';
                }
                $http({
                    method: method,
                    err_title:"创建或修改sudo",
                    url: url,
                    data: selectedItem
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('success', '修改sudo', '保存成功');
                        } else {
                            toaster.pop('success', '新增sudo', '保存成功');
                        }
                        $scope.table_options.reload();//重新渲染表格
                    } else {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('error', '修改sudo', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        } else {
                            toaster.pop('error', '新增sudo', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        }
                    }
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         * 删除sudo
         * @param aliasesObj
         */
        $scope.delAliases = function (aliasesObj) {
            if (!(aliasesObj instanceof Array)) {
                aliasesObj = (aliasesObj == null || aliasesObj == "" ||
                typeof(aliasesObj) == "undefined") ? [] : [aliasesObj];
            }
            aliasesObj = (aliasesObj == null || aliasesObj == "" ||
            typeof(aliasesObj) == "undefined") ? [] : aliasesObj;
            $scope.items = aliasesObj;
            var modalInstance = $modal.open({
                templateUrl: 'delAliasesTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var defered_array = [];
                angular.forEach(selectedItem, function (data, index, array) {
                    defered_array.push($scope.deleteAliases(data.id));
                });
                $q.all(defered_array).then(function() {
                    $scope.table_options.reload();//重新渲染表格
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
        /**
         * 删除sudo
         * @param id
         */
        $scope.deleteAliases = function (id) {
            var defer = $q.defer();
            $http({
                method: 'DELETE',
                err_title:"删除sudo",
                url: $scope.listUrl + id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '删除sudo', '删除成功');
                } else {
                    toaster.pop('error', '删除sudo', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
                defer.resolve();
            }, function errorCallback(response) {
                defer.resolve();
            });
            return defer.promise;
        };

        /***
         * sudo详情
         * @param aliasesObj
         */
        $scope.aliasesDetails = function (aliasesObj) {
            $scope.items = (aliasesObj == null || aliasesObj == "" ||
            typeof(aliasesObj) == "undefined") ? {} : aliasesObj;
            var modalInstance = $modal.open({
                templateUrl: 'aliasesDetailsTpl',
                controller: 'aliasesDetailsModalCtrl',
                size: 'lg',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                console.log(selectedItem);
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

    }
]);