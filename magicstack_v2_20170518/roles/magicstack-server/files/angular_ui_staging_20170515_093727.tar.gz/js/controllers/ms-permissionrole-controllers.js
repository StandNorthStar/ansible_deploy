/**
 * Created by lidukang on 2016/8/5.
 * 授权管理-系统用户
 */
'use strict';
app.controller('roleModalCtrl', ['$rootScope', '$scope', '$http', '$modalInstance',
    'msLocalStorage', 'toaster', 'items',
    function ($rootScope, $scope, $http, $modalInstance, msLocalStorage, toaster, items) {
        if (!$.ms.isEmptyObject(items)) {
            $http({
                method: 'GET',
                err_title:"查询系统用户",
                url: '/v1/asset_auth/project/' + msLocalStorage.get("projectId") + '/role/' + items.id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.items = response.data;
                    $scope.items.key_content = '';
                }
            });
        } else {
            $scope.items = items;
        }

        /**
         * sudo列表查询
         */
        $http({
            method: 'GET',
            err_title:"sudo列表查询",
            url: '/v1/asset_auth/project/' + msLocalStorage.get("projectId") + '/sudo/?limit=all',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.sudoItems = response.data.results;
            }
        });

        $scope.ok = function () {
            $modalInstance.close($scope.items);
        };

        $scope.clear = function () {
            $scope.items = {};
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
app.controller('pushRoleModalCtrl', ['$rootScope', '$scope', '$http', '$modalInstance',
    'msLocalStorage', 'toaster', 'items',
    function ($rootScope, $scope, $http, $modalInstance,  msLocalStorage, toaster, items) {
        $scope.name = items.name;
        $scope.pushRoleModel = {};

        /**
         * 资产列表查询
         */
        $http({
            method: 'GET',
            err_title:"资产列表查询",
            url: '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/asset/?is_active=1&limit=all',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.assetItems = response.data.results;
            }
        });

        $scope.assetsFlag = true;

        $scope.$watch('pushRoleModel.asset', function (newVal, oldVal) {
            if (newVal) {
                $scope.assetsFlag = false;
            }
        }, true);

        $scope.ok = function () {
            $scope.pushRoleModel.id = items.id;
            $modalInstance.close($scope.pushRoleModel);
        };

        $scope.clear = function () {
            $scope.pushRoleModel = {};
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
app.controller('roleDetailsModalCtrl', ['$rootScope', '$scope', '$modal', '$http', '$modalInstance',
    'msLocalStorage', '$timeout', 'toaster', 'items',
    function ($rootScope, $scope, $modal, $http, $modalInstance,  msLocalStorage, $timeout, toaster, items) {
        /******************************************************PROXY创建记录Begin*****************************************************/
        $scope.proxyCreatePagination = {
            proxyCreateMaxSize: 5,
            proxyCreateTotalItems: 0,
            proxyCreateCurrentPage: 1
        };
        $scope.proxyCreateTableModal = {};
        $scope.selectProxyCreate = function (offset) {
            var url = '/v1/asset_auth/project/' + msLocalStorage.get("projectId") + '/role/' + items.id + '/proxy/create/';
            if (offset !== 0) {
                offset = offset + '0';
            }
            url += '?offset=' + offset + '&limit=10';
            $http({
                method: 'GET',
                err_title:"PROXY创建记录查询",
                url: url,
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.proxyCreatePagination.proxyCreateTotalItems = response.data.count;
                    $scope.proxyCreateTableModal = response.data.results;
                }
                else {
                    toaster.pop('error', 'PROXY创建记录查询', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            });
        };

        $scope.$watch('proxyCreatePagination.proxyCreateCurrentPage', function (newVal, oldVal) {
            if (!$.ms.isEmptyObject(items)) {
                if (newVal && newVal > -1) {
                    $scope.proxyCreatePagination.proxyCreateCurrentPage = newVal;
                    $scope.selectProxyCreate((newVal - 1));
                }
            }
        }, true);
        /******************************************************PROXY创建记录End*****************************************************/

        /******************************************************PROXY推送记录Begin*****************************************************/
        $scope.proxyPushPagination = {
            proxyPushMaxSize: 5,
            proxyPushTotalItems: 0,
            proxyPushCurrentPage: 1
        };
        $scope.proxyPushTableModal = {};
        $scope.selectProxyPush = function (offset) {
            var url = '/v1/asset_auth/project/' + msLocalStorage.get("projectId") + '/role/' + items.id + '/proxy/push/';
            if (offset !== 0) {
                offset = offset + '0';
            }
            url += '?offset=' + offset + '&limit=10';
            $http({
                method: 'GET',
                err_title:"PROXY推送记录查询",
                url: url,
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.proxyPushPagination.proxyPushTotalItems = response.data.count;
                    $scope.proxyPushTableModal = response.data.results;
                }
                else {
                    toaster.pop('error', 'PROXY推送记录查询', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            });
        };

        $scope.$watch('proxyPushPagination.proxyPushCurrentPage', function (newVal, oldVal) {
            if (!$.ms.isEmptyObject(items)) {
                if (newVal && newVal > -1) {
                    $scope.proxyPushPagination.proxyPushCurrentPage = newVal;
                    $scope.selectProxyPush((newVal - 1));
                }
            }
        }, true);
        /******************************************************PROXY推送记录End*****************************************************/

        /******************************************************未推送主机Begin*****************************************************/
        $scope.notYetPushHostPagination = {
            notYetPushHostMaxSize: 5,
            notYetPushHostTotalItems: 0,
            notYetPushHostCurrentPage: 1
        };
        $scope.notYetPushHostTableModal = {};
        $scope.selectNotYetPushHost = function (offset) {
            var url = '/v1/asset_auth/project/' + msLocalStorage.get("projectId") + '/role/' + items.id + '/proxy/unpushed/';
            if (offset !== 0) {
                offset = offset + '0';
            }
            url += '?offset=' + offset + '&limit=10';
            $http({
                method: 'GET',
                err_title:"系统用户详情查询",
                url: url,
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.notYetPushHostPagination.notYetPushHostTotalItems = response.data.count;
                    $scope.notYetPushHostTableModal = response.data.results;
                }
                else {
                    toaster.pop('error', '系统用户详情查询', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            });
        };

        $scope.$watch('notYetPushHostPagination.notYetPushHostCurrentPage', function (newVal, oldVal) {
            if (!$.ms.isEmptyObject(items)) {
                if (newVal && newVal > -1) {
                    $scope.notYetPushHostPagination.notYetPushHostCurrentPage = newVal;
                    $scope.selectNotYetPushHost((newVal - 1));
                }
            }
        }, true);
        /******************************************************未推送主机End*****************************************************/


        /******************************************************PROXY上操作记录Begin*****************************************************/
        $scope.proxyOperationRecordPagination = {
            proxyOperationRecordMaxSize: 5,
            proxyOperationRecordTotalItems: 0,
            proxyOperationRecordCurrentPage: 1
        };
        $scope.proxyOperationRecordTableModal = {};
        $scope.selectProxyOperationRecord = function (offset) {
            var url = '/v1/asset_auth/project/' + msLocalStorage.get("projectId") + '/role/' + items.id + '/';
            if (offset !== 0) {
                offset = offset + '0';
            }
            url += '?offset=' + offset + '&limit=10';
            $http({
                method: 'GET',
                err_title:"系统用户详情查询",
                url: url,
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.proxyOperationRecordPagination.proxyOperationRecordTotalItems = response.data.count;
                    $scope.proxyOperationRecordTableModal = response.data.results;
                }
                else {
                    toaster.pop('error', '系统用户详情查询', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            });
        };

        $scope.$watch('proxyOperationRecordPagination.proxyOperationRecordCurrentPage', function (newVal, oldVal) {
            if (!$.ms.isEmptyObject(items)) {
                if (newVal && newVal > -1) {
                    $scope.proxyOperationRecordPagination.proxyOperationRecordCurrentPage = newVal;
                    $scope.selectProxyOperationRecord((newVal - 1));
                }
            }
        }, true);
        /******************************************************PROXY上操作记录End*****************************************************/

        $scope.ok = function () {
            $modalInstance.close($scope.items);
        };

        $scope.clear = function () {
            $scope.items = {};
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
app.controller('permissionroleController', ['$rootScope', '$scope', '$state', '$http', '$modal', '$log','msLocalStorage', '$interval', 'toaster','$q',
    function ($rootScope, $scope, $state, $http, $modal, $log,msLocalStorage, $interval, toaster,$q) {
        $scope.listUrl = '/v1/asset_auth/project/' + msLocalStorage.get("projectId") + '/role/';
        var editBtnOpt = {
            text: '编辑',
            class: 'color-2',
            perm: "AUTH_ROLE_EDIT_ACTION",
            color:'#004740',
            action: function () {
                var items = $scope.table_options.getCheckedItems();
                $scope.newEditRole(items[0]);
            }
        };
        var deleteBtnOpt = {
            text: '删除',
            class: 'color-4',
            perm: "AUTH_ROLE_DELETE_ACTION",
            color:'#d2181c',
            action: function (e, dt, node, config) {
                var items = $scope.table_options.getCheckedItems();
                $scope.delRole(items);
            }
        };
        $scope.table_options = new msTables.Option()
            .withButtons([{
                hide: false,
                disable: false,
                text: '添加',
                class: 'color-1',
                perm: "AUTH_ROLE_CREATE_ACTION",
                color:'#2f5398',
                action: function (button) {
                    $scope.newEditRole('');
                }
            },
                editBtnOpt, deleteBtnOpt, {
                    text: '展示/隐藏',
                    extend: 'colvis',
                    perm: "",
                    class: 'color-0'
                }
            ])
            .setCheckedChangeFunc(function (items) {
                if (items.length == 1) {
                    editBtnOpt.disable = false;
                } else {
                    editBtnOpt.disable = true;
                }
                if (items.length > 0) {
                    deleteBtnOpt.disable = false;
                } else {
                    deleteBtnOpt.disable = true;
                }
            })
            .enableSearch(true)
            .withFields(
                [{
                    key: "name",
                    title: "名称",
                    sort_key: "name",
                    can_hide: false
                }, {
                    title: "sudo别名",
                    class:'long-text',
                    html: function (item) {
                        if (item.sudo.length > 0) {
                            var tempSudoName = [];
                            angular.forEach(item.sudo, function (data, index, array) {
                                tempSudoName.push(data.name);
                            });
                            return tempSudoName.toString();
                        } else {
                            return null;
                        }
                    },
                    toolTip:function (item,field) {
                        return field.html(item);
                    }
                }, {
                    title: "推送状态",
                    sort_key: "push_status",
                    html:function (item) {
                        var code =item.push_status;
                        if (code == 1) {
                            return '推送中';
                        }
                        if (code == 2) {
                            return '推送结束';
                        }
                    }
                }, {
                    key: 'push_detail',
                    class:'long-text',
                    title: "推送结果",
                    sort_key: "push_detail",
                    toolTip:function (item) {
                        return item.push_detail;
                    }
                }, {
                    key: 'create_time',
                    title: "创建时间",
                    sort_key: "create_time"
                }, {
                    title: "操作",
                    can_hide: false,
                    class:'ms-table-operate',
                    html: function () {
                        return '<ms-ext-btn buttons="$ctrl.tabBtn" item="$item"/>';
                    }
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                var url = $scope.listUrl + '?offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "系统用户列表查询",
                    url: url,
                }).then(function (response) {
                    var relaod = false;
                    response.data.results.forEach(function (item) {
                        if (item.push_status==1) {
                            relaod = true;
                        }
                    });
                    response.data.auto_reload = relaod;
                    return response.data;
                })
            })
            .enableExternData(true, function (item) {
                return "<div class='extern-title'>系统组:</div><div class='extern-content'>{{$item.system_groups}}</div>" +
                    "<div class='extern-title'>备注:</div><div class='extern-content'>{{$item.comment}}</div>";
            })
            .setCtrlInitFunc(function ($ctrl) {
                $ctrl.tabBtn = [
                    {
                        name: '查看详情',
                        click: $scope.roleDetails,
                        perm: "",
                    },
                    {
                        name: '编辑',
                        click: $scope.newEditRole,
                        perm: "AUTH_ROLE_EDIT_ACTION",
                    },
                    {
                        name: '推送',
                        click: $scope.pushRole,
                        perm: "AUTH_ROLE_PUSH_ACTION",
                    },
                    {
                        name: '下载密钥',
                        click: $scope.downloadKey,
                        perm: "AUTH_ROLE_DOWNLOAD_KEY_ACTION",
                    },
                    {
                        name: '删除',
                        click: $scope.delRole,
                        perm: "AUTH_ROLE_DELETE_ACTION",
                    }
                ];
            });

        /**
         * 新增、编辑系统用户
         * @param roleObj
         */
        $scope.newEditRole = function (roleObj) {
            $scope.items = (roleObj == null || roleObj == "" ||
            typeof(roleObj) == "undefined") ? {} : roleObj;
            var modalInstance = $modal.open({
                templateUrl: 'newEditRoleTpl',
                controller: 'roleModalCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var method = "POST", url = $scope.listUrl;
                if (selectedItem.hasOwnProperty('id')) {
                    method = 'PUT';
                    url += selectedItem.id + '/';
                }
                $http({
                    method: method,
                    err_title:"创建或修改系统用户",
                    url: url,
                    data: selectedItem
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('success', '修改系统用户', '保存成功');
                        } else {
                            toaster.pop('success', '新增系统用户', '保存成功');
                        }
                        $scope.table_options.reload();//重新渲染表格
                    } else {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('error', '修改系统用户', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        } else {
                            toaster.pop('error', '新增系统用户', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        }
                    }
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         * 删除Role
         * @param roleObj
         */
        $scope.delRole = function (roleObj) {
            if (!(roleObj instanceof Array)) {
                roleObj = (roleObj == null || roleObj == "" ||
                typeof(roleObj) == "undefined") ? [] : [roleObj];
            }
            roleObj = (roleObj == null || roleObj == "" ||
            typeof(roleObj) == "undefined") ? [] : roleObj;
            $scope.items = roleObj;
            var modalInstance = $modal.open({
                templateUrl: 'delRoleTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var del_promise = [];
                angular.forEach(selectedItem, function (data, index, array) {
                    del_promise.push($scope.deleteRole(data.id));
                });
                $q.all(del_promise).then(function () {
                    $scope.table_options.reload();//重新渲染表格
                });

            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
        /**
         * 删除sudo
         * @param id
         */
        $scope.deleteRole = function (id) {
            var defer = $q.defer();
            return $http({
                method: 'DELETE',
                err_title:"删除系统用户",
                url: $scope.listUrl + id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '删除系统用户', '删除成功');
                } else {
                    toaster.pop('error', '删除系统用户', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
                defer.resolve();
            }, function errorCallback(response) {
                defer.resolve();
            });
            return defer.promise;
        };

        /**
         * 推送
         * @param roleObj
         */
        $scope.pushRole = function (roleObj) {
            $scope.items = (roleObj == null || roleObj == "" ||
            typeof(roleObj) == "undefined") ? {} : roleObj;
            var modalInstance = $modal.open({
                templateUrl: 'pushRoleTpl',
                controller: 'pushRoleModalCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var tempAsset = [];
                if (selectedItem.asset) {
                    angular.forEach(selectedItem.asset, function (data, index, array) {
                        tempAsset.push({id: data.id});
                    });
                }
                $http({
                    method: 'POST',
                    err_title:"系统用户-推送",
                    url: $scope.listUrl + 'push-role/' + selectedItem.id + '/',
                    data: {asset: tempAsset, comment: selectedItem.comment}
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        toaster.pop('success', '系统用户-推送', '推送中');
                        $scope.table_options.reload();//重新渲染表格
                    } else {
                        toaster.pop('error', '系统用户-推送', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                    }
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         * 下载密钥
         * @param roleObj
         */
        $scope.downloadKey = function (roleObj) {
            window.open($scope.listUrl + 'download-key/' + roleObj.id + '/', '_self', 'toolbar=no, location=no,resizable=no,copyhistory=yes, scrollbars=no');
        };

        /***
         * 系统用户详情
         * @param roleObj
         */
        $scope.roleDetails = function (roleObj) {
            $scope.items = (roleObj == null || roleObj == "" ||
            typeof(roleObj) == "undefined") ? {} : roleObj;
            var modalInstance = $modal.open({
                templateUrl: 'roleDetailsTpl',
                controller: 'roleDetailsModalCtrl',
                size: 'lg',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                console.log(selectedItem);
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

    }
]);