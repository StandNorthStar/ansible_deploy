/**
 * Created by lidukang on 2016/8/5.
 * 应用管理-模块剧本
 */
'use strict';
app.controller('deployMSUploadModalCtrl', ['$rootScope', '$scope', '$http', '$modalInstance', 'msLocalStorage', 'toaster', 'items', 'Upload',
    function ($rootScope, $scope, $http, $modalInstance, msLocalStorage, toaster, items, Upload) {
        $scope.submit = function () {
            $modalInstance.close($scope.file);
        };

        $scope.clear = function () {
            $scope.file = null;
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
app.controller('deployModuleScriptModalCtrl', ['$rootScope', '$scope', '$http', '$modalInstance',
    'msLocalStorage', 'toaster', 'items',
    function ($rootScope, $scope, $http, $modalInstance, msLocalStorage, toaster, items) {
        $scope.deployModel = items;
        $scope.deployURL = '/v1/application/project/' + msLocalStorage.get("projectId") + '/deploy/';
        $http({
            method: 'GET',
            err_title: "代理列表查询",
            url: '/v1/proxy-manage/project/' + msLocalStorage.get("projectId") + '/proxy/?limit=all&ordering=proxy_name',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.proxyItems = response.data.results;
            }
        });

        /**
         * 资产列表查询
         */
        $scope.$watch('deployModel.proxy', function (newVal, oldVal) {
            if (!$.ms.isEmptyObject(newVal)) {
                $http({
                    method: 'GET',
                    err_title: "资产列表查询",
                    url: '/v1/asset-manage/project/' + msLocalStorage.get("projectId") + '/proxy/' + newVal.id + '/asset/?is_active=1&limit=all',
                    data: ''
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        $scope.assetItems = response.data.results;
                    }
                });
            } else {
                $scope.assetItems = [];
            }
        }, true);

        $scope.ok = function () {
            $modalInstance.close($scope.deployModel);
        };

        $scope.upload = function () {
            $http({
                method: "POST",
                err_title: "部署失败",
                url: $scope.deployURL,
                data: {}
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    var url = "deploy_terminal.html?" + "token=" + response.data.task_uuid;
                    $.ms.setWindowOpen(url, '_blank', 1174, 476);
                } else {
                    toaster.pop('error', '部署失败:', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            });
        };
        $scope.clear = function () {
            $scope.deployModel = {
                proxy: ''
            };
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
app.controller('editModuleScriptModalCtrl', ['$scope', '$http', '$modalInstance', 'msLocalStorage', 'toaster', 'items',
    function ($scope, $http, $modalInstance, msLocalStorage, toaster, items) {
        $scope.items = items;
        $scope.editMSModel = $scope.items;

        $scope.ok = function () {
            $modalInstance.close($scope.editMSModel);
            $scope.editMSModel.kwargs.desc = $scope.editMSModel.desc;
        };

        $scope.clear = function () {
            $scope.editMSModel = {};
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
app.controller('modulescriptController', ['$rootScope', '$scope', '$http', '$modal', '$log',
    'msLocalStorage', '$interval', 'toaster', 'Upload', '$state',
    function ($rootScope, $scope, $http, $modal, $log, msLocalStorage, $interval, toaster, Upload, $state) {

        $scope.applicationURL = '/v1/application/app/';
        $scope.deployURL = '/v1/application/project/' + msLocalStorage.get("projectId") + '/deploy/';

        /**
         * 文件上传
         * @param fileObj
         */
        $scope.deployMSUploadOpen = function (fileObj) {
            $scope.items = (fileObj == null || fileObj == "" ||
            typeof(fileObj) == "undefined") ? {} : fileObj;
            var modalInstance = $modal.open({
                templateUrl: 'deployModuleScriptUploadTpl',
                controller: 'deployMSUploadModalCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                $scope.uploadFile(selectedItem, $scope.upload)
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
        $scope.fileProgress = 0;//进度条百分比
        $scope.uploading = false;

        $scope.uploadFile = function (file, callback) {
            $scope.uploading = true;
            file.upload = Upload.upload({
                url: '/v1/common-file/upload/',
                data: {file: file}
            });

            file.upload.then(function (response) {
                file.result = response.data;
                callback(file.result.id)
            }, function (response) {
                if (response.status > 0)
                    $scope.errorMsg = response.status + ': ' + response.data;
            }, function (evt) {
                // Math.min is to fix IE which reports 200% sometimes
                var progress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
                console.log("process", evt.loaded, evt.total, progress + "%");
                $scope.fileProgress = progress;
                if (progress > 0 && progress < 100) {
                    $scope.uploading = true;
                }
            });
        };

        $scope.upload = function (fileid) {
            $http({
                method: 'POST',
                err_title: "上传失败",
                url: $scope.applicationURL,
                data: {
                    "file": fileid,
                    "type": 'playbook'
                }
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '上传成功');
                    $scope.initList();
                    $scope.uploading = false;
                }
            }, function errorCallback(response) {
                $scope.uploading = false;
            });
        };

        /**
         * 初始化可用部署文件列表
         */
        $scope.appRecordTableModel = {};
        $scope.initList = function () {
            $http({
                method: "GET",
                err_title: "初始化失败",
                url: $scope.applicationURL + '?limit=all',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.appRecordTableModel = response.data.results;
                } else {
                    toaster.pop('error', '初始化失败', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            });

        };

        $scope.initList();


        /**
         * 部署模板剧本
         * @param moduleScriptObj
         */
        $scope.deployModuleScript = function (moduleScriptObj) {
            $state.go("app.apprun", {id: moduleScriptObj.id});
        };

        /**
         * 编辑剧本
         * @param moduleScriptObj
         */
        $scope.editModuleScript = function (moduleScriptObj) {
            $scope.items = (moduleScriptObj == null || moduleScriptObj == "" ||
            typeof(moduleScriptObj) == "undefined") ? {} : moduleScriptObj;
            var modalInstance = $modal.open({
                templateUrl: 'editModuleScriptTpl',
                controller: 'editModuleScriptModalCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                $http({
                    method: 'PUT',
                    err_title: "编辑失败",
                    url: $scope.applicationURL + selectedItem.id + '/',
                    data: {
                        "desc": selectedItem.desc,
                        "kwargs": selectedItem.kwargs
                    }
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        toaster.pop('success', '编辑成功');
                        $scope.initList();
                    }
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         * 删除模板剧本
         * @param moduleScriptObj
         */
        $scope.delModuleScript = function (moduleScriptObj) {
            $scope.items = (moduleScriptObj == null || moduleScriptObj == "" ||
            typeof(moduleScriptObj) == "undefined") ? {} : moduleScriptObj;
            var modalInstance = $modal.open({
                templateUrl: 'delModuleScriptTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                $http({
                    method: 'DELETE',
                    err_title: "删除失败",
                    url: $scope.applicationURL + selectedItem.id + '/',
                    data: ''
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        toaster.pop('success', '删除成功');
                        $scope.initList();
                    }
                });

            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
    }
]);