/**
 * Created by lidukang on 2017/2/8.
 */
'use strict';
app.controller('cIController', ['$rootScope', '$scope', '$state', '$http', '$modal', '$log', 'toaster', '$q', 'msLocalStorage',
    function ($rootScope, $scope, $state, $http, $modal, $log, toaster, $q, msLocalStorage) {
        $scope.listUrl = '/v1/buildbot/project/' + msLocalStorage.get("projectId") + '/';
        var editBtnOpt = {
            text: '编辑',
            class: 'color-2',
            perm: "ASSET_IDC_EDIT_ACTION",
            color: '#004740',
            action: function () {
                var items = $scope.table_options.getCheckedItems();
                $state.go('app.editcontinuous', {id: items[0].config_id});
            }
        };
        var deleteBtnOpt = {
            text: '删除',
            class: 'color-4',
            perm: "ASSET_IDC_DELETE_ACTION",
            color: '#d2181c',
            action: function (e, dt, node, config) {
                var items = $scope.table_options.getCheckedItems();
                $scope.delCI(items);
            }
        };
        $scope.table_options = new msTables.Option()
            .enableItemChecks(true, 'builderid')
            .withButtons([{
                disable: false,
                text: '添加',
                perm: "ASSET_IDC_CREATE_ACTION",
                class: 'color-1',
                color: '#2f5398',
                action: function (button) {
                    $state.go('app.newcontinuous', '');
                }
            }, editBtnOpt, deleteBtnOpt, {
                text: '展示/隐藏',
                perm: "",
                extend: 'colvis',
                class: 'color-0'
            }
            ])
            .setCheckedChangeFunc(function (items) {
                if (items.length == 1) {
                    editBtnOpt.disable = false;
                } else {
                    editBtnOpt.disable = true;
                }
                if (items.length > 0) {
                    deleteBtnOpt.disable = false;
                } else {
                    deleteBtnOpt.disable = true;
                }
            })
            .enableSearch(true)
            .withFields(
                [{
                    title: "项目名称",
                    sort_key: "name",
                    can_hide: false,
                    html: function (item) {
                        return '<a class="btn btn-link" ' +
                            'style="padding: 0;color: #428bca;" ' +
                            'ng-click="$ctrl.xiangqing($item)" ' +
                            'ng-bind="$item.name"></a>';
                    }
                }, {
                    key: 'description',
                    title: "描述",
                    sort_key: "description"
                }, {
                    title: "操作",
                    can_hide: false,
                    class: 'ms-table-operate',
                    html: function () {
                        return '<ms-ext-btn buttons="$ctrl.tabBtn" item="$item"/>';
                    }
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                var url = $scope.listUrl + 'builders/' + '?offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "持续集成列表查询",
                    url: url,
                }).then(function (response) {
                    return response.data;
                })
            })
            .enableExternData(true, function (item) {
                return $scope.proxyHtml(item);
            })
            .setCtrlInitFunc(function ($ctrl) {
                $ctrl.xiangqing = function (item) {
                    $state.go('app.cibuild', {id: item.builderid});
                };
                $ctrl.tabBtn = [
                    {
                        name: '立即构建',
                        click: $scope.runBuild,
                        perm: "",
                    },
                    {
                        name: '编辑',
                        click: $scope.editCI,
                        perm: "",
                    },
                    {
                        name: '删除',
                        click: $scope.delCI,
                        perm: "",
                    }
                ];

            });

        /**
         * 立即构建
         * @param cIObj
         */
        $scope.runBuild = function (cIObj) {
            $http({
                method: 'POST',
                err_title: "立即构建",
                url: $scope.listUrl + 'builders/' + cIObj.builderid + '/run_build',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '立即构建', '提交成功！');
                } else {
                    toaster.pop('error', '立即构建', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            }, function errorCallback(response) {
            });
        };

        /**
         * 编辑
         * @param cIObj
         */
        $scope.editCI = function (cIObj) {
            $state.go('app.editcontinuous', {id: cIObj.config_id});
        };

        /**
         * 代理
         * @param data
         * @param type
         * @param full
         * @param meta
         * @returns {string}
         */
        $scope.proxyHtml = function (data, type, full, meta) {
            var html = '', dt = '', dd = '';
            dt = '<dt>代理:</dt>';
            angular.forEach(data.proxys, function (data, index, array) {
                if (data.connected) {
                    dd += '<dd class="label label-success">' + data.proxy_name + '</dd>';
                } else {
                    dd += '<dd class="label label-danger">' + data.proxy_name + '</dd>';
                }
            });
            html += '<dl class="user-project">' + dt + dd + '</dl>';
            return html;
        };

        /**
         * 删除CI
         * @param CIObj
         */
        $scope.delCI = function (CIObj) {
            if (!(CIObj instanceof Array)) {
                CIObj = (CIObj == null || CIObj == "" ||
                typeof(CIObj) == "undefined") ? [] : [CIObj];
            }
            CIObj = (CIObj == null || CIObj == "" ||
            typeof(CIObj) == "undefined") ? [] : CIObj;
            $scope.items = CIObj;
            var modalInstance = $modal.open({
                templateUrl: 'delCITpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                var defered_array = [];
                angular.forEach(selectedItem, function (data, index, array) {
                    defered_array.push($scope.deleteCI(data.config_id));
                });
                $q.all(defered_array).then(function () {
                    $scope.table_options.reload();//重新渲染表格
                })
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
        /**
         * 删除CI
         * @param id
         */
        $scope.deleteCI = function (id) {
            var defer = $q.defer();
            $http({
                method: 'DELETE',
                err_title: "删除CI",
                url: $scope.listUrl + 'config_builders/' + id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '删除CI', '删除成功');
                } else {
                    toaster.pop('error', '删除CI', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
                defer.resolve();
            }, function errorCallback(response) {
                defer.resolve();
            });
            return defer.promise;
        };
    }
]);
//新增编辑
app.controller('newEditCIController', ['$rootScope', '$scope', '$compile', '$state', '$http', '$log', 'toaster', '$templateCache', 'msLocalStorage',
    function ($rootScope, $scope, $compile, $state, $http, $log, toaster, $templateCache, msLocalStorage) {
        $scope.newEditUrl = '/v1/buildbot/project/' + msLocalStorage.get("projectId") + '/config_builders/';
        $scope.newsCount = 0;
        $scope.stepTypes = [];
        $scope.stepTypeArray = [];
        $scope.title = '新增持续集成';
        if ($state.params.id) {
            $scope.title = '编辑持续集成';
            $http({
                method: 'GET',
                err_title: "查询构建详情",
                url: $scope.newEditUrl + $state.params.id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.cIModel = response.data;
                    $scope.cIModel.steps.forEach(function (data) {
                        $scope.createForm(data.type, data.kwargs);
                    });
                }
            });
        } else {
            $scope.cIModel = {
                steps: []
            };
        }

        Array.prototype.removeByValue = function (val) {
            for (var i = 0; i < this.length; i++) {
                if (this[i] == val) {
                    this.splice(i, 1);
                    break;
                }
            }
        };
        $http({
            method: 'GET',
            err_title: "代理列表查询",
            url: '/v1/proxy-manage/project/' + msLocalStorage.get("projectId") + '/proxy/?limit=all',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.proxyItems = response.data.results;
            }
        });
        $http({
            method: 'GET',
            err_title: "获取步数类型",
            url: '/v1/buildbot/step-types/',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.stepTypes = response.data;
            }
        });

        $scope.createDynamicForm = function (newid, tplObj, type, kwargs) {
            $scope.stepTypeArray.push(newid);
            $scope.stepTypes.some(function (item) {
                if (item.type == type) {
                    $scope['newsModel' + newid] = angular.copy(item);//不要直接赋值
                    $scope['newsModel' + newid]['kwargs'] = kwargs || {};
                }
            });
            var newNode = $.ms.format(tplObj.html(), newid);
            var newsEle = angular.element(newNode);
            angular.element($('#step_container')).append(newsEle);
            $compile(newsEle.contents())($scope);
        };

        $scope.createForm = function (type, kwargs) {
            var st = ++$scope.newsCount;
            $scope.createDynamicForm('tpl' + st, $('#newTpl'), type, kwargs);
        };

        $scope.delForm = function (newid) {
            $('#step_types_' + newid).remove();
            delete $scope['newsModel' + newid];
            $scope.stepTypeArray.removeByValue(newid);
        };

        /**
         * 保存
         */
        $scope.submintForm = function () {
            var method = 'POST';
            if ($scope.cIModel.id) {
                method = 'PUT';
                $scope.newEditUrl = $scope.newEditUrl + $scope.cIModel.id + '/';
            }
            $scope.cIModel.steps = [];
            angular.forEach($scope.stepTypeArray, function (data, index, array) {
                $scope.cIModel.steps.push($scope['newsModel' + data]);
            });
            $http({
                method: method,
                url: $scope.newEditUrl,
                data: $scope.cIModel
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '持续集成', '保存成功');
                    $state.go('app.integration.continuous');
                } else {
                    toaster.pop('error', '持续集成', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
            }, function errorCallback(response) {

            });
        };
    }
]);

//构建
app.controller('cIBuildCIController', ['$rootScope', '$scope', '$state', '$http', '$modal', '$log', 'toaster', '$q', 'msLocalStorage',
    function ($rootScope, $scope, $state, $http, $modal, $log, toaster, $q, msLocalStorage) {
        $scope.listUrl = '/v1/buildbot/project/' + msLocalStorage.get("projectId") + '/';
        $scope.cIDetail = {};
        $http({
            method: 'GET',
            err_title: "构建详情查询",
            url: $scope.listUrl + 'builders/' + $state.params.id + '/',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.cIDetail = response.data;
            }
        });
        $scope.build_requests_options = new msTables.Option()
            .enableItemChecks(false, 'buildrequestid')
            .enableSearch(false)
            .withFields(
                [{
                    title: "BuildRequestID",
                    sort_key: "buildrequestid",
                    can_hide: false,
                    html: function (item) {
                        return '<a class="btn btn-link" ' +
                            'style="padding: 0;color: #428bca;" ' +
                            'ng-click="$ctrl.buildDetail($item)" ' +
                            'ng-bind="$item.buildrequestid"></a>';
                    }
                }, {
                    title: "提交时间",
                    sort_key: "submitted_at",
                    html: function (item) {
                        return moment.unix(item.submitted_at).format('YYYY-MM-DD HH:mm:ss')
                    }
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                var url = $scope.listUrl + 'builders/' + $state.params.id + '/buildrequests/?claimed=false&offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "构建请求表查询",
                    url: url,
                }).then(function (response) {
                    return response.data;
                })
            })
            .enableExternData(false, function (item) {
                // return $scope.proxyHtml(item);
            })
            .setCtrlInitFunc(function ($ctrl) {
                $ctrl.buildDetail = function (item) {
                    $state.go('app.cibuildrequest', {id: item.builderid});
                };
            });


        $scope.builds_options = new msTables.Option()
            .enableItemChecks(false, 'buildid')
            .enableSearch(false)
            .withFields(
                [{
                    title: "Number",
                    sort_key: "number",
                    can_hide: false,
                    html: function (item) {
                        return '<a ng-class="$ctrl.results_to_class($item.results)" class="label build-number" ' +
                            'style="border-radius:10px" ' +
                            'ng-click="$ctrl.buildAttrDetail($item)" >' +
                            '<span class="number-text" ng-bind="$item.number"></span>' +
                            '<span class="active-text" ng-bind="$ctrl.results_to_status($item.results)"></span>' +
                            '</a>';
                    }
                }, {
                    title: "开始时间",
                    sort_key: "started_at",
                    html: function (item) {
                        return moment.unix(item.started_at).format('YYYY-MM-DD HH:mm:ss')
                    }
                }, {
                    title: "结束时间",
                    sort_key: "complete_at",
                    html: function (item) {
                        return moment.unix(item.complete_at).format('YYYY-MM-DD HH:mm:ss')
                    }
                }, {
                    key: 'state_string',
                    title: "状态",
                    sort_key: "state_string"
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                var url = $scope.listUrl + 'builders/' + $state.params.id + '/builds/?order=-number&offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "构建表查询",
                    url: url,
                }).then(function (response) {
                    console.log(response.data);
                    return response.data;
                })
            })
            .enableExternData(false, function (item) {
                // return $scope.proxyHtml(item);
            })
            .setCtrlInitFunc(function ($ctrl) {
                $ctrl.buildAttrDetail = function (item) {
                    $state.go('app.cibuildattr', {id: item.buildid});
                };

                $ctrl.results_to_status = function (results) {
                    if (results == 0) {//success
                        return "成功";
                    }
                    else if (results == 1) {//warnings
                        return "警告";
                    }
                    else if (results == 2) {//failure
                        return "失败";
                    }
                    else if (results == 3) {//skipped
                        return "忽略";
                    }
                    else if (results == 4) {//exception
                        return "异常";
                    }
                    else if (results == 5) {//retry
                        return "重试";
                    }
                    else if (results == 6) {//cancelled
                        return "取消";
                    }
                    else {//unknown
                        return "未知";
                    }
                };

                $ctrl.results_to_class = function (results) {
                    if (results == 0) {//success
                        return "results_SUCCESS";
                    }
                    else if (results == 1) {//warnings
                        return "results_WARNINGS";
                    }
                    else if (results == 2) {//failure
                        return "results_FAILURE";
                    }
                    else if (results == 3) {//skipped
                        return "results_SKIPPED";
                    }
                    else if (results == 4) {//exception
                        return "results_EXCEPTION";
                    }
                    else if (results == 5) {//retry
                        return "results_RETRY";
                    }
                    else if (results == 6) {//cancelled
                        return "results_CANCELLED";
                    }
                    else {//unknown
                        return "results_UNKNOWN";
                    }
                };
            });
    }
]);
app.controller('ciLogModalCtrl', ['$rootScope', '$scope', '$http', '$modalInstance', 'msLocalStorage', '$timeout', 'toaster', 'items',
    function ($rootScope, $scope, $http, $modalInstance, msLocalStorage, $timeout, toaster, items) {
        $scope.aceOption = {
            theme: 'monokai',
            mode: 'sh',
            onLoad: function (_ace) {
                // HACK to have the ace instance in the scope...
                $scope.modeChanged = function () {
                    _ace.getSession().setMode("ace/mode/sh");
                };
            }
        };
        $scope.ciAttrLogModal = {};
        $http({
            method: 'GET',
            err_title: "构建日志查询",
            url: '/v1/buildbot/steps/' + items.stepid + '/logs/',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.ciLogList = response.data.results;
                $scope.ciAttrLogModal.log = $scope.ciLogList[0];
            } else {
                toaster.pop('error', '构建日志查询', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
            }
        }, function errorCallback(response) {

        });

        $scope.$watch('ciAttrLogModal.log', function (newVal, oldVal) {
            if (newVal) {
                $http({
                    method: 'GET',
                    err_title: "构建日志详情",
                    url: '/v1/buildbot/logs/' + newVal.logid + '/contents/',
                    data: ''
                }).then(function successCallback(response) {
                    var log_type = newVal.type;
                    if (log_type == 'h') {
                        $scope.content = response.data.results[0].content;
                    }
                    else {
                        var i, len, line, lines, logclass, offset, ret;
                        var content = response.data.results;
                        ret = [];
                        if (content.length === 0) {
                            $scope.lines = ret;
                            return;
                        }
                        offset = 0;
                        lines = content[0].content.split("\n");
                        if (lines.length > 1) {
                            lines.pop();
                        }
                        for (i = 0, len = lines.length; i < len; i++) {
                            line = lines[i];
                            logclass = "o";
                            if (line.length > 0 && (newVal.type === 's')) {
                                logclass = line[0];
                                line = line.slice(1);
                            }
                            ret.push({
                                index: offset + i,
                                content: line,
                                "class": "log_" + logclass
                            });
                            offset += 1;
                        }
                        $scope.lines = ret;
                    }
                }, function errorCallback(response) {

                });
            }
        });

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
app.controller('cIBuildAttrCIController', ['$rootScope', '$scope', '$state', '$http', '$modal', '$log', 'toaster', 'msLocalStorage',
    function ($rootScope, $scope, $state, $http, $modal, $log, toaster, msLocalStorage) {
        $scope.listUrl = '/v1/buildbot/project/' + msLocalStorage.get("projectId") + '/';
        $scope.builds_steps_options = new msTables.Option()
            .enableItemChecks(false, 'stepid')
            .enableSearch(false)
            .withFields(
                [{
                    key: 'number',
                    title: "Number",
                    sort_key: "number"
                }, {
                    key: 'name',
                    title: '名称',
                    sort_key: 'name'
                }, {
                    title: "开始时间",
                    sort_key: "started_at",
                    html: function (item) {
                        return moment.unix(item.started_at).format('YYYY-MM-DD HH:mm:ss')
                    }
                }, {
                    title: "结束时间",
                    sort_key: "complete_at",
                    html: function (item) {
                        return moment.unix(item.complete_at).format('YYYY-MM-DD HH:mm:ss')
                    }
                }, {
                    key: 'state_string',
                    title: "状态",
                    sort_key: "state_string"
                }, {
                    title: "日志",
                    can_hide: false,
                    class: 'ms-table-operate',
                    html: function (item) {
                        return '<a class="btn btn-link fa fa-download" ' +
                            'style="padding: 0;color: #428bca;" ' +
                            'ng-click="$ctrl.selectCILog($item)"></a>';
                    }
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                var url = '/v1/buildbot/builds/' + $state.params.id + '/steps/?offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "构建步骤查询",
                    url: url,
                }).then(function (response) {
                    // console.log(response.data);
                    return response.data;
                })
            })
            .enableExternData(false, function (item) {
                // return $scope.proxyHtml(item);
            })
            .setCtrlInitFunc(function ($ctrl) {
                $ctrl.selectCILog = function (ciLogObj) {
                    $scope.items = (ciLogObj == null || ciLogObj == "" ||
                    typeof(ciLogObj) == "undefined") ? {} : ciLogObj;
                    var modalInstance = $modal.open({
                        templateUrl: 'tpl/buildbot_logview.html',
                        controller: 'ciLogModalCtrl',
                        size: 'lg',
                        resolve: {
                            items: function () {
                                return $scope.items;
                            }
                        }
                    });

                    modalInstance.result.then(function (selectedItem) {

                    }, function () {
                        $log.info('关闭时间: ' + new Date());
                    });
                };
            });

        $http({
            method: 'GET',
            err_title: "构建属性查询",
            url: '/v1/buildbot/builds/' + $state.params.id + '/properties/',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.buildProperties = response.data;
            } else {
                toaster.pop('error', '构建属性查询', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
            }
        }, function errorCallback(response) {

        });
    }
]);

app.controller('cIBuildRequestsCIController', ['$rootScope', '$scope', '$state', '$http', '$log', 'toaster', 'msLocalStorage',
    function ($rootScope, $scope, $state, $http, $log, toaster, msLocalStorage) {
        $scope.listUrl = '/v1/buildbot/project/' + msLocalStorage.get("projectId") + '/';

        $http({
            method: 'GET',
            err_title: "持续集成构建请求查询",
            url: '/v1/buildbot/buildsets/' + $state.params.id + '/properties/',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.buildRequestsProperties = response.data;
            } else {
                toaster.pop('error', '持续集成构建请求', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
            }
        }, function errorCallback(response) {

        });
    }
]);