/**
 * Created by lidukang on 2016/8/5.
 * 警告管理-警告设置
 */
'use strict';
app.controller('emergencyruleController', ['$rootScope','$scope', '$filter', '$http','$state',
    'msLocalStorage', 'editableOptions', 'editableThemes', 'toaster',
    function ($rootScope,$scope, $filter, $http,$state,  msLocalStorage, editableOptions, editableThemes, toaster) {
        editableThemes.bs3.inputClass = 'input-sm';
        editableThemes.bs3.buttonsClass = 'btn-sm';
        editableOptions.theme = 'bs3';

        /**
         * 用户列表查询
         */
        $http({
            method: 'GET',
            err_title:"用户列表查询错误",
            url: '/v1/user-manage/user/?limit=all',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.userItems = response.data.results;
            }
        });

        /**
         * 告警人员
         * @param alarm
         * @returns {string}
         */
        $scope.userShowStatus = function (alarm) {
            var selected = [];
            angular.forEach($scope.userItems, function (user) {
                if (alarm.staff.indexOf(user.id) >= 0) {
                    selected.push(user.username);
                }
            });
            return selected.length ? selected.join(', ') : '暂无';
        };

        /**
         * 告警设置列表查询
         */
        $scope.alarmRuleTable = function () {
            $http({
                method: "GET",
                err_title:"查询告警设置列表",
                url: '/v1/alarm/project/' + msLocalStorage.get("projectId") + '/rule/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.alarmRuleModal = response.data.results;
                    angular.forEach($scope.alarmRuleModal, function (data, index, array) {
                        $scope.alarmRuleModal[index]['operating_perm'] = [];
                        if (data.is_add) {
                            $scope.alarmRuleModal[index].operating_perm.push(0);
                        }
                        if (data.is_del) {
                            $scope.alarmRuleModal[index].operating_perm.push(1);
                        }
                        if (data.is_update) {
                            $scope.alarmRuleModal[index].operating_perm.push(2);
                        }
                        if(data.staff){
                            // $scope.alarmRuleModal[index].staff=[];
                            angular.forEach(data.staff,function (dataStaff,indexStaff,arrayStaff) {
                                $scope.alarmRuleModal[index].staff.push(dataStaff.id);
                            });
                        }
                    });
                } else {
                    toaster.pop('error', '查询告警设置列表', '失败原因:' + response.data.message,$rootScope.errorDwellTime);
                }
            });
        };

        $scope.alarmRuleTable();

        $scope.alarmTimes = [
            {value: 1, text: '全部'},
            {value: 2, text: '工作日'},
            {value: 3, text: '周末'}
        ];

        /**
         * 告警时间
         * @param alarm
         * @returns {string}
         */
        $scope.alarmTimeShowStatus = function (alarm) {
            var selected = [];
            if (alarm.time_type) {
                angular.forEach($scope.alarmTimes, function (data, index, array) {
                    if (data.value === alarm.time_type) {
                        selected.push(data.text);
                    }
                });
            }
            return selected.length ? selected.join(', ') : '暂无';
        };

        $scope.jurisdictions = [
            {value: 0, text: '添加'},
            {value: 1, text: '修改'},
            {value: 2, text: '删除'}
        ];

        /**
         * 权限
         * @param alarm
         * @returns {string}
         */
        $scope.jurisdictionShowStatus = function (alarm) {
            var selected = [];
            angular.forEach($scope.jurisdictions, function (jur) {
                if(alarm.operating_perm){
                    if (alarm.operating_perm.indexOf(jur.value) >= 0) {
                        selected.push(jur.text);
                    }
                }
            });
            return selected.length ? selected.join(', ') : '暂无';
        };

        $scope.alarmStatuses = [
            {value: true, text: '启用'},
            {value: false, text: '禁用'}
        ];

        /**
         * 告警状态
         * @param alarm
         * @returns {string}
         */
        $scope.alarmStatusShowStatus = function (alarm) {
            var selected = [];
            angular.forEach($scope.alarmStatuses, function (data, index, array) {
                if (alarm.status === data.value) {
                    selected.push(data.text);
                }
            });
            return selected.length ? selected.join(', ') : '暂无';
        };

        /**
         * 获取媒介类型
         */
        $http({
            method: 'GET',
            err_title:"用户列表查询错误",
            url: '/v1/alarm/project/' + msLocalStorage.get("projectId") + '/type/?limit=all',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.mediaTypeGroup = response.data.results;
            }
        });

        /**
         * 媒介类型
         * @param alarm
         * @returns {*}
         */
        $scope.mediaTypeShowGroup = function (alarm) {
            var selected = [];
            angular.forEach($scope.mediaTypeGroup, function (type) {
                if (alarm.media_type === type.id) {
                    selected.push(type.name);
                }
            });
            return selected.length ? selected.join(', ') : '暂无';
        };

        $scope.saveAlarmRule = function (data, id) {
            var tempAlarmRule = angular.extend(data, {id: id});
            if(tempAlarmRule.staff.length>0){
                $http({
                    method: 'PUT',
                    err_title:"告警设置",
                    url: 'v1/alarm/project/' + msLocalStorage.get("projectId") + '/rule/' + id + '/',
                    data: tempAlarmRule
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        toaster.pop('success', '告警设置', '保存成功');
                        $scope.alarmRuleTable();
                    } else {
                        toaster.pop('error', '告警设置', '保存失败原因:' + response.data.message,$rootScope.errorDwellTime);
                    }
                });
            }else {
                toaster.pop('error', '告警设置保存失败', '至少选择一个名告警人员',$rootScope.errorDwellTime);
                $scope.alarmRuleTable();
            }
        };
    }]);