/**
 * Created by lidukang on 2016/8/5.
 * 用户组
 */
'use strict';
/***
 * 模态框控制器
 */
app.controller('projectListModalCtrl', ['$scope', '$http', '$modalInstance', '$timeout', 'toaster', 'items',
    function ($scope, $http, $modalInstance, $timeout, toaster, items) {
        $scope.items = {};
        $http({
            method: 'GET',
            err_title: "代理列表查询",
            url: '/v1/proxy-manage/proxy/?limit=all&ordering=proxy_name',
            data: ''
        }).then(function successCallback(response) {
            if (response.status >= 200 && response.status <= 299) {
                $scope.proxyItems = response.data.results;
            }
        });
        $scope.modalTitle = '添加项目';
        $scope.proxysFlag = true;
        if (!$.ms.isEmptyObject(items)) {
            $scope.modalTitle = '修改项目';
            $http({
                method: 'GET',
                err_title: "查询项目",
                url: '/v1/permissions/project/' + items.id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    $scope.items = response.data;
                }
            });
        }

        $scope.$watch('items.proxys', function (newVal, oldVal) {
            if (newVal instanceof Array) {
                if (newVal.length > 0) {
                    $scope.proxysFlag = false;
                } else {
                    $scope.proxysFlag = true;
                }
            } else {
                $scope.proxysFlag = true;
            }
        }, true);

        /**
         * 清空表单
         */
        $scope.clearProject = function () {
            $scope.originItems = angular.copy(items);
            if (!$.ms.isEmptyObject(items)) {
                $scope.items = $scope.originItems;
            } else {
                $scope.items = {};
            }

        };

        $scope.ok = function () {
            $modalInstance.close($scope.items);
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);
app.controller('projectListController', ['$rootScope', '$scope', '$compile', '$state', '$http', '$modal', '$log', '$q', 'toaster',
    function ($rootScope, $scope, $compile, $state, $http, $modal, $log, $q, toaster) {
        $scope.listUrl = '/v1/permissions/project/';
        var editBtnOpt = {
            text: '编辑',
            class: 'color-2',
            perm: "",
            color: '#004740',
            action: function () {
                var items = $scope.table_options.getCheckedItems();
                $scope.newEditProject(items[0]);
            }
        };
        var deleteBtnOpt = {
            text: '删除',
            class: 'color-4',
            perm: "",
            color: '#d2181c',
            action: function (e, dt, node, config) {
                var items = $scope.table_options.getCheckedItems();
                $scope.delProject(items);
            }
        };
        $scope.table_options = new msTables.Option()
            .withButtons([{
                hide: false,
                disable: false,
                text: '添加',
                perm: "",
                class: 'color-1',
                color: '#2f5398',
                action: function (button) {
                    $scope.newEditProject('');
                }
            },
                editBtnOpt, deleteBtnOpt, {
                    text: '展示/隐藏',
                    extend: 'colvis',
                    perm: "",
                    class: 'color-0'
                }
            ])
            .setCheckedChangeFunc(function (items) {
                if (items.length == 1) {
                    editBtnOpt.disable = false;
                } else {
                    editBtnOpt.disable = true;
                }
                if (items.length > 0) {
                    deleteBtnOpt.disable = false;
                } else {
                    deleteBtnOpt.disable = true;
                }
            })
            .enableSearch(true)
            .withFields(
                [{
                    key: "name",
                    title: "组名",
                    sort_key: "name",
                    can_hide: false
                }, {
                    key: "desc",
                    title: "备注",
                    sort_key: "desc",
                    class: 'long-text',
                    toolTip: function (item) {
                        return item.desc;
                    }
                }, {
                    key: "create_time",
                    title: "创建时间",
                    sort_key: "create_time"
                }, {
                    title: "操作",
                    can_hide: false,
                    class: 'ms-table-operate',
                    html: function () {
                        return '<ms-ext-btn buttons="$ctrl.tabBtn" item="$item"/>';
                    }
                }])
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                var url = $scope.listUrl + '?offset=' + offset + '&limit=' + limit;
                if (sort_key) {
                    url += "&ordering=" + sort_key;
                }
                if (search_keyword) {
                    url += "&search=" + search_keyword;
                }
                return $http({
                    method: "GET",
                    err_title: "项目列表查询",
                    url: url,
                }).then(function (response) {
                    return response.data;
                })
            })
            .enableExternData(true, function (item) {
                return $scope.proxysHtml(item);
            })
            .setCtrlInitFunc(function ($ctrl) {
                $ctrl.tabBtn = [
                    {
                        name: '批量执行',
                        click: $scope.batchExecution,
                        perm: "",
                    },
                    {
                        name: '编辑',
                        click: $scope.newEditProject,
                        perm: "",
                    },
                    {
                        name: '删除',
                        click: $scope.delProject,
                        perm: "",
                    }
                ];
            });

        $scope.proxysHtml = function (data, type, full, meta) {
            var dd = '';
            angular.forEach(data.proxys, function (proxysData, proxysIndex, proxysArray) {
                dd += '<dd>' + proxysData.proxy_name + '</dd>';
            });
            return '<dl class="user-project"><dt>代理:</dt>' + dd + '</dl>';
        };

        /**
         * 新增修改项目
         * @param projectObj
         */
        $scope.newEditProject = function (projectObj) {
            $scope.items = (projectObj == null || projectObj == "" ||
            typeof(projectObj) == "undefined") ? {} : projectObj;
            var modalInstance = $modal.open({
                templateUrl: 'projectListTpl',
                controller: 'projectListModalCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var method = "POST", url = '/v1/permissions/project/';
                if (selectedItem.hasOwnProperty('id')) {
                    method = 'PUT';
                    url += selectedItem.id + '/';
                }
                $http({
                    method: method,
                    err_title: "创建或修改项目",
                    url: url,
                    data: selectedItem
                }).then(function successCallback(response) {
                    if (response.status >= 200 && response.status <= 299) {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('success', '修改项目', '保存成功');
                        } else {
                            toaster.pop('success', '新增项目', '保存成功');
                        }
                        $scope.table_options.reload();//重新渲染表格
                    } else {
                        if (selectedItem.hasOwnProperty('id')) {
                            toaster.pop('error', '修改项目', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        } else {
                            toaster.pop('error', '新增项目', '保存失败原因:' + response.data.message, $rootScope.errorDwellTime);
                        }
                    }
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

        /**
         * 删除项目
         * @param projectObj
         */
        $scope.delProject = function (projectObj) {
            if (!(projectObj instanceof Array)) {
                projectObj = (projectObj == null || projectObj == "" ||
                typeof(projectObj) == "undefined") ? [] : [projectObj];
            }
            projectObj = (projectObj == null || projectObj == "" ||
            typeof(projectObj) == "undefined") ? [] : projectObj;
            $scope.items = projectObj;
            var modalInstance = $modal.open({
                templateUrl: 'delProjectTpl',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function () {
                        return $scope.items;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                var defered_array = [];
                angular.forEach(selectedItem, function (data, index, array) {
                    defered_array.push($scope.deleteProject(data.id));
                });
                $q.all(defered_array).then(function () {
                    $scope.table_options.reload();//重新渲染表格
                });
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };
        /**
         * 删除项目
         * @param id
         */
        $scope.deleteProject = function (id) {
            var defer = $q.defer();
            $http({
                method: 'DELETE',
                err_title: "删除项目",
                url: '/v1/permissions/project/' + id + '/',
                data: ''
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    toaster.pop('success', '删除项目', '删除成功');
                } else {
                    toaster.pop('error', '删除项目', '失败原因:' + response.data.message, $rootScope.errorDwellTime);
                }
                defer.resolve();
            }, function errorCallback(response) {
                defer.resolve();
            });
            return defer.promise;
        };

        /**
         * 批量执行
         * @param batchExecObj
         */
        $scope.batchExecution = function (batchExecObj) {
            var modalInstance = $modal.open({
                templateUrl: 'projectBatchExecutionTpl',
                controller: 'projectBatchExecModalCtrl',
                size: 'batch-exec',
                resolve: {
                    items: batchExecObj
                }
            });

            modalInstance.result.then(function (selectedItem) {
                $scope.selected = selectedItem;
            }, function () {
                $log.info('关闭时间: ' + new Date());
            });
        };

    }
]);

app.controller('projectBatchExecModalCtrl', ['$rootScope', '$scope', '$http', '$location', '$modalInstance', 'toaster', '$sce', 'items',
    function ($rootScope, $scope, $http, $location, $modalInstance, toaster, $sce, items) {
        $scope.disabled = true;
        var id = 0;
        $scope.content_htmls = [];
        $scope.message = "初始化中...";
        var last_count = 0;
        var proxy_count = 0;

        function add_html(html) {
            $('.batch-exec-msg').append(html);
            $('.batch-exec-msg').append("<br>");
            $scope.$broadcast("scroll-bottom");
        }

        var url = "/v1/proxy-manage/project/" + items.id + "/proxy/" + "all" + "/execute-cmd-token/";
        $http({
            method: "POST",
            err_title: "连接失败",
            url: url
        }).then(function successCallback(response) {
            var options = {};
            options.enters = response.data.results;
            proxy_count = response.data.results.length;
            options.onmessage = $scope.onmessage;
            options.onclose = $scope.onclose;
            $scope.executeCmd = new $.ms.ExecuteCmd(options);
            $scope.content_htmls = [];
            $scope.disabled = false;
            $scope.message = "";
        });
        $scope.onclose = function () {
            $scope.disabled = true;
            $scope.message = "连接已关闭";
        };
        $scope.onmessage = function (message) {
            $scope.$apply(function () {
                console.log(message);
                var data = JSON.parse(message.data);
                var type = data.type;
                var html = "";
                last_count -= 1;
                if (last_count <= 0) {
                    $scope.disabled = false;
                    $scope.message = "";
                }
                else {
                    $scope.message = "执行中...(" + (proxy_count - last_count) + "/" + proxy_count + ")";
                }
                if (type == 'results') {

                    add_html('匹配主机: ' + data.asset_name.join(","));
                    add_html('<span style="color: yellow">Ansible> ' + data.command + '</span>');
                    data.results.forEach(function (item) {
                        if (item.success) {
                            add_html("<span style='color: green'>[ " + item.host + " => success]</span>\n");
                        }
                        else {
                            add_html("<span style='color: red'>[ " + item.host + " => failed]</span>\n");
                        }
                        var info = item.info.replace(/\n/g, "<br>");
                        add_html(info);
                    });
                }
                else if (type == "text") {
                    add_html(data.text);
                }
            })

        };
        $scope.sendMessage = function () {
            last_count = proxy_count;
            $scope.disabled = true;
            $scope.message = "执行中...(" + (proxy_count - last_count) + "/" + proxy_count + ")";

            var data = {
                pattern: $scope.ansible,
                command: $scope.command
            };
            $scope.executeCmd.send(data);
            $scope.command = '';
        };

        $scope.proxyKeyPress = function (event) {
            if (event.keyCode === 13 && !$scope.exec_form.$invalid) {
                $scope.sendMessage();
            }
        };

        $scope.ok = function () {
            $modalInstance.close($scope.items);
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);