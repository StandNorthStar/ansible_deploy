'use strict';

/* Filters */
// need load the moment.js to use this filter. 
angular.module('app')
    .filter('fromNow', function () {
        return function (date) {
            return moment(date).fromNow();
        }
    })
    .filter('fileNameLen', function () {
        return function (data, len) {
            var ext;
            if (data.length > len) {
                var houzhui = data.split('.');
                if (houzhui.length > 1) {
                    ext = "." + houzhui[houzhui.length - 1];
                }
                else {
                    ext = '';
                }
                data = data.substr(0, data.length - ext.length);
                len = len - 1 - ext.length;
                data = data.substr(0, len / 2) + "…" + data.substr(data.length - len / 2, len / 2) + ext;
                return data;

            }
            else {
                return data;
            }

        }
    })
    .filter('dic_filter', function () {
        return function (data, fields, value) {
            if (!data) {
                return data;
            }
            if (!angular.isArray(data)) {
                return data;
            }
            fields = fields.split(",");
            var res = [];
            data.forEach(function (item) {

                var find = fields.some(function (f) {
                    return item[f].indexOf(value) != -1;
                });
                if (find) {
                    res.push(item);
                }
            });
            return res;

        }
    });