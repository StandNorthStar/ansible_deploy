'use strict';


angular.module('app', [
    'ngAnimate',
    'ngAria',
    'ngCookies',
    'ngMessages',
    'ngResource',
    'ngSanitize',
    'ngTouch',
    'ngStorage',
    'ui.router',
    'ui.bootstrap',
    'ui.utils',
    'ui.load',
    'ui.jq',
    'oc.lazyLoad',
    'pascalprecht.translate',
    'ng-echarts',
    'toaster',
    'angular-bind-html-compile',
    'highcharts-ng',
    'ui.bootstrap.datetimepicker',
]).run(["$rootScope", "$state", function ($rootScope, $state) {
    $rootScope.CONFIG = window.CONFIG;
    $rootScope.$on("$stateChangeSuccess", function (event, toState, toParams, fromState, fromParams) {
        // $rootScope.app.settings.showChangeProject = !toState.hideChangeProject;
        $rootScope.app.settings.showChangeProject = true;
        $rootScope.title = 'MagicStack | ' + toState.title;
    });
    $rootScope.$on("$stateChangeStart", function (event, toState, toParams, fromState, fromParams) {
        // var perm = toState.perm;
        // console.log(perm);
        // if (!$.ms.checkPermissions(perm)) {
        //     console.log('权限');
        //     event.preventDefault();
        //     setTimeout(function () {
        //         $state.go("app.ui.overview");
        //     });
        // }else {
        //     console.log('llllllllllllllllll');
        // }
    })
}]);
