app.factory("msPlayback", ["$modal", function ($modal) {
    return function (args) {

        var modalInstance = $modal.open({
            templateUrl: 'tpl/ms_playback_modal.html',
            controller: 'playBackModalCtrl',
            size: 'playback',
            resolve: {
                args: function () {
                    return args
                }
            }
        });

        return modalInstance.result;
    }
}]);
app.controller('playBackModalCtrl', ['$rootScope', '$scope', 'msLocalStorage', '$modalInstance', '$http', 'toaster', 'args',
    function ($rootScope, $scope, msLocalStorage, $modalInstance, $http, toaster, args) {
        $scope.args = args;
        $scope.data = args.data;
        $scope.title = args.title || "";
        // Thanks http://stackoverflow.com/a/2998822
        $scope.zeroPad = function (num, size) {
            var s = "0" + num;
            return s.substr(s.length - size);
        };
        /**
         * 计算时间
         * @param millis
         * @returns {string}
         */
        $scope.buildTimeString = function (millis) {
            var hours = $scope.zeroPad(Math.floor(millis / (1000 * 60 * 60)), 2);
            millis -= hours * (1000 * 60 * 60);
            var minutes = $scope.zeroPad(Math.floor(millis / (1000 * 60)), 2);
            millis -= minutes * (1000 * 60);
            var seconds = $scope.zeroPad(Math.floor(millis / 1000), 2);
            return hours + ':' + minutes + ':' + seconds;
        };

        $scope.speed = '0';//播放速度
        $scope.beforeScrubberText = '';//播放进度Text
        $scope.afterScrubberText = '';//视频总时间
        $scope.scrubber = '0';//播放进度条
        function runPlayback(data) {
            var toggle = true;
            var totalTime = 0;
            var TICK = 33;
            var TIMESTEP = 33;
            var time = 33;
            var timer;
            var pos = 0;

            $scope.scrub = function () {
                var setPercent = $scope.scrubber;
                time = (setPercent / 100) * totalTime;
                $scope.restart(time);
            };

            function advance() {
                $scope.scrubber = Math.ceil((time / totalTime) * 100);
                $scope.beforeScrubberText = $scope.buildTimeString(time);
                $scope.$apply();
                for (; pos < timelist.length; pos++) {
                    if (timelist[pos] * 1000 <= time) {
                        term.write(data[timelist[pos]]);
                    } else {
                        break;
                    }
                }

                if (pos >= timelist.length) {
                    clearInterval(timer);
                }

                time += TIMESTEP;
            }

            $scope.pause = function (test) {
                if (!toggle && test) {
                    return;
                }
                if (toggle) {
                    clearInterval(timer);
                    toggle = !toggle;
                } else {
                    timer = setInterval(advance, TICK);
                    toggle = !toggle;
                }
            };

            $scope.setSpeed = function () {
                var speed = $scope.speed;
                if (speed == 0) {
                    TIMESTEP = TICK;
                } else if (speed < 0) {
                    TIMESTEP = TICK / -speed;
                } else {
                    TIMESTEP = TICK * speed;
                }
            };

            $scope.restart = function (millis) {
                clearInterval(timer);
                term.reset();
                time = millis;
                pos = 0;
                toggle = true;
                timer = setInterval(advance, TICK);
            };

            var term = new Terminal({
                cols: 120,
                rows: 24,
                useStyle: true,
                screenKeys: true
            });
            var timelist = [];
            for (var i in data) {
                totalTime = Math.max(totalTime, i);
                timelist.push(i);
            }
            timelist = timelist.sort(function (a, b) {
                return a - b
            });
            totalTime = totalTime * 1000;
            $scope.afterScrubberText = $scope.buildTimeString(totalTime);
            term.open(document.getElementById('terminal'));
            timer = setInterval(advance, TICK);
        }
        setTimeout(function () {
            runPlayback($scope.data);
        },300);


        $scope.ok = function () {
            $modalInstance.close($scope.args);
        };

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }]);