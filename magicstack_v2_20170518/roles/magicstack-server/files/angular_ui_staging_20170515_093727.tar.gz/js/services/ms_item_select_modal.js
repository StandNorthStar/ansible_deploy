app.factory("msItemSelect", ["$modal", function ($modal) {
    return function (args) {

        var modalInstance = $modal.open({
            templateUrl: 'tpl/ms_item_select_modal.html',
            controller: 'msItemSelectModalController',
            resolve: {
                args: function () {
                    return args
                }
            }
        });

        return modalInstance.result;
    }
}]);
app.controller('msItemSelectModalController', ['$rootScope', '$scope', '$http', '$state', '$modalInstance', 'args',
    function ($rootScope, $scope, $http, $state, $modalInstance, args) {
        $scope.url = args.url;
        $scope.title = args.title;
        $scope.fields = args.fields;
        $scope.keywork = "";

        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };

        $scope.ok = function () {
            $modalInstance.close($scope.table_options.getCheckedItems());
        };
        function filterOrderData(data, sort_key, search_keyword) {
            var result = [];
            data.forEach(function (item) {
                var find = args.fields.some(function (field) {
                    if (field.key) {
                        return item[field.key].indexOf(search_keyword) != -1;
                    }
                    else {
                        return false;
                    }
                });
                if (find) {
                    result.push(item);
                }
            });
            if (sort_key) {
                if (sort_key[0] == '-') {
                    sort_key = sort_key.slice(1);
                    result = _(result).sortBy(sort_key).reverse();
                }
                else {
                    result = _(result).sortBy(sort_key);
                }


            }

            return {count: result.length, results: result, no_change_select: true};
        }

        $scope.table_options = new msTables.Option()
            .setCheckedChangeFunc(function (items) {

            })
            .enableSearch(true)
            .setPageSize(100)
            .withFields($scope.fields)
            .showPagination(false)
            .setLoadDataFunc(function (offset, limit, sort_key, search_keyword) {
                if (args.datas) {
                    return filterOrderData(args.datas, sort_key, search_keyword);
                }
                else {
                    return {count: 0, results: [], no_change_select: true}
                }
            })
            .setCtrlInitFunc(function ($ctrl) {
                if (args.model && angular.isArray(args.model)) {
                    var check_items = {};
                    args.model.forEach(function (item) {
                        check_items[item[args.key]] = true;
                    });
                    angular.extend($ctrl.check_items, check_items);
                }

            });
    }]
);