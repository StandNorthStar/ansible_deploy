/*
 此文件为自动生成，请勿直接修改。权限配置请修改服务器端permissions.xml文件,并执行python manage.py permissions_gen

|--项目管理(PROJECT_MANAGE_MENU)
|  |--项目列表(PROJECT_LIST_MENU)
|  |--用户列表(USER_LIST_MENU)
|  |  |--查询用户(USER_QUERY)
|  |  |--创建用户(USER_CREATE_ACTION)
|  |  |--编辑用户(USER_EDIT_ACTION)
|  |  |--删除用户(USER_DELETE_ACTION)
|  |--资产列表(ASSET_LIST_MENU)
|  |  |--查询资产(ASSET_QUERY)
|  |  |--添加资产(ASSET_CREATE_ACTION)
|  |  |--编辑资产(ASSET_EDIT_ACTION)
|  |  |--连接资产(ASSET_CONNECT_ACTION)
|  |  |--删除资产(ASSET_DELETE_ACTION)
|  |  |--更新资产(ASSET_UPDATE_ACTION)
|  |  |--开机(ASSET_POWER_ACTION)
|  |  |--重启(ASSET_REBOOT_ACTION)
|  |  |--关机(ASSET_SHUTDOWN_ACTION)
|  |  |--重装系统(ASSET_REBUILD_ACTION)
|  |  |--启用禁用(ASSET_ENABLE_OR_DISABLE_ACTION)
|  |  |--批量执行(ASSET_BATCH_EXEC_ACTION)
|  |  |--变更项目(ASSET_CHANGE_PROJECT_ACTION)
|  |--机房列表(ASSET_IDC_MENU)
|  |  |--查询机房(ASSET_IDC_QUERY)
|  |  |--添加机房(ASSET_IDC_CREATE_ACTION)
|  |  |--编辑机房(ASSET_IDC_EDIT_ACTION)
|  |  |--删除机房(ASSET_IDC_DELETE_ACTION)
|  |  |--查看详情(ASSET_IDC_DETAIL_ACTION)
|  |--虚拟机列表(VM_LIST_MENU)
|  |  |--查询虚拟机(VM_QUERY)
|  |  |--添加虚拟机(VM_CREATE_ACTION)
|  |  |--编辑虚拟机(VM_EDIT_ACTION)
|  |  |--删除虚拟机(VM_DELETE_ACTION)
|  |  |--连接虚拟机(VM_CONNECT_ACTION)
|  |  |--更新虚拟机(VM_UPDATE_ACTION)
|--应用管理(APP_MANAGE_MENU)
|  |--模块剧本(APP_MODULE_MENU)
|  |  |--剧本上传(APP_MODULE_UPLOAD_ACTION)
|  |  |--剧本查看(APP_MODULE_LIST_QUERY)
|  |  |--部署创建(APP_MODULE_DEPLOY_CREATE_ACTION)
|  |  |--部署查询(APP_MODULE_DEPLOY_LIST_QUERY)
|  |  |--部署回放(APP_MODULE_DEPLOY_REPLAY_ACTION)
|  |--容器部署(APP_CONTAINER_MENU)
|--任务管理(TASK_MANAGE_MENU)
|  |--常规任务(TASK_COMMON_MENU)
|  |  |--查询常规任务(TASK_COMMON_QUERY)
|  |  |--添加常规任务(TASK_COMMON_CREATE_ACTION)
|  |  |--添加常规任务(无需审批)(TASK_COMMON_CREATE_IMM)
|  |  |--添加常规任务(审批)(TASK_COMMON_CREATE_APPROVE)
|  |  |--查看任务明细(TASK_COMMON_DETAIL_ACTION)
|  |  |--编辑常规任务(TASK_COMMON_EDIT_ACTION)
|  |  |--编辑常规任务(无需审批)(TASK_COMMON_EDIT_IMM)
|  |  |--编辑常规任务(审批)(TASK_COMMON_EDIT_APPROVE)
|  |  |--删除常规任务(TASK_COMMON_DELETE_ACTION)
|  |  |--删除常规任务(无需审批)(TASK_COMMON_DELETE_IMM)
|  |  |--删除常规任务(审批)(TASK_COMMON_DELETE_APPROVE)
|  |  |--禁用常规任务(TASK_COMMON_PAUSE_ACTION)
|  |  |--禁用常规任务(无需审批)(TASK_COMMON_PAUSE_IMM)
|  |  |--禁用常规任务(审批)(TASK_COMMON_PAUSE_APPROVE)
|  |  |--启用常规任务(TASK_COMMON_RESUME_ACTION)
|  |  |--启用常规任务(无需审批)(TASK_COMMON_RESUME_IMM)
|  |  |--启用常规任务(审批)(TASK_COMMON_RESUME_APPROVE)
|  |  |--查看常规任务执行结果(TASK_COMMON_EXEC_INFO_QUERY)
|  |  |--常规任务回放(TASK_COMMON_REPLAY_QUERY)
|  |--高级任务(TASK_ADVANCED_MENU)
|  |  |--查询高级任务(TASK_ADVANCED_QUERY)
|  |  |--添加高级任务(TASK_ADVANCED_CREATE_ACTION)
|  |  |--添加高级任务(无需审批)(TASK_ADVANCED_CREATE_IMM)
|  |  |--添加高级任务(审批)(TASK_ADVANCED_CREATE_APPROVE)
|  |  |--查看高级任务明细(TASK_ADVANCED_DETAIL_ACTION)
|  |  |--编辑高级任务(TASK_ADVANCED_EDIT_ACTION)
|  |  |--编辑高级任务(无需审批)(TASK_ADVANCED_EDIT_IMM)
|  |  |--编辑高级任务(审批)(TASK_ADVANCED_EDIT_APPROVE)
|  |  |--删除高级任务(TASK_ADVANCED_DELETE_ACTION)
|  |  |--删除高级任务(无需审批)(TASK_ADVANCED_DELETE_IMM)
|  |  |--删除高级任务(审批)(TASK_ADVANCED_DELETE_APPROVE)
|  |  |--禁用高级任务(TASK_ADVANCED_PAUSE_ACTION)
|  |  |--禁用高级任务(无需审批)(TASK_ADVANCED_PAUSE_IMM)
|  |  |--禁用高级任务(审批)(TASK_ADVANCED_PAUSE_APPROVE)
|  |  |--启用高级任务(TASK_ADVANCED_RESUME_ACTION)
|  |  |--启用高级任务(无需审批)(TASK_ADVANCED_RESUME_IMM)
|  |  |--启用高级任务(审批)(TASK_ADVANCED_RESUME_APPROVE)
|  |  |--查看高级任务执行结果(TASK_ADVANCED_EXEC_INFO_QUERY)
|  |  |--高级任务回放(TASK_ADVANCED_REPLAY_QUERY)
|  |--路径/文件备份(BACKUP_FILE_MENU)
|  |  |--查询文件备份(BACKUP_FILE_QUERY)
|  |  |--添加文件备份(BACKUP_FILE_CREATE_ACTION)
|  |  |--添加文件备份(无需审批)(BACKUP_FILE_CREATE_IMM)
|  |  |--添加文件备份(审批)(BACKUP_FILE_CREATE_APPROVE)
|  |  |--查看明细(BACKUP_FILE_DETAIL_ACTION)
|  |  |--编辑文件备份(BACKUP_FILE_EDIT_ACTION)
|  |  |--编辑文件备份(无需审批)(BACKUP_FILE_EDIT_IMM)
|  |  |--编辑文件备份(审批)(BACKUP_FILE_EDIT_APPROVE)
|  |  |--删除文件备份(BACKUP_FILE_DELETE_ACTION)
|  |  |--删除文件备份(无需审批)(BACKUP_FILE_DELETE_IMM)
|  |  |--删除文件备份(审批)(BACKUP_FILE_DELETE_APPROVE)
|  |  |--文件备份执行记录查询(BACKUP_FILE_EXEC_INFO_QUERY)
|  |  |--文件备份回放(BACKUP_FILE_REPLAY_QUERY)
|  |  |--文件备份下载(BACKUP_FILE_DOWNLOAD_ACTION)
|  |--MySQL备份(BACKUP_DATABASE_MENU)
|  |  |--查询数据库备份(BACKUP_DATABASE_QUERY)
|  |  |--添加数据库备份(BACKUP_DATABASE_CREATE_ACTION)
|  |  |--添加数据库备份(无需审批)(BACKUP_DATABASE_CREATE_IMM)
|  |  |--添加数据库备份(审批)(BACKUP_DATABASE_CREATE_APPROVE)
|  |  |--查看明细(BACKUP_DATABASE_DETAIL_ACTION)
|  |  |--编辑数据库备份(BACKUP_DATABASE_EDIT_ACTION)
|  |  |--编辑数据库备份(无需审批)(BACKUP_DATABASE_EDIT_IMM)
|  |  |--编辑数据库备份(审批)(BACKUP_DATABASE_EDIT_APPROVE)
|  |  |--删除数据库备份(BACKUP_DATABASE_DELETE_ACTION)
|  |  |--删除数据库备份(无需审批)(BACKUP_DATABASE_DELETE_IMM)
|  |  |--删除数据库备份(审批)(BACKUP_DATABASE_DELETE_APPROVE)
|  |  |--数据库备份执行记录查询(BACKUP_DATABASE_EXEC_INFO_QUERY)
|  |  |--数据库备份回放(BACKUP_DATABASE_REPLAY_QUERY)
|  |  |--数据库备份下载(BACKUP_DATABASE_DOWNLOAD_ACTION)
|--授权管理(AUTH_MANAGE_MENU)
|  |--sudo(AUTH_SUDO_MENU)
|  |  |--查询SUDO(AUTH_SUDO_QUERY)
|  |  |--添加SUDO(AUTH_SUDO_CREATE_ACTION)
|  |  |--编辑SUDO(AUTH_SUDO_EDIT_ACTION)
|  |  |--删除SUDO(AUTH_SUDO_DELETE_ACTION)
|  |--系统用户(AUTH_ROLE_MENU)
|  |  |--查询系统用户(AUTH_ROLE_QUERY)
|  |  |--添加系统用户(AUTH_ROLE_CREATE_ACTION)
|  |  |--编辑系统用户(AUTH_ROLE_EDIT_ACTION)
|  |  |--推送系统用户(AUTH_ROLE_PUSH_ACTION)
|  |  |--下载秘钥(AUTH_ROLE_DOWNLOAD_KEY_ACTION)
|  |  |--删除系统用户(AUTH_ROLE_DELETE_ACTION)
|  |--授权规则(AUTH_RULE_MENU)
|  |  |--查询授权规则(AUTH_RULE_QUERY)
|  |  |--添加授权规则(AUTH_RULE_CREATE_ACTION)
|  |  |--编辑授权规则(AUTH_RULE_EDIT_ACTION)
|  |  |--删除授权规则(AUTH_RULE_DELETE_ACTION)
|--代理管理(PROXY_MANAGE_MENU)
|  |--查看代理(PROXY_LIST_MENU)
|  |  |--查询代理(PROXY_QUERY)
|  |  |--添加代理(PROXY_CREATE_ACTION)
|  |  |--编辑代理(PROXY_EDIT_ACTION)
|  |  |--执行命令(PROXY_EXEC_COMMAND_ACTION)
|  |  |--删除代理(PROXY_DELETE_ACTION)
|--日志管理(LOG_MANAGE_MENU)
|  |--日志审计(LOG_LIST_MENU)
|  |  |--查询在线记录(LOG_ASSET_ONLINE_QUERY)
|  |  |--查询登录历史记录(LOG_ASSET_LOGIN_QUERY)
|  |  |--查询告警事件(LOG_ALARM_QUERY)
|  |  |--查询操作记录(LOG_OPERATOR_QUERY)
|  |  |--命令执行历史(LOG_COMMAND_HISTORY_QUERY)
|  |  |--阻断命令行(LOG_CONNECT_KILL_ACTION)
|  |  |--操作回放(LOG_CONNECT_RECORD_ACTION)
|--我的工作(WORKFLOW_MENU)
|  |--我起草的(WORKFLOW_MY_CREATE_MENU)
|  |--待处理的(WORKFLOW_WILL_DO_MENU)
|  |--已完成的(WORKFLOW_COMPLETE_MENU)
|--告警管理(ALARM_MANAGE_MENU)
|  |--告警媒介类型(ALARM_TYPE_MENU)
|  |  |--查询告警媒介类型(ALARM_TYPE_QUERY)
|  |  |--添加告警媒介类型(ALARM_TYPE_CREATE_ACTION)
|  |  |--编辑告警媒介类型(ALARM_TYPE_EDIT_ACTION)
|  |  |--删除告警媒介类型(ALARM_TYPE_DELETE_ACTION)
|  |--告警设置(ALARM_SETTING_MENU)
|  |  |--查询告警设置(ALARM_SETTING_QUERY)
|  |  |--编辑告警设置(ALARM_SETTING_EDIT_ACTION)
|--上传下载(UPLOAD_DOWNLOAD_MANAGE_MENU)
|  |--文件上传(FILE_UPLOAD_MENU)
|  |  |--查询上传文件(FILE_UPLOAD_QUERY)
|  |  |--上传文件(FILE_UPLOAD_ACTION)
|  |--文件下载(FILE_DOWNLOAD_MENU)
|  |  |--查询下载文件(FILE_DOWNLOAD_QUERY)
|  |  |--下载文件(FILE_DOWNLOAD_ACTION)
|--插件管理(PLUGIN_MANAGE_MENU)
|  |--插件列表(PLUGIN_LIST_MENU)
|  |  |--查询插件(PLUGIN_QUERY_ACTION)
|  |  |--添加插件(PLUGIN_CREATE_ACTION)
|  |  |--编辑插件(PLUGIN_EDIT_ACTION)
|  |  |--删除插件(PLUGIN_DELETE_ACTION)
|  |  |--插件登录(PLUGIN_CONNECT_ACTION)
|--全局设置(GLOBAL_SETTINGS_MENU)
|  |--认证(GLOBAL_SETTINGS_AUTH_MENU)
 */
var ms_permission_kv = {
    "PROJECT_MANAGE_MENU": "2",//项目管理
    "PROJECT_LIST_MENU": "3",//项目列表
    "USER_LIST_MENU": "4",//用户列表
    "USER_QUERY": "160",//查询用户
    "USER_CREATE_ACTION": "161",//创建用户
    "USER_EDIT_ACTION": "162",//编辑用户
    "USER_DELETE_ACTION": "163",//删除用户
    "ASSET_LIST_MENU": "5",//资产列表
    "ASSET_QUERY": "6",//查询资产
    "ASSET_CREATE_ACTION": "7",//添加资产
    "ASSET_EDIT_ACTION": "8",//编辑资产
    "ASSET_CONNECT_ACTION": "9",//连接资产
    "ASSET_DELETE_ACTION": "10",//删除资产
    "ASSET_UPDATE_ACTION": "12",//更新资产
    "ASSET_POWER_ACTION": "13",//开机
    "ASSET_REBOOT_ACTION": "14",//重启
    "ASSET_SHUTDOWN_ACTION": "15",//关机
    "ASSET_REBUILD_ACTION": "16",//重装系统
    "ASSET_ENABLE_OR_DISABLE_ACTION": "17",//启用禁用
    "ASSET_BATCH_EXEC_ACTION": "159",//批量执行
    "ASSET_CHANGE_PROJECT_ACTION": "188",//变更项目
    "ASSET_IDC_MENU": "18",//机房列表
    "ASSET_IDC_QUERY": "19",//查询机房
    "ASSET_IDC_CREATE_ACTION": "20",//添加机房
    "ASSET_IDC_EDIT_ACTION": "21",//编辑机房
    "ASSET_IDC_DELETE_ACTION": "22",//删除机房
    "ASSET_IDC_DETAIL_ACTION": "24",//查看详情
    "VM_LIST_MENU": "25",//虚拟机列表
    "VM_QUERY": "26",//查询虚拟机
    "VM_CREATE_ACTION": "27",//添加虚拟机
    "VM_EDIT_ACTION": "28",//编辑虚拟机
    "VM_DELETE_ACTION": "29",//删除虚拟机
    "VM_CONNECT_ACTION": "30",//连接虚拟机
    "VM_UPDATE_ACTION": "31",//更新虚拟机
    "APP_MANAGE_MENU": "32",//应用管理
    "APP_MODULE_MENU": "33",//模块剧本
    "APP_MODULE_UPLOAD_ACTION": "34",//剧本上传
    "APP_MODULE_LIST_QUERY": "35",//剧本查看
    "APP_MODULE_DEPLOY_CREATE_ACTION": "36",//部署创建
    "APP_MODULE_DEPLOY_LIST_QUERY": "37",//部署查询
    "APP_MODULE_DEPLOY_REPLAY_ACTION": "38",//部署回放
    "APP_CONTAINER_MENU": "39",//容器部署
    "TASK_MANAGE_MENU": "40",//任务管理
    "TASK_COMMON_MENU": "41",//常规任务
    "TASK_COMMON_QUERY": "42",//查询常规任务
    "TASK_COMMON_CREATE_ACTION": "43",//添加常规任务
    "TASK_COMMON_CREATE_IMM": "52",//添加常规任务(无需审批)
    "TASK_COMMON_CREATE_APPROVE": "53",//添加常规任务(审批)
    "TASK_COMMON_DETAIL_ACTION": "44",//查看任务明细
    "TASK_COMMON_EDIT_ACTION": "46",//编辑常规任务
    "TASK_COMMON_EDIT_IMM": "54",//编辑常规任务(无需审批)
    "TASK_COMMON_EDIT_APPROVE": "55",//编辑常规任务(审批)
    "TASK_COMMON_DELETE_ACTION": "47",//删除常规任务
    "TASK_COMMON_DELETE_IMM": "164",//删除常规任务(无需审批)
    "TASK_COMMON_DELETE_APPROVE": "165",//删除常规任务(审批)
    "TASK_COMMON_PAUSE_ACTION": "48",//禁用常规任务
    "TASK_COMMON_PAUSE_IMM": "166",//禁用常规任务(无需审批)
    "TASK_COMMON_PAUSE_APPROVE": "167",//禁用常规任务(审批)
    "TASK_COMMON_RESUME_ACTION": "49",//启用常规任务
    "TASK_COMMON_RESUME_IMM": "168",//启用常规任务(无需审批)
    "TASK_COMMON_RESUME_APPROVE": "169",//启用常规任务(审批)
    "TASK_COMMON_EXEC_INFO_QUERY": "50",//查看常规任务执行结果
    "TASK_COMMON_REPLAY_QUERY": "51",//常规任务回放
    "TASK_ADVANCED_MENU": "56",//高级任务
    "TASK_ADVANCED_QUERY": "57",//查询高级任务
    "TASK_ADVANCED_CREATE_ACTION": "58",//添加高级任务
    "TASK_ADVANCED_CREATE_IMM": "68",//添加高级任务(无需审批)
    "TASK_ADVANCED_CREATE_APPROVE": "69",//添加高级任务(审批)
    "TASK_ADVANCED_DETAIL_ACTION": "59",//查看高级任务明细
    "TASK_ADVANCED_EDIT_ACTION": "61",//编辑高级任务
    "TASK_ADVANCED_EDIT_IMM": "70",//编辑高级任务(无需审批)
    "TASK_ADVANCED_EDIT_APPROVE": "71",//编辑高级任务(审批)
    "TASK_ADVANCED_DELETE_ACTION": "62",//删除高级任务
    "TASK_ADVANCED_DELETE_IMM": "170",//删除高级任务(无需审批)
    "TASK_ADVANCED_DELETE_APPROVE": "171",//删除高级任务(审批)
    "TASK_ADVANCED_PAUSE_ACTION": "64",//禁用高级任务
    "TASK_ADVANCED_PAUSE_IMM": "172",//禁用高级任务(无需审批)
    "TASK_ADVANCED_PAUSE_APPROVE": "173",//禁用高级任务(审批)
    "TASK_ADVANCED_RESUME_ACTION": "65",//启用高级任务
    "TASK_ADVANCED_RESUME_IMM": "174",//启用高级任务(无需审批)
    "TASK_ADVANCED_RESUME_APPROVE": "175",//启用高级任务(审批)
    "TASK_ADVANCED_EXEC_INFO_QUERY": "66",//查看高级任务执行结果
    "TASK_ADVANCED_REPLAY_QUERY": "67",//高级任务回放
    "BACKUP_FILE_MENU": "72",//路径/文件备份
    "BACKUP_FILE_QUERY": "73",//查询文件备份
    "BACKUP_FILE_CREATE_ACTION": "74",//添加文件备份
    "BACKUP_FILE_CREATE_IMM": "176",//添加文件备份(无需审批)
    "BACKUP_FILE_CREATE_APPROVE": "177",//添加文件备份(审批)
    "BACKUP_FILE_DETAIL_ACTION": "75",//查看明细
    "BACKUP_FILE_EDIT_ACTION": "76",//编辑文件备份
    "BACKUP_FILE_EDIT_IMM": "178",//编辑文件备份(无需审批)
    "BACKUP_FILE_EDIT_APPROVE": "179",//编辑文件备份(审批)
    "BACKUP_FILE_DELETE_ACTION": "77",//删除文件备份
    "BACKUP_FILE_DELETE_IMM": "180",//删除文件备份(无需审批)
    "BACKUP_FILE_DELETE_APPROVE": "181",//删除文件备份(审批)
    "BACKUP_FILE_EXEC_INFO_QUERY": "79",//文件备份执行记录查询
    "BACKUP_FILE_REPLAY_QUERY": "80",//文件备份回放
    "BACKUP_FILE_DOWNLOAD_ACTION": "81",//文件备份下载
    "BACKUP_DATABASE_MENU": "82",//MySQL备份
    "BACKUP_DATABASE_QUERY": "83",//查询数据库备份
    "BACKUP_DATABASE_CREATE_ACTION": "84",//添加数据库备份
    "BACKUP_DATABASE_CREATE_IMM": "182",//添加数据库备份(无需审批)
    "BACKUP_DATABASE_CREATE_APPROVE": "183",//添加数据库备份(审批)
    "BACKUP_DATABASE_DETAIL_ACTION": "85",//查看明细
    "BACKUP_DATABASE_EDIT_ACTION": "86",//编辑数据库备份
    "BACKUP_DATABASE_EDIT_IMM": "184",//编辑数据库备份(无需审批)
    "BACKUP_DATABASE_EDIT_APPROVE": "185",//编辑数据库备份(审批)
    "BACKUP_DATABASE_DELETE_ACTION": "87",//删除数据库备份
    "BACKUP_DATABASE_DELETE_IMM": "186",//删除数据库备份(无需审批)
    "BACKUP_DATABASE_DELETE_APPROVE": "187",//删除数据库备份(审批)
    "BACKUP_DATABASE_EXEC_INFO_QUERY": "89",//数据库备份执行记录查询
    "BACKUP_DATABASE_REPLAY_QUERY": "90",//数据库备份回放
    "BACKUP_DATABASE_DOWNLOAD_ACTION": "91",//数据库备份下载
    "AUTH_MANAGE_MENU": "92",//授权管理
    "AUTH_SUDO_MENU": "93",//sudo sudo别名
    "AUTH_SUDO_QUERY": "94",//查询SUDO
    "AUTH_SUDO_CREATE_ACTION": "95",//添加SUDO
    "AUTH_SUDO_EDIT_ACTION": "96",//编辑SUDO
    "AUTH_SUDO_DELETE_ACTION": "97",//删除SUDO
    "AUTH_ROLE_MENU": "98",//系统用户
    "AUTH_ROLE_QUERY": "99",//查询系统用户
    "AUTH_ROLE_CREATE_ACTION": "100",//添加系统用户
    "AUTH_ROLE_EDIT_ACTION": "101",//编辑系统用户
    "AUTH_ROLE_PUSH_ACTION": "102",//推送系统用户
    "AUTH_ROLE_DOWNLOAD_KEY_ACTION": "103",//下载秘钥
    "AUTH_ROLE_DELETE_ACTION": "104",//删除系统用户
    "AUTH_RULE_MENU": "105",//授权规则
    "AUTH_RULE_QUERY": "106",//查询授权规则
    "AUTH_RULE_CREATE_ACTION": "107",//添加授权规则
    "AUTH_RULE_EDIT_ACTION": "108",//编辑授权规则
    "AUTH_RULE_DELETE_ACTION": "109",//删除授权规则
    "PROXY_MANAGE_MENU": "110",//代理管理
    "PROXY_LIST_MENU": "111",//查看代理
    "PROXY_QUERY": "112",//查询代理
    "PROXY_CREATE_ACTION": "113",//添加代理
    "PROXY_EDIT_ACTION": "114",//编辑代理
    "PROXY_EXEC_COMMAND_ACTION": "115",//执行命令
    "PROXY_DELETE_ACTION": "116",//删除代理
    "LOG_MANAGE_MENU": "118",//日志管理
    "LOG_LIST_MENU": "119",//日志审计
    "LOG_ASSET_ONLINE_QUERY": "120",//查询在线记录
    "LOG_ASSET_LOGIN_QUERY": "121",//查询登录历史记录
    "LOG_ALARM_QUERY": "122",//查询告警事件
    "LOG_OPERATOR_QUERY": "123",//查询操作记录
    "LOG_COMMAND_HISTORY_QUERY": "124",//命令执行历史
    "LOG_CONNECT_KILL_ACTION": "125",//阻断命令行 在线记录-阻断命令行
    "LOG_CONNECT_RECORD_ACTION": "126",//操作回放 历史登录-操作回放
    "WORKFLOW_MENU": "155",//我的工作
    "WORKFLOW_MY_CREATE_MENU": "156",//我起草的
    "WORKFLOW_WILL_DO_MENU": "157",//待处理的
    "WORKFLOW_COMPLETE_MENU": "158",//已完成的
    "ALARM_MANAGE_MENU": "127",//告警管理
    "ALARM_TYPE_MENU": "128",//告警媒介类型
    "ALARM_TYPE_QUERY": "129",//查询告警媒介类型
    "ALARM_TYPE_CREATE_ACTION": "130",//添加告警媒介类型
    "ALARM_TYPE_EDIT_ACTION": "131",//编辑告警媒介类型
    "ALARM_TYPE_DELETE_ACTION": "132",//删除告警媒介类型
    "ALARM_SETTING_MENU": "134",//告警设置
    "ALARM_SETTING_QUERY": "135",//查询告警设置
    "ALARM_SETTING_EDIT_ACTION": "136",//编辑告警设置
    "UPLOAD_DOWNLOAD_MANAGE_MENU": "139",//上传下载
    "FILE_UPLOAD_MENU": "140",//文件上传
    "FILE_UPLOAD_QUERY": "141",//查询上传文件
    "FILE_UPLOAD_ACTION": "142",//上传文件
    "FILE_DOWNLOAD_MENU": "143",//文件下载
    "FILE_DOWNLOAD_QUERY": "144",//查询下载文件
    "FILE_DOWNLOAD_ACTION": "145",//下载文件
    "PLUGIN_MANAGE_MENU": "146",//插件管理
    "PLUGIN_LIST_MENU": "147",//插件列表
    "PLUGIN_QUERY_ACTION": "148",//查询插件
    "PLUGIN_CREATE_ACTION": "149",//添加插件
    "PLUGIN_EDIT_ACTION": "150",//编辑插件
    "PLUGIN_DELETE_ACTION": "151",//删除插件
    "PLUGIN_CONNECT_ACTION": "152",//插件登录
    "GLOBAL_SETTINGS_MENU": "153",//全局设置
    "GLOBAL_SETTINGS_AUTH_MENU": "154",//认证

};
var ms_permission_vk = {
    "2": "PROJECT_MANAGE_MENU",//项目管理
    "3": "PROJECT_LIST_MENU",//项目列表
    "4": "USER_LIST_MENU",//用户列表
    "160": "USER_QUERY",//查询用户
    "161": "USER_CREATE_ACTION",//创建用户
    "162": "USER_EDIT_ACTION",//编辑用户
    "163": "USER_DELETE_ACTION",//删除用户
    "5": "ASSET_LIST_MENU",//资产列表
    "6": "ASSET_QUERY",//查询资产
    "7": "ASSET_CREATE_ACTION",//添加资产
    "8": "ASSET_EDIT_ACTION",//编辑资产
    "9": "ASSET_CONNECT_ACTION",//连接资产
    "10": "ASSET_DELETE_ACTION",//删除资产
    "12": "ASSET_UPDATE_ACTION",//更新资产
    "13": "ASSET_POWER_ACTION",//开机
    "14": "ASSET_REBOOT_ACTION",//重启
    "15": "ASSET_SHUTDOWN_ACTION",//关机
    "16": "ASSET_REBUILD_ACTION",//重装系统
    "17": "ASSET_ENABLE_OR_DISABLE_ACTION",//启用禁用
    "159": "ASSET_BATCH_EXEC_ACTION",//批量执行
    "188": "ASSET_CHANGE_PROJECT_ACTION",//变更项目
    "18": "ASSET_IDC_MENU",//机房列表
    "19": "ASSET_IDC_QUERY",//查询机房
    "20": "ASSET_IDC_CREATE_ACTION",//添加机房
    "21": "ASSET_IDC_EDIT_ACTION",//编辑机房
    "22": "ASSET_IDC_DELETE_ACTION",//删除机房
    "24": "ASSET_IDC_DETAIL_ACTION",//查看详情
    "25": "VM_LIST_MENU",//虚拟机列表
    "26": "VM_QUERY",//查询虚拟机
    "27": "VM_CREATE_ACTION",//添加虚拟机
    "28": "VM_EDIT_ACTION",//编辑虚拟机
    "29": "VM_DELETE_ACTION",//删除虚拟机
    "30": "VM_CONNECT_ACTION",//连接虚拟机
    "31": "VM_UPDATE_ACTION",//更新虚拟机
    "32": "APP_MANAGE_MENU",//应用管理
    "33": "APP_MODULE_MENU",//模块剧本
    "34": "APP_MODULE_UPLOAD_ACTION",//剧本上传
    "35": "APP_MODULE_LIST_QUERY",//剧本查看
    "36": "APP_MODULE_DEPLOY_CREATE_ACTION",//部署创建
    "37": "APP_MODULE_DEPLOY_LIST_QUERY",//部署查询
    "38": "APP_MODULE_DEPLOY_REPLAY_ACTION",//部署回放
    "39": "APP_CONTAINER_MENU",//容器部署
    "40": "TASK_MANAGE_MENU",//任务管理
    "41": "TASK_COMMON_MENU",//常规任务
    "42": "TASK_COMMON_QUERY",//查询常规任务
    "43": "TASK_COMMON_CREATE_ACTION",//添加常规任务
    "52": "TASK_COMMON_CREATE_IMM",//添加常规任务(无需审批)
    "53": "TASK_COMMON_CREATE_APPROVE",//添加常规任务(审批)
    "44": "TASK_COMMON_DETAIL_ACTION",//查看任务明细
    "46": "TASK_COMMON_EDIT_ACTION",//编辑常规任务
    "54": "TASK_COMMON_EDIT_IMM",//编辑常规任务(无需审批)
    "55": "TASK_COMMON_EDIT_APPROVE",//编辑常规任务(审批)
    "47": "TASK_COMMON_DELETE_ACTION",//删除常规任务
    "164": "TASK_COMMON_DELETE_IMM",//删除常规任务(无需审批)
    "165": "TASK_COMMON_DELETE_APPROVE",//删除常规任务(审批)
    "48": "TASK_COMMON_PAUSE_ACTION",//禁用常规任务
    "166": "TASK_COMMON_PAUSE_IMM",//禁用常规任务(无需审批)
    "167": "TASK_COMMON_PAUSE_APPROVE",//禁用常规任务(审批)
    "49": "TASK_COMMON_RESUME_ACTION",//启用常规任务
    "168": "TASK_COMMON_RESUME_IMM",//启用常规任务(无需审批)
    "169": "TASK_COMMON_RESUME_APPROVE",//启用常规任务(审批)
    "50": "TASK_COMMON_EXEC_INFO_QUERY",//查看常规任务执行结果
    "51": "TASK_COMMON_REPLAY_QUERY",//常规任务回放
    "56": "TASK_ADVANCED_MENU",//高级任务
    "57": "TASK_ADVANCED_QUERY",//查询高级任务
    "58": "TASK_ADVANCED_CREATE_ACTION",//添加高级任务
    "68": "TASK_ADVANCED_CREATE_IMM",//添加高级任务(无需审批)
    "69": "TASK_ADVANCED_CREATE_APPROVE",//添加高级任务(审批)
    "59": "TASK_ADVANCED_DETAIL_ACTION",//查看高级任务明细
    "61": "TASK_ADVANCED_EDIT_ACTION",//编辑高级任务
    "70": "TASK_ADVANCED_EDIT_IMM",//编辑高级任务(无需审批)
    "71": "TASK_ADVANCED_EDIT_APPROVE",//编辑高级任务(审批)
    "62": "TASK_ADVANCED_DELETE_ACTION",//删除高级任务
    "170": "TASK_ADVANCED_DELETE_IMM",//删除高级任务(无需审批)
    "171": "TASK_ADVANCED_DELETE_APPROVE",//删除高级任务(审批)
    "64": "TASK_ADVANCED_PAUSE_ACTION",//禁用高级任务
    "172": "TASK_ADVANCED_PAUSE_IMM",//禁用高级任务(无需审批)
    "173": "TASK_ADVANCED_PAUSE_APPROVE",//禁用高级任务(审批)
    "65": "TASK_ADVANCED_RESUME_ACTION",//启用高级任务
    "174": "TASK_ADVANCED_RESUME_IMM",//启用高级任务(无需审批)
    "175": "TASK_ADVANCED_RESUME_APPROVE",//启用高级任务(审批)
    "66": "TASK_ADVANCED_EXEC_INFO_QUERY",//查看高级任务执行结果
    "67": "TASK_ADVANCED_REPLAY_QUERY",//高级任务回放
    "72": "BACKUP_FILE_MENU",//路径/文件备份
    "73": "BACKUP_FILE_QUERY",//查询文件备份
    "74": "BACKUP_FILE_CREATE_ACTION",//添加文件备份
    "176": "BACKUP_FILE_CREATE_IMM",//添加文件备份(无需审批)
    "177": "BACKUP_FILE_CREATE_APPROVE",//添加文件备份(审批)
    "75": "BACKUP_FILE_DETAIL_ACTION",//查看明细
    "76": "BACKUP_FILE_EDIT_ACTION",//编辑文件备份
    "178": "BACKUP_FILE_EDIT_IMM",//编辑文件备份(无需审批)
    "179": "BACKUP_FILE_EDIT_APPROVE",//编辑文件备份(审批)
    "77": "BACKUP_FILE_DELETE_ACTION",//删除文件备份
    "180": "BACKUP_FILE_DELETE_IMM",//删除文件备份(无需审批)
    "181": "BACKUP_FILE_DELETE_APPROVE",//删除文件备份(审批)
    "79": "BACKUP_FILE_EXEC_INFO_QUERY",//文件备份执行记录查询
    "80": "BACKUP_FILE_REPLAY_QUERY",//文件备份回放
    "81": "BACKUP_FILE_DOWNLOAD_ACTION",//文件备份下载
    "82": "BACKUP_DATABASE_MENU",//MySQL备份
    "83": "BACKUP_DATABASE_QUERY",//查询数据库备份
    "84": "BACKUP_DATABASE_CREATE_ACTION",//添加数据库备份
    "182": "BACKUP_DATABASE_CREATE_IMM",//添加数据库备份(无需审批)
    "183": "BACKUP_DATABASE_CREATE_APPROVE",//添加数据库备份(审批)
    "85": "BACKUP_DATABASE_DETAIL_ACTION",//查看明细
    "86": "BACKUP_DATABASE_EDIT_ACTION",//编辑数据库备份
    "184": "BACKUP_DATABASE_EDIT_IMM",//编辑数据库备份(无需审批)
    "185": "BACKUP_DATABASE_EDIT_APPROVE",//编辑数据库备份(审批)
    "87": "BACKUP_DATABASE_DELETE_ACTION",//删除数据库备份
    "186": "BACKUP_DATABASE_DELETE_IMM",//删除数据库备份(无需审批)
    "187": "BACKUP_DATABASE_DELETE_APPROVE",//删除数据库备份(审批)
    "89": "BACKUP_DATABASE_EXEC_INFO_QUERY",//数据库备份执行记录查询
    "90": "BACKUP_DATABASE_REPLAY_QUERY",//数据库备份回放
    "91": "BACKUP_DATABASE_DOWNLOAD_ACTION",//数据库备份下载
    "92": "AUTH_MANAGE_MENU",//授权管理
    "93": "AUTH_SUDO_MENU",//sudo sudo别名
    "94": "AUTH_SUDO_QUERY",//查询SUDO
    "95": "AUTH_SUDO_CREATE_ACTION",//添加SUDO
    "96": "AUTH_SUDO_EDIT_ACTION",//编辑SUDO
    "97": "AUTH_SUDO_DELETE_ACTION",//删除SUDO
    "98": "AUTH_ROLE_MENU",//系统用户
    "99": "AUTH_ROLE_QUERY",//查询系统用户
    "100": "AUTH_ROLE_CREATE_ACTION",//添加系统用户
    "101": "AUTH_ROLE_EDIT_ACTION",//编辑系统用户
    "102": "AUTH_ROLE_PUSH_ACTION",//推送系统用户
    "103": "AUTH_ROLE_DOWNLOAD_KEY_ACTION",//下载秘钥
    "104": "AUTH_ROLE_DELETE_ACTION",//删除系统用户
    "105": "AUTH_RULE_MENU",//授权规则
    "106": "AUTH_RULE_QUERY",//查询授权规则
    "107": "AUTH_RULE_CREATE_ACTION",//添加授权规则
    "108": "AUTH_RULE_EDIT_ACTION",//编辑授权规则
    "109": "AUTH_RULE_DELETE_ACTION",//删除授权规则
    "110": "PROXY_MANAGE_MENU",//代理管理
    "111": "PROXY_LIST_MENU",//查看代理
    "112": "PROXY_QUERY",//查询代理
    "113": "PROXY_CREATE_ACTION",//添加代理
    "114": "PROXY_EDIT_ACTION",//编辑代理
    "115": "PROXY_EXEC_COMMAND_ACTION",//执行命令
    "116": "PROXY_DELETE_ACTION",//删除代理
    "118": "LOG_MANAGE_MENU",//日志管理
    "119": "LOG_LIST_MENU",//日志审计
    "120": "LOG_ASSET_ONLINE_QUERY",//查询在线记录
    "121": "LOG_ASSET_LOGIN_QUERY",//查询登录历史记录
    "122": "LOG_ALARM_QUERY",//查询告警事件
    "123": "LOG_OPERATOR_QUERY",//查询操作记录
    "124": "LOG_COMMAND_HISTORY_QUERY",//命令执行历史
    "125": "LOG_CONNECT_KILL_ACTION",//阻断命令行 在线记录-阻断命令行
    "126": "LOG_CONNECT_RECORD_ACTION",//操作回放 历史登录-操作回放
    "155": "WORKFLOW_MENU",//我的工作
    "156": "WORKFLOW_MY_CREATE_MENU",//我起草的
    "157": "WORKFLOW_WILL_DO_MENU",//待处理的
    "158": "WORKFLOW_COMPLETE_MENU",//已完成的
    "127": "ALARM_MANAGE_MENU",//告警管理
    "128": "ALARM_TYPE_MENU",//告警媒介类型
    "129": "ALARM_TYPE_QUERY",//查询告警媒介类型
    "130": "ALARM_TYPE_CREATE_ACTION",//添加告警媒介类型
    "131": "ALARM_TYPE_EDIT_ACTION",//编辑告警媒介类型
    "132": "ALARM_TYPE_DELETE_ACTION",//删除告警媒介类型
    "134": "ALARM_SETTING_MENU",//告警设置
    "135": "ALARM_SETTING_QUERY",//查询告警设置
    "136": "ALARM_SETTING_EDIT_ACTION",//编辑告警设置
    "139": "UPLOAD_DOWNLOAD_MANAGE_MENU",//上传下载
    "140": "FILE_UPLOAD_MENU",//文件上传
    "141": "FILE_UPLOAD_QUERY",//查询上传文件
    "142": "FILE_UPLOAD_ACTION",//上传文件
    "143": "FILE_DOWNLOAD_MENU",//文件下载
    "144": "FILE_DOWNLOAD_QUERY",//查询下载文件
    "145": "FILE_DOWNLOAD_ACTION",//下载文件
    "146": "PLUGIN_MANAGE_MENU",//插件管理
    "147": "PLUGIN_LIST_MENU",//插件列表
    "148": "PLUGIN_QUERY_ACTION",//查询插件
    "149": "PLUGIN_CREATE_ACTION",//添加插件
    "150": "PLUGIN_EDIT_ACTION",//编辑插件
    "151": "PLUGIN_DELETE_ACTION",//删除插件
    "152": "PLUGIN_CONNECT_ACTION",//插件登录
    "153": "GLOBAL_SETTINGS_MENU",//全局设置
    "154": "GLOBAL_SETTINGS_AUTH_MENU",//认证
};
