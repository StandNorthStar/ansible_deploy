// config

var app =
    angular.module('app')
        .config(['$controllerProvider', '$compileProvider', '$filterProvider', '$provide', '$httpProvider',
            function ($controllerProvider, $compileProvider, $filterProvider, $provide, $httpProvider) {
                // lazy controller, directive and service
                app.controller = $controllerProvider.register;
                app.directive = $compileProvider.directive;
                app.filter = $filterProvider.register;
                app.factory = $provide.factory;
                app.service = $provide.service;
                app.constant = $provide.constant;
                app.value = $provide.value;
                //配置$http 请求header
                $httpProvider.defaults.headers.common['Content-Type'] = 'application/json';
                $httpProvider.defaults.headers.post['Content-Type'] = 'application/json';
                $httpProvider.defaults.headers.put['Content-Type'] = 'application/json';

                /**
                 * 拦截器
                 */
                $httpProvider.interceptors.push(["$q", "$injector", function ($q, $injector) {
                    return {
                        request: function (request) {
                            var key = $.ms.getQueryString("key");
                            if (key && request) {
                                request.headers['X-Auth-Token'] = key;
                            }
                            return request;
                        },
                        // 可选，拦截失败的响应
                        responseError: function (rejection) {
                            var $rootScope = $injector.get("$rootScope");
                            var $state = $injector.get("$state");
                            var $modalStack = $injector.get("$modalStack");
                            var toaster = $injector.get("toaster");
                            var msLocalStorage = $injector.get("msLocalStorage");
                            // 对失败的响应进行处理
                            var status = rejection.status;
                            var message = rejection.data && rejection.data.message;
                            if (!message) {
                                if (status === 500) {
                                    message = "HTTP 500:Internal Server Error";
                                }
                            }
                            if (status == 403 && (rejection.data.error_code == 1 || rejection.data.error_code == 2)) {
                                msLocalStorage.remove("userId");
                                msLocalStorage.remove("isSuperuser");
                                msLocalStorage.remove("username");
                                msLocalStorage.remove("projectId");
                                msLocalStorage.remove("projectName");
                                msLocalStorage.remove("myProjectList");
                                // msLocalStorage.remove("permissionsObj");
                                if (message && rejection.data.error_code == 2) {
                                    toaster.pop('error', rejection.config.err_title, message, $rootScope.errorDwellTime);
                                }
                                //系统踢下线时关闭没有关闭的模态框
                                $modalStack.dismissAll();


                                window.location.href = "/"
                            }
                            else if (status == 403 && rejection.data.error_code == 3) {
                                //未授权跳转
                                if (message && !rejection.config.no_error) {
                                    toaster.pop('error', rejection.config.err_title, message, $rootScope.errorDwellTime);
                                }
                                msLocalStorage.remove("userId");
                                msLocalStorage.remove("isSuperuser");
                                msLocalStorage.remove("username");
                                msLocalStorage.remove("projectId");
                                msLocalStorage.remove("projectName");
                                msLocalStorage.remove("myProjectList");
                                //跳转授权License
                                $state.go('auth.license');
                            }
                            else {
                                if (message && !rejection.config.no_error) {
                                    toaster.pop('error', rejection.config.err_title, message, $rootScope.errorDwellTime);
                                }

                            }
                            return $q.reject(rejection);
                        }
                    };
                }]);
            }
        ]);

/**
 * 保存到localstorage
 */
app.factory('msLocalStorage', function () {
    return {
        set: function (key, value) {
            window.localStorage[key] = value;
        },
        get: function (key) {
            return window.localStorage[key];
        },
        remove: function (key) {
            window.localStorage.removeItem(key);
        }
    }
});

/**
 * 登录、授权
 */
app.factory('msLoginSsoAuth', ['$rootScope', '$http', '$state', 'toaster', 'msLocalStorage',
    function ($rootScope, $http, $state, toaster, msLocalStorage) {
        return function (url, method, parameter, errorInfo) {
            $http({
                method: method,
                url: url,
                err_title: errorInfo,
                data: parameter
            }).then(function successCallback(response) {
                if (response.status >= 200 && response.status <= 299) {
                    msLocalStorage.set("userId", response.data.id);
                    msLocalStorage.set("isSuperuser", response.data.is_superuser);
                    msLocalStorage.set("username", response.data.username);
                    $rootScope.username = msLocalStorage.get("username");
                    if (!$.ms.isEmptyObject(response.data.project)) {
                        msLocalStorage.set("projectId", response.data.project.id);
                        msLocalStorage.set("projectName", response.data.project.name);
                        $rootScope.projectId = msLocalStorage.get("projectId");
                        $rootScope.projectName = msLocalStorage.get("projectName");
                        $http({
                            method: 'GET',
                            url: '/v1/permissions/my-project/?offset=0&limit=10',
                            data: ''
                        }).then(function successCallback(response) {
                            if (response.status >= 200 && response.status <= 299 && !$.ms.isEmptyObject(response.data.results)) {
                                msLocalStorage.set("myProjectList", JSON.stringify(response.data.results));
                            }
                        });
                    }
                    $state.go('app.ui.overview');
                }
            });
        }
    }]);

/***
 * 模态框控制器
 */
app.controller('ModalInstanceCtrl', ['$scope', '$modalInstance', 'items', function ($scope, $modalInstance, items) {
    $scope.items = items;

    $scope.ok = function () {
        $modalInstance.close($scope.items);
    };

    $scope.clear = function () {
        $scope.items = {};
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
}]);