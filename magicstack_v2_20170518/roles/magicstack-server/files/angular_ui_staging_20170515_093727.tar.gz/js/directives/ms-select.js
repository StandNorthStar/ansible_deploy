app.component("msSelect", {
    templateUrl: 'tpl/ms_select.html',
    bindings: {
        ngModel: "=",
        datas: "=",
        placeholder: "@",
        type: "@",
        required: "@"

    },
    require: {
        ngModelCtrl: 'ngModel'
    },
    controller: ["$q", "$location", "$timeout", '$scope', 'msItemSelect', function ($q, $location, $timeout, $scope, msItemSelect) {
        this.$onInit = function () {
            if (typeof (this.required) === "string") {
                this.ngModelCtrl.$validators.ms_required = function (modelValue, viewValue) {
                    if (!viewValue) {
                        return false;
                    }
                    else if (angular.isArray(viewValue) && viewValue.length == 0) {
                        return false;
                    }
                    else {
                        return true;
                    }
                }

            }

        };

        this.typeConfig = {
            asset: {
                displayName: "name",
                displayNameSmall: "ip",
                key: "id",
                tableFields: [
                    {
                        key: "name",
                        title: "资产名称",
                        sort_key: "name"
                    },
                    {
                        key: "ip",
                        title: "IP",
                        sort_key: "ip"
                    }
                ]
            },
            proxy: {
                displayName: "proxy_name",
                displayNameSmall: "proxy_name",
                key: "id",
                tableFields: [
                    {
                        key: "proxy_name",
                        title: "名称",
                        sort_key: "proxy_name"
                    },
                    {
                        key: "comment",
                        title: "备注",
                        sort_key: "comment"
                    }
                ]
            },
            sudo: {
                displayName: "name",
                displayNameSmall: "commands",
                key: "id",
                tableFields: [
                    {
                        key: "name",
                        title: "名称",
                        sort_key: "name"
                    },
                    {
                        key: "commands",
                        title: "命令",
                        sort_key: "commands"
                    }
                ]
            },
            system_user: {
                displayName: "name",
                displayNameSmall: "name",
                key: "id",
                tableFields: [
                    {
                        key: "name",
                        title: "系统用户",
                        sort_key: "name"
                    },
                    {
                        key: "comment",
                        title: "备注",
                        sort_key: "comment"
                    }
                ]
            },
            user: {
                displayName: "username",
                displayNameSmall: "email",
                key: "id",
                tableFields: [
                    {
                        key: "username",
                        title: "用户名",
                        sort_key: "username"
                    },
                    {
                        key: "email",
                        title: "Email",
                        sort_key: "email"
                    }
                ]
            },
            role: {
                displayName: "name",
                displayNameSmall: "name",
                key: "id",
                tableFields: [
                    {
                        key: "name",
                        title: "角色",
                        sort_key: "name"
                    }
                ]
            },
            media_type: {
                displayName: "name",
                displayNameSmall: "name",
                key: "id",
                tableFields: [
                    {
                        key: "name",
                        title: "媒介类型",
                        sort_key: "name"
                    }
                ]
            },
        };
        this.displayName = this.typeConfig[this.type].displayName;
        this.displayNameSmall = this.typeConfig[this.type].displayNameSmall;
        this.key = this.typeConfig[this.type].key;
        this.tableFields = this.typeConfig[this.type].tableFields;
        this.placeholder_txt = this.placeholder || "请选择";
        this.mulSetData = function () {
            var self = this;
            msItemSelect({
                title: this.placeholder,
                datas: this.datas,
                model: this.ngModel,
                key: this.key,
                fields: this.tableFields,
                tableFilterKeys: this.tableFilterKeys
            }).then(function (selected_items) {
                $timeout(function () {
                    self.ngModel = selected_items;
                }, 300);

            })
        }
    }]
});
