angular.module('app')
    .component("msTables", {
        templateUrl: 'tpl/tables.html',
        bindings: {
            options: '=',
            id: "@"

        },
        controller: ["$q", "$location", "$timeout", '$scope', function ($q, $location, $timeout, $scope) {
            var self = this;
            self.page_offset = 0;
            self.p_index = 1;
            self.check_items = {};
            self.search_keyword = "";
            self.page_index = 1;
            self.last_page_index = 0;
            self.reload_timer = null;
            self.pageSizeList = [
                10, 30, 50, 100, 150
            ];
            $scope.$watch("$ctrl.options.page_size", function (oldvalue, newvalue) {
                setTimeout(function () {
                    self.loadData()
                }, 100)
            });
            function getInstanceId() {
                var id = self.id || "";
                return $location.path() + id;
            }

            function cancelReloadTimer() {
                if (self.reload_timer) {
                    $timeout.cancel(self.reload_timer);
                    self.reload_timer = null;
                }
            }

            function getLastPageIndex() {
                var last = window.localStorage.ms_tables_last_page;
                if (last) {
                    last = JSON.parse(last);
                    if (last && last.id == getInstanceId()) {
                        return last.index;
                    } else {
                        window.localStorage.ms_tables_last_page = null;
                        return 1;
                    }
                } else {
                    return 1;
                }


            }

            function setLastPageIndex(page_index) {
                var data = {
                    id: getInstanceId(),
                    index: page_index
                }
                window.localStorage.ms_tables_last_page = JSON.stringify(data);
            }

            function loadHideField() {
                var key = "ms_tables_hide_field_" + getInstanceId();
                var hide_fields = window.localStorage.getItem(key);
                if (hide_fields) {
                    hide_fields = JSON.parse(hide_fields);
                    if (hide_fields) {
                        self.options.fields.forEach(function (item) {
                            if (item.can_hide && hide_fields[item.title]) {
                                item.show = false;
                            }
                        });
                    }
                }

            }

            self.getDepKye = function (obj, key) {
                if (!key) {
                    return "";
                }
                var keys = key.split("__");
                keys.forEach(function (k) {
                    if (!obj) {
                        return "";
                    }
                    obj = obj[k];
                });
                return obj;
            };

            self.saveHideField = function () {
                var key = "ms_tables_hide_field_" + getInstanceId();
                var hide_fields = {};
                self.options.fields.forEach(function (item) {
                    if (item.can_hide && !item.show) {
                        hide_fields[item.title] = true;
                    }
                });
                window.localStorage.setItem(key, JSON.stringify(hide_fields));
            }

            self.top_checked_change = function () {
                var key = self.options.item_checks.key;
                self.options.data.results.forEach(function (item) {
                    var id = item[key];
                    self.check_items[id] = self.top_checked;
                });
                var chk_items = self.options.getCheckedItems();
                self.options.checkedChange(chk_items);
            }
            self.extShow = function (item) {
                item.__show_ext__ = !item.__show_ext__;
            }
            self.keyword_change = function () {
                self.page_index = 1;
                self.loadData();
            }
            self.checked_change = function () {
                var key = self.options.item_checks.key;
                var select_all;
                if (self.options.data.results && self.options.data.results.length > 0) {
                    select_all = true;
                    self.options.data.results.forEach(function (item) {
                        var id = item[key];
                        if (!self.check_items[id]) {
                            select_all = false;
                        }
                    });
                }
                else {
                    select_all = false;
                }

                self.top_checked = select_all;
                var chk_items = self.options.getCheckedItems();
                self.options.checkedChange(chk_items);
            }
            self.column_count = function () {
                var count = self.options.fields.length;
                if (self.options.item_checks && self.options.item_checks.enable) {
                    count += 1;
                }
                return count;
            }
            self.compile = function (html, $item) {
                $compile(html)($item);
                return html;
            }
            self.sort = function (field) {
                if (field.sort_key) {
                    if (self.sort_key == field.sort_key) {
                        self.is_sort_desc = !self.is_sort_desc;
                    } else {
                        self.sort_key = field.sort_key;
                        self.is_sort_desc = false;
                    }
                    self.page_index = 1;
                    self.loadData();
                }
            }

            self.loadData = function () {
                cancelReloadTimer();
                var sort_key = self.sort_key || "";
                if (sort_key && self.is_sort_desc) {
                    sort_key = sort_key.split(',');
                    for (var i in sort_key) {
                        sort_key[i] = "-" + sort_key[i];
                    }
                    sort_key = sort_key.join(",")
                }
                var page_index = self.page_index;
                var page_offset = self.options.page_size * (page_index - 1);
                var change_page = self.last_page_index != self.page_index;
                self.last_page_index = self.page_index;
                $q.when(self.options.loadData(page_offset, self.options.page_size, sort_key, self.search_keyword)).then(function (data) {
                    self.page_offset = page_offset;
                    self.top_checked = false;
                    self.options.data = data;
                    if (change_page && !data.no_change_select) {
                        self.check_items = {};
                        self.options.checkedChange([]);
                    }
                    else {
                        self.checked_change();
                    }
                    setLastPageIndex(page_index);
                    if (data.auto_reload) {
                        cancelReloadTimer();
                        self.reload_timer = $timeout(self.loadData, 3000);
                    }
                });
            }
            self.pageChanged = function () {
                self.loadData();
            }
            self.$onInit = function () {
                self.page_index = getLastPageIndex();
                self.options.$ctrl = self;
                self.options.ctrlInit(self);
                loadHideField();
                self.loadData();
            }
            self.$onDestroy = function () {


            };
        }]
    })
    .component("msExtBtn", {
        templateUrl: 'tpl/tables-ext-btn.html',
        bindings: {
            buttons: '=',
            item: '='
        },
        controller: ["$scope", "$q", "$location", "$timeout", function ($scope, $q, $location, $timeout) {
            var self = this;
            $scope.$item = self.item;
            self.checkBtnPerm = function () {
                var result = [];
                var buttons = self.buttons || [];
                for (var i = 0; i < buttons.length; i++) {
                    var button = buttons[i];
                    var display = true;
                    if (button.display) {
                        display = $scope.$eval(button.display);
                    }
                    if ($.ms.checkPermissions(button.perm) && display) {
                        result.push(button);
                    }
                }
                return result;
            };

            self.getFirstBtn = function () {
                var btns = self.checkBtnPerm();
                if (btns.length > 0) {
                    return btns[0];
                }
                else {
                    return null;
                }

            };
            var lastBtns = [];
            self.getLastBtns = function () {
                lastBtns.splice(0, lastBtns.length);
                var btns = self.checkBtnPerm();
                if (btns.length > 1) {
                    for (var i = 1; i < btns.length; i++) {
                        lastBtns.push(btns[i]);
                    }
                    return lastBtns;

                }
                else {
                    return null;
                }
            }

        }]
    })
    .component("msMoreBtn", {
        templateUrl: 'tpl/tables-more-btn.html',
        bindings: {
            buttons: '=',
            item: '='
        },
        controller: ["$scope", "$q", "$location", "$timeout", function ($scope, $q, $location, $timeout) {
            var self = this;
            $scope.$item = self.item;
            self.checkBtnPerm = function () {
                var result = [];
                var buttons = self.buttons || [];
                for (var i = 0; i < buttons.length; i++) {
                    var button = buttons[i];
                    var display = true;
                    if (button.display) {
                        display = $scope.$eval(button.display);
                    }
                    if (button.hide) {
                        display = false;
                    }
                    if ($.ms.checkPermissions(button.perm) && display) {
                        result.push(button);
                    }
                }
                return result;
            };
            $scope.$watch('$ctrl.buttons', function () {
                self.getBtns();
            }, true);
            var enableBtns = $scope.enableBtns = [];
            self.getBtns = function () {
                enableBtns.splice(0, enableBtns.length);
                var btns = self.checkBtnPerm();
                for (var i = 0; i < btns.length; i++) {
                    enableBtns.push(btns[i]);
                }
            }

        }]
    });

/******************************************************************************/
(function (window) {
    window.msTables = {};

    function genId() {
        var timestamp = (new Date()).valueOf();
        var rand = parseInt(Math.random() * 1000);
        var id = "id" + timestamp + rand;
        return id;
    }

    var Option = window.msTables.Option = function () {
        var self = this;

        self.search = {
            enable: true,
        };
        self.item_checks = {
            enable: true,
            key: "id",
        };
        self.extern_data = {
            enable: false
        };
        self.loadData = function (page_index, sort_key, search_keyword) {
        };
        self.ctrlInit = function ($ctrl) {
        }
        self.checkedChange = function (items) {
        };
        self.page_size = 10;
        self.show_pagination = false;
        self.$ctrl = null;
        self.show_pagination = true;
    };

    Option.prototype.withButtons = function (buttons) {
        var self = this;
        if (!angular.isArray(buttons)) {
            console.error("参数必须为数组");
        }
        buttons.forEach(function (item) {
            item.id = genId();

        });
        self.buttons = buttons;
        return self;
    }
    Option.prototype.enableSearch = function (enable) {
        var self = this;
        self.search = {
            enable: enable
        };
        return self;
    }
    Option.prototype.setLoadDataFunc = function (func) {
        var self = this;
        self.loadData = func;
        return self;
    }
    Option.prototype.setCtrlInitFunc = function (func) {
        var self = this;
        self.ctrlInit = func;
        return self;
    }
    Option.prototype.setCheckedChangeFunc = function (func) {
        var self = this;
        self.checkedChange = func;
        return self;
    }
    Option.prototype.withFields = function (fields) {
        var self = this;
        if (!angular.isArray(fields)) {
            console.error("参数必须为数组");
        }
        fields.forEach(function (item) {
            item.id = genId();
            if (item.show === undefined) {
                item.show = true;
            }
            if (item.can_hide === undefined) {
                item.can_hide = true;
            }
        });
        self.fields = fields;
        return self;
    }
    Option.prototype.enableItemChecks = function (enable, key) {
        var self = this;
        if (!key) {
            key = "id";
        }
        self.item_checks = {
            enable: enable,
            key: key
        };
        return self;
    };
    Option.prototype.setPageSize = function (page_size) {
        var self = this;
        self.page_size = page_size;
        return self;
    };

    Option.prototype.showPagination = function (show) {
        var self = this;
        self.show_pagination = show;
        return self;
    };

    Option.prototype.enableExternData = function (enable, func) {
        var self = this;
        if (enable && !func) {
            console.error("未指定回调函数", func);
            return self;
        }
        self.extern_data = {
            enable: enable,
            func: func
        };
        return self;
    }
    //check_items
    Option.prototype.getCheckedItems = function () {
        var self = this;
        if (!self.item_checks.enable || !self.$ctrl || !self.data || !self.data.results) {
            return [];
        }
        var result = [];
        var key = self.item_checks.key;
        self.data.results.forEach(function (item) {
            if (self.$ctrl.check_items[item[key]]) {
                result.push(item);
            }
        });
        return result;

    }
    Option.prototype.reload = function () {
        var self = this;
        if (self.$ctrl) {
            self.$ctrl.loadData();
        }
        return self;
    }
})(window);
