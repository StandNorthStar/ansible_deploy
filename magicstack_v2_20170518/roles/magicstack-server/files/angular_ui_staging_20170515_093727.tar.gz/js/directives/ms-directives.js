/**
 * Created by liyongbing on 2016/8/17.
 * 指令
 */
angular.module('app')
    .directive('msSigninCaptcha', function msCaptcha() {
        return {
            restrict: 'AC',
            link: function (scope, element) {
                var changeSrc = function () {
                    //通过附加随机验证码来强制更换图形验证码
                    element.attr('src', '/v1/permissions/image_code?key=login&' + Math.random());
                };

                //启动动的时候先更换一次，一遍显示出来
                changeSrc();
                element.on('click', function () {
                    changeSrc();
                });
            }
        };
    })
    .directive('msForgotCaptcha', function msCaptcha() {
        return {
            restrict: 'AC',
            link: function (scope, element) {
                var changeSrc = function () {
                    //通过附加随机验证码来强制更换图形验证码
                    element.attr('src', '/v1/permissions/image_code?key=forget_password&' + Math.random());
                };

                //启动动的时候先更换一次，一遍显示出来
                changeSrc();
                element.on('click', function () {
                    changeSrc();
                });
            }
        };
    })
    .directive('msDateTimePicker', function msDateTimePicker() {
        return {
            restrict: 'A',
            link: function (scope, element, attrs, ngModel) {
                var dateOption = {
                    language: 'zh-CN',
                    weekStart: 1,
                    todayHighlight: 1,
                    startView: 2,
                    forceParse: 0,
                    showMeridian: 1,
                    autoclose: true,
                    minView: 2
                };
                element.datetimepicker(dateOption);
            }
        };
    })
    .directive('msDateTimePickerSF', function msDateTimePicker() {
        return {
            restrict: 'A',
            link: function (scope, element, attrs, ngModel) {
                var dateOption = {
                    language: 'zh-CN',
                    autoclose: true,
                    format: 'hh:ii',
                    startView: 1,
                    minView: 0
                };
                element.datetimepicker(dateOption);
            }
        };
    })
    .directive('msDateTimePickerSFM', function msDateTimePicker() {
        return {
            restrict: 'A',
            link: function (scope, element, attrs, ngModel) {
                var dateOption = {
                    language: 'zh-CN',
                    autoclose: true,
                    format: 'yyyy-mm-dd hh:ii'
                };
                element.datetimepicker(dateOption);
            }
        };
    })
    .directive('msButton', function msButton() { //按钮动画
        return {
            restrict: 'A',
            replace: 'true',
            scope: {},
            priority: 0,
            link: function (scope, element, attrs, ngModel) {
                var canvas = {},
                    centerX = 0,
                    centerY = 0,
                    color = '',
                    context = {},
                    radius = 0,
                    ele, tpl = '<canvas></canvas>',
                    requestAnimFrame = function () {
                        return (
                            window.requestAnimationFrame ||
                            window.mozRequestAnimationFrame ||
                            window.oRequestAnimationFrame ||
                            window.msRequestAnimationFrame ||
                            function (callback) {
                                window.setTimeout(callback, 1000 / 60);
                            }
                        );
                    }(),

                    init = function () {
                        element.append(tpl);
                        canvas = element.children()[0];
                        canvas.style.width = '100%';
                        canvas.style.height = '100%';
                        canvas.width = canvas.offsetWidth;
                        canvas.height = canvas.offsetHeight;

                        element.bind('click', function () {
                            color = attrs.color;
                            ele = element.children()[0];
                            context = ele.getContext('2d');
                            radius = 0;
                            centerX = event.offsetX;
                            centerY = event.offsetY;
                            context.clearRect(0, 0, ele.width, ele.height);
                            draw();
                        });
                    },

                    draw = function () {
                        context.beginPath();
                        context.arc(centerX, centerY, radius, 0, 2 * Math.PI, false);
                        context.fillStyle = color;
                        context.fill();
                        radius += 2;
                        if (radius < ele.width) {
                            requestAnimFrame(draw);
                        }
                    };

                init();
            }
        };
    })
    .directive('msScrollBottom', function () {
        return {
            restrict: 'A',
            link: function ($scope, element, attrs, ngModel) {
                var event;
                var has_new = false;
                var is_running = false;
                if (attrs.msScrollBottom) {
                    event = attrs.msScrollBottom + "-scroll-bottom";
                } else {
                    event = "scroll-bottom";
                }
                var scroll_down = function () {
                    has_new = false;
                    if (!is_running) {
                        is_running = true;
                        element.animate({
                            scrollTop: element[0].scrollHeight
                        }, 300, function () {
                            is_running = false;
                            if (has_new) {
                                setTimeout(scroll_down);
                            }
                        });
                    }
                };
                var listener = $scope.$on(event, function (event, data) {
                    setTimeout(function () {
                        has_new = true;
                        scroll_down();
                    });
                });


                $scope.$on('$destroy', function () {
                    listener();
                    listener = null;
                })
            }
        };
    })
    .directive('msPerm', function () {
        return {
            restrict: 'A',
            link: function ($scope, tElm, tAttrs) {
                $scope.$watch(
                    function () {
                        return $.ms.permissions
                    }, function () {
                        if (tAttrs.msPerm) {
                            var perms = tAttrs.msPerm.split(",");
                            var check = $.ms.checkPermissions(perms);
                            if (!check) {
                                tElm.hide();
                            }
                            else {
                                tElm.show();
                            }
                        }
                    }
                );
            }
        };
    })
    .directive('backDragable', ['$document', "$state", function ($document, $state) {
        return {
            restrict: 'A',
            link: function ($scope, element, tAttrs) {
                var startX = 0, startY = 0, x = 0, y = 0;
                var mask = null;
                var has_move = false;
                element.css({
                    cursor: 'pointer'
                });
                element.on('mousedown', mousedown);
                function mousedown(event) {
                    // Prevent default dragging of selected content
                    event.preventDefault();
                    startX = event.pageX - x;
                    startY = event.pageY - y;
                    $document.on('mousemove', mousemove);
                    $document.on('mouseup', mouseup);
                    mask = $("<div style='position: fixed;left: 0;top: 0;right: 0;bottom: 0;z-index: 100;'>");
                    $("body").append(mask);
                    has_move = false;
                }

                function mousemove(event) {
                    y = event.pageY - startY;
                    x = event.pageX - startX;
                    if (x * x + y * y > 18) {
                        has_move = true;
                    }
                    element.css({
                        cursor: 'move'
                    });
                    element.css({
                        top: y + 'px',
                        left: x + 'px'
                    });
                }

                function mouseup() {
                    y = event.pageY - startY;
                    x = event.pageX - startX;
                    if (x < 0) {
                        x = 0;
                    }
                    if (y < 0) {
                        y = 0;
                    }
                    var max_width = $(window).width() - element.width();
                    var max_height = $(window).height() - element.height();
                    if (x > max_width) {
                        x = max_width;
                    }
                    if (y > max_height) {
                        y = max_height;
                    }
                    element.css({
                        top: y + 'px',
                        left: x + 'px'
                    });
                    $document.off('mousemove', mousemove);
                    $document.off('mouseup', mouseup);
                    if (mask) {
                        mask.remove();
                        mask = null;
                    }
                    if (!has_move) {
                        $state.go(tAttrs.backDragable);
                    }
                    element.css({
                        cursor: 'pointer'
                    });
                }

                $scope.$on(
                    "$destroy", function () {
                        $document.off('mousemove', mousemove);
                        $document.off('mouseup', mouseup);
                        element.off('mousedown', mousedown);
                        if (mask) {
                            mask.remove();
                            mask = null;
                        }
                    }
                );
            }
        };
    }])
    .directive('msIframeLoadingBar', function () {
        return {
            restrict: 'A',
            link: function ($scope, el, attrs) {
                var bar = $('<div style="position: absolute;z-index: 2000;width: 100%"><span class="bar"></span></div>');
                bar.addClass('butterbar hide');
                bar.removeClass('hide').addClass('active');
                el.on('load', function () {
                    bar.addClass('hide').removeClass('active');
                });
                el.before(bar);
                $scope.$on("$destroy", function () {
                        el.off('load');
                    }
                );
            }
        };
    })
    .directive('starttime', function () {
        return {
            require: 'ngModel',
            link: function (scope, ele, attrs, ctrl) {
                ctrl.$validators.startTime = function (modelValue, viewValue) {
                    if (modelValue) {
                        return new Date(new Date(modelValue).toLocaleDateString()) >= new Date(new Date().toLocaleDateString()) ? true : false;
                    }
                    return true;
                }
            }
        }
    })
    .directive('endtime', function () {
        return {
            require: 'ngModel',
            link: function (scope, ele, attrs, ctrl) {
                ctrl.$validators.endTime = function (modelValue, viewValue) {
                    var startTime = angular.element('#startTime').val();
                    if (modelValue) {
                        return new Date(new Date(modelValue).toLocaleDateString()) > new Date(new Date(startTime).toLocaleDateString()) ? true : false;
                    }
                    return true;
                }
            }
        }
    })
    .directive('starttimesfm', function () {
        return {
            require: 'ngModel',
            link: function (scope, ele, attrs, ctrl) {
                ctrl.$validators.startTime = function (modelValue, viewValue) {
                    if (modelValue) {
                        return new Date(new Date(modelValue)) <= new Date(new Date()) ? true : false;
                    }
                    return true;
                }
            }
        }
    })
    .directive('endtimesfm', function () {
        return {
            require: 'ngModel',
            link: function (scope, ele, attrs, ctrl) {
                ctrl.$validators.endTime = function (modelValue, viewValue) {
                    var startTime = angular.element('#ms_monitor').val();
                    if (modelValue) {
                        return new Date(new Date(modelValue)) > new Date(new Date(startTime)) ? true : false;
                    }
                    return true;
                }
            }
        }
    })
    .directive('hourvalidate', function () {
        return {
            require: 'ngModel',
            link: function (scope, ele, attrs, ctrl) {
                ctrl.$validators.hourvalidate = function (modelValue, viewValue) {
                    if (modelValue) {
                        return modelValue <= 24 && modelValue >= 0 ? true : false;
                    }
                    return true;
                }
            }
        }
    })
    .directive('minutevalidate', function () {
        return {
            require: 'ngModel',
            link: function (scope, ele, attrs, ctrl) {
                ctrl.$validators.minutevalidate = function (modelValue, viewValue) {
                    if (modelValue) {
                        return modelValue <= 59 && modelValue >= 0 ? true : false;
                    }
                    return true;
                }
            }
        }
    })
    .directive('pinteger', function () {
        return {
            require: 'ngModel',
            link: function (scope, ele, attrs, ctrl) {
                ctrl.$validators.pInteger = function (modelValue, viewValue) {
                    if (modelValue) {
                        var re = /^[0-9]*[1-9][0-9]*$/;
                        return re.test(modelValue) ? true : false;
                    }
                }
            }
        }
    })
    .directive('absPaths', function () {
        return {
            require: 'ngModel',
            link: function (scope, ele, attrs, ctrl) {
                ctrl.$validators.abs_paths = function (modelValue, viewValue) {
                    if (viewValue) {
                        var p;
                        var paths = viewValue.split(",");
                        for (var i in paths) {
                            p = paths[i];
                            if (!p || p[0] != '/' || p[p.length - 1] == '/') {
                                return false;
                            }
                        }
                    }

                    return true;
                }
            }
        }
    })
;
