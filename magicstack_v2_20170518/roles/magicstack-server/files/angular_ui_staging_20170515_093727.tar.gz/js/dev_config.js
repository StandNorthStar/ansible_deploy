/**
 * Created by fanjunwei on 2017/4/1.
 */
var CONFIG = {
    home: 'http://localhost:8080/monitor', //默认登录跳转url
    switcher:{
      deployment:true,
      setting:true,
      monitor:true,
      task:false,
    },
    login_api: 'http://172.16.30.170:8000',//登录页面数据api
    login_web: 'http://localhost:8081/auth',//登录页面web路径
    login_router_base: '/auth', //登录页面路由基础url

    monitor_api: 'http://172.16.30.170:8000',//监控页面数据api
    monitor_web: 'http://localhost:8080/monitor', //监控页面web路径
    monitor_router_base: '/monitor', //监控页面路由基础url

    angular_web: "http://localhost:3000/",
    angular_console_router: "/app/ui/overview",
    angular_admin_router: "/admin/project/list",

    task_api: 'http://172.16.30.170:8000',//任务数据api
    task_web: 'http://localhost:8082/task', //任务页面web路径
    task_router_base: '/task', //任务页面路由基础url
};
