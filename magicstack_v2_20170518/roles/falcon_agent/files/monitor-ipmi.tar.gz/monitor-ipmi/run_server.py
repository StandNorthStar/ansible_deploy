#!/usr/bin/env python
# -*- coding: utf-8 -*-
import time
from threading import Timer
import json

from wsgiref.simple_server import make_server
from falcon_ipmi import IPMI, CON_INFO, ConfigInfo, PROJECT_FILE_PATH
from views import wsgiapp, get_file_logger

application = wsgiapp
log = get_file_logger('ipmi')

def ipmi_timer(inc):
    """定时轮询ipmi接口任务"""
    # print 'start'
    timestamp = int(time.time())
    ipmi_info = CON_INFO.ipmi_con_info
    for (key, value) in ipmi_info.items():
        try:
            ipmi = IPMI(value['ip'], value['username'], value['password'])
            ConfigInfo.push_ipmi_to_transfer(ipmi, value['ip'], timestamp)
        except Exception, e:
            log.error("value:%s; faild:%s" % (value['ip'], e))
            continue

    t = Timer(inc, ipmi_timer, (inc,))
    t.setDaemon(True)
    t.start()

def main():
    """初始化"""
    try:
        with open(PROJECT_FILE_PATH+'/config.json', 'r') as f:
            content = json.loads(f.read())
        proxy_ip = content['proxy_ip']

        cron_step = content['cron_step']
        ConfigInfo.transfer_ip = content['transfer_ip']
        ConfigInfo.step = content['step']

        CON_INFO.init_data(proxy_ip)
        
        ipmi_timer(cron_step)

        httpd = make_server('', 9100, application)
        sa = httpd.socket.getsockname()
        log.info('http://{0}:{1}/'.format(*sa))

        # Respond to requests until process is killed
        httpd.serve_forever()

    except Exception, e:
        log.error('faild: %s' % e)


if __name__ == '__main__':
    main()
