# -*- coding:utf-8 -*-
import json
import logging
import logging.handlers
from urlparse import parse_qs
from application import my_app
from falcon_ipmi import CON_INFO, PROJECT_FILE_PATH


urls = (
    ("/", "Index"),
    ("/ipmi/update", "UpdateIpmi"),
    ("/ipmi/del", "DelIpmi"),
)


def get_file_logger(name, format='%(asctime)s %(levelname)s\n%(message)s\n', level=logging.DEBUG):
    log = logging.getLogger(name)
    if not log.handlers:
        handler = logging.handlers.TimedRotatingFileHandler(PROJECT_FILE_PATH+'/%s.log' % name, 'midnight', 1, 7)
        formatter = logging.Formatter(format)
        handler.setFormatter(formatter)
        log.addHandler(handler)
        log.setLevel(level)
    return log


class Index:
    def GET(self, environ, *args):
        my_app.header('Content-type', 'text/plain')
        return "Welcome!"


class BaseData(object):
    """接收并处理post 过来的json数据"""
    def __init__(self):
        self.request_body_size = 0

    @classmethod
    def read_post_data(cls, environ):
        """提取trigger过来的json数据"""
        content_type = environ.get('CONTENT_TYPE')
        try:
            cls.request_body_size = int(environ.get('CONTENT_LENGTH', 0))
        except (ValueError):
            cls.request_body_size = 0
        request_body = environ['wsgi.input'].read(cls.request_body_size)
        if content_type == "application/json":
            return json.loads(request_body)
        else:
            data = parse_qs(request_body)
            return data


class UpdateIpmi(BaseData):
    """增加/更新ipmi连接信息"""
    def __init__(self):
        super(UpdateIpmi, self).__init__()
        self.log = get_file_logger('ipmi')

    def POST(self, environ, *args):
        try:
            my_app.header('Content-type', 'text/plain')
            data = self.read_post_data(environ)
            CON_INFO.ipmi_con_info[data['id']] = dict(ip=data['ip'],
                                                      username=data['username'],
                                                      password=data['password'])
            self.log.info("update: "+json.dumps(data['id']))
        except Exception, e:
            self.log.error(e)
            return 'error'
        return 'ok'


class DelIpmi(BaseData):
    """删除ipmi连接信息"""
    def __init__(self):
        super(DelIpmi, self).__init__()
        self.log = get_file_logger('ipmi')

    def POST(self, environ, *args):
        try:
            my_app.header('Content-type', 'text/plain')
            data = self.read_post_data(environ)
            if data['id'] in CON_INFO.ipmi_con_info.keys():
                del CON_INFO.ipmi_con_info[data['id']]
                self.log.info("delete: "+json.dumps(data['id']))
        except Exception, e:
            self.log.error(e)
            return 'error'
        return 'ok'


wsgiapp = my_app(urls, globals())
