#!/usr/bin/python
# -*- coding: utf-8 -*-

from pyghmi.ipmi.command import Command
from pyghmi.ipmi.sdr import SDR
from pyghmi.ipmi.fru import FRU
import requests
import json
import copy
import os.path
import dummy


PROJECT_FILE_PATH = os.path.split(os.path.realpath(dummy.__file__))[0]

METRIC_TEMP = {
    "endpoint": "",
    "metric": "",
    "timestamp": 0,
    "step": 60,
    "value": 0,
    "counterType": "GAUGE",
    "tags": "",
}

MNAME_LIST = ["ipmi.temperature", "ipmi.fan", "ipmi.powerstate"]


class IPMI(object):

    def __init__(self, bmc, userid, password):
        self.bmc = bmc
        self.userid = userid
        self.password = password
        self.con_command = Command(bmc=self.bmc, userid=self.userid, password=self.password)
        self.info = self.all_info()

    def all_info(self):
        result = [i for i in self.con_command.get_sensor_data()]
        return result

    def cpu_info(self):
        result = {}
        for value in self.info:
            if value.type == 'Processor':
                result[value.name] = value.value
        return result

    def mem_info(self):
        result = {}
        for value in self.info:
            if value.type == 'Memory':
                result[value.name] = value.value
        return result

    def fan(self):
        result = {}
        for value in self.info:
            if value.type == 'Fan':
                result[value.name] = value.value
        return result

    def power_status(self):
        status = self.con_command.get_power()
        return status

    def temp(self):
        result = {}
        for value in self.info:
            if value.type == 'Temperature':
                result[value.name] = value.value
        return result

    def p_user(self):
        user = self.con_command.get_users()
        result = None
        for i in user.keys():
            uid = user[i].get('uid')
            result = self.con_command.get_user_access(uid)
        return result

    def fru(self):
        fru = FRU(ipmicmd=self.con_command)
        result = fru.parsedata()
        return result


class CON_INFO(object):
    """全局变量保存所有的ipmi接口信息"""
    ipmi_con_info = dict()

    @classmethod
    def init_data(self, proxy_ip):
        """初始化ipmi接口信息"""
        # test_data = {
        #     "asset_id":{
        #         "ip": '10.22.1.8',
        #         "username": 'ADMIN',
        #         "password": 'ADMIN',
        #     }
        # }
        # 请求proxy 获取初始化的ipmi连接信息
        resp = requests.get("http://"+proxy_ip+"/v1.0/ipmicollector/init", timeout=3)
        data = resp.json()['result']['serverinfos']
        for item in data:
            if item['ip'] and item['username'] and item['password']:
                self.ipmi_con_info[item['id']] = dict(ip=item['ip'],
                                                      username=item['username'],
                                                      password=item['password'])
            else:
                continue
        return


class ConfigInfo(object):
    transfer_ip = ""
    step = 60

    @classmethod
    def push_ipmi_to_transfer(self, ipmi, ipmi_ip, timestamp):

        def _make_metric(metric, value, tags=None, countertype="GAUGE"):
            tmp = copy.copy(METRIC_TEMP)
            tmp["metric"] = metric
            tmp["endpoint"] = ipmi_ip
            tmp["timestamp"] = timestamp
            tmp["step"] = self.step
            tmp["value"] = value
            tmp["tags"] = tags
            tmp["counterType"] = countertype
            return tmp

        result = list()
        for m in MNAME_LIST:
            data = list()
            if m == "ipmi.temperature":
                for (k, v) in ipmi.temp().items():
                    if not v:
                        v = 0
                    data.append(_make_metric(m, v,
                                             "device="+k.replace(' ', '_')))
            elif m == "ipmi.fan":
                for (k, v) in ipmi.fan().items():
                    if not v:
                        v = 0
                    data.append(_make_metric(m, v,
                                             "fan="+k.replace(' ', '_')))
            elif m == "ipmi.powerstate":
                value = ipmi.power_status()
                if value['powerstate'] == 'on':
                    v = 1
                else:
                    v = 0
                data.append(_make_metric(m, v))
            else:
                continue
            result += data
        # print json.dumps(result)
        transfer_host = 'http://' + self.transfer_ip + '/api/push'
        print result
        r = requests.post(transfer_host, data=json.dumps(result), timeout=3)
        print r.text
        return


if __name__ == '__main__':

    bmc = '192.168.88.199'
    userid = 'root'
    password = 'admin'
    # bmc = '10.1.121.78'
    # userid = 'USERID'
    # password = 'PASSW0RD'
    a = IPMI(bmc=bmc,userid=userid,password=password)
    # print [i for i in a.con_command.get_inventory()]
    print a.cpu_info()
    print a.mem_info()
    print a.temp()
    print a.fan()
    print a.p_user()
    print a.power_status()
