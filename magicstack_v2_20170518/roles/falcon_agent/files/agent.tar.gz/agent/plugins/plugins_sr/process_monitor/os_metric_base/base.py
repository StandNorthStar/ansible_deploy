"""processers'name is based on linux command top, and limited 15 chars."""

import socket
import copy
import json
import socket
import os.path, time
import dummy


HOSTNAME = socket.gethostname()

RESULT = list()

METRIC_TEMP = {
    "endpoint": "",
    "metric": "",
    "timestamp": 0,
    "step": 60,
    "value": 0,
    "counterType": "GAUGE",
    "tags": "",
}

PROJECT_FILE_PATH = os.path.split(os.path.realpath(dummy.__file__))[0]


class Net_Connections(object):
    """deal with all proc fd conns.
    """
    def __init__(self, ps_net_connections):
        self.net_connections = ps_net_connections

    def parse_ps_net_connections(self):
        result = dict()
        for sconn in self.net_connections:
            if result.has_key(str(sconn.pid)):
                result[str(sconn.pid)] += 1
            else:
                result[str(sconn.pid)] = 0
        return result


class OSMetric(object):
    """
    Openstack components metric module.
    """
    PROCESS_MAP = ""
    TAGPREFIX = "process="
    step = 60
    api_host = 'http://127.0.0.1:1988/v1/push'

    def __init__(self, tag, timestamp):
        """Init openstack metric object.
        :params pname: the process or sub process's name.
        :params s_tag: to know what type(openstack) or service(nova).

        !deprecated multiple threads.
        """
        self.processers = []
        self.p_active = False
        self.read_bytes = 0
        self.write_bytes = 0
        self.pname = 'process'
        self.s_tag = tag
        self.timestamp = timestamp

    def run(self, net_conns=None):
        self.parse_processers(net_conns)

    def push_data(self, payload):
        # if payload:
        #     requests.post(self.api_host, data=json.dumps(payload), timeout=3)
        global RESULT
        RESULT += payload

    def make_metric(self, metric, timestamp, step,
                    value, tags, countertype="GAUGE"):
        """Package a metric data.
        """
        tmp = copy.copy(METRIC_TEMP)
        tmp["endpoint"] = HOSTNAME
        tmp["metric"] = metric
        tmp["timestamp"] = timestamp
        tmp["step"] = step
        tmp["value"] = value
        tmp["tags"] = tags
        return tmp

    def get_procs_mem(self):
        """Calculate the porocessers mem percent.
        """
        mem_percent = list()
        for i in self.processers:
            mem_percent.append(i.memory_percent())
        m_data = round(sum(mem_percent), 4)
        return m_data

    def get_procs_con(self, net_conns):
        num = 0
        for proc in self.processers:
            if net_conns.get(proc.pid):
                num += net_conns.get(proc.pid)
        return num

    def get_procs_cpu(self, get_value=False):
        """Calculate the porocessers cpu percent.
        """
        if get_value:
            cpu_percent = list()
            for k in self.processers:
                cpu_percent.append(k.cpu_percent())
            return round(sum(cpu_percent), 4)
        else:
            for k in self.processers:
                k.cpu_percent()
            return None

    def package_processers(self, net_conns):
        """Return porocessers all metric data.
        """
        try:
            result = list()
            tags = self.TAGPREFIX + self.s_tag
            self.get_procs_cpu()
            self.push_procs_io_counter()

            m_data = self.get_procs_mem()
            mem_metric = self.pname + ".memory.percent"
            mem_data = self.make_metric(mem_metric,
                                        self.timestamp,
                                        self.step,
                                        m_data, tags)
            result.append(mem_data)

            conns = self.get_procs_con(net_conns)
            con_metric = self.pname + ".net.connections"
            con_data = self.make_metric(con_metric,
                                        self.timestamp,
                                        self.step,
                                        conns, tags)
            result.append(con_data)
        except Exception, e:
            # print e
            pass
        return result

    def push_procs_cpu_percent(self):
        result = list()
        tags = self.TAGPREFIX + self.s_tag
        cpu_metric = self.pname + ".cpu.percent"
        c_data = self.get_procs_cpu(True)
        cpu_data = self.make_metric(cpu_metric,
                                    self.timestamp,
                                    self.step,
                                    c_data, tags)
        result.append(cpu_data)
        self.push_data(result)
        return None

    def push_procs_io_counter(self):
        result = list()
        tags = self.TAGPREFIX + self.s_tag
        io_r_metric = self.pname + ".io.read_bytes"
        io_w_metric = self.pname + ".io.write_bytes"

        rc = 0
        wc = 0
        for proc in self.processers:
            rc += proc.io_counters().read_bytes
            wc += proc.io_counters().read_bytes

        r_m_data = self.make_metric(io_r_metric,
                                    self.timestamp,
                                    self.step,
                                    rc, tags, "COUNTER")
        result.append(r_m_data)
        w_m_data = self.make_metric(io_w_metric,
                                    self.timestamp,
                                    self.step,
                                    wc, tags, "COUNTER")
        result.append(w_m_data)
        self.push_data(result)
        return None

    def parse_processers(self, net_conns=None):
        """Judge the process is alive or not.
        """
        try:
            payload = self.package_processers(net_conns)
            self.push_data(payload)
        except Exception, e:
            #print e #if write into log will make too much txt.
            self.p_active = False

        if self.p_active:
            #print "success:", self.pname
            pass
        else:
            #print "failed:", self.pname
            pass
        return None
