# 安装前先把代码git到/opt下，然后在执行magicstack安装脚本
