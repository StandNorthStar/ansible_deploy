#!/usr/bin/bash

python ./libs/haproxyStats.py -f /var/lib/haproxy/stats 
