#!/usr/bin/env python

import json
import time
import socket
import urllib2
import commands
from optparse import OptionParser

host = socket.gethostname()
messages = []
HEALTH = {
        "HEALTH_OK": 0,
        "HEALTH_WARN": 1,
        "HEALTH_ERR": 2,
        }

def addmsg(metric, value, tags=None):
    m = {}
    m['metric'] = metric
    m['endpoint'] = host
    m['tags'] = tags
    m['value'] = value
    m['timestamp'] = int(time.time())
    m['step'] = int(step)
    m['counterType'] = 'GAUGE'
    messages.append(m)

def get_df_data():
    try:
        df_json = commands.getoutput('ceph df --format=json 2>/dev/null')
        df_data = json.loads(df_json)
    except:
        return
    
    df_stats_data = df_data.get("stats")
    df_pools_data = df_data.get("pools")

    #ceph.total_avail_bytes,ceph.total_used_bytes,ceph.total_bytes
    for k, v in df_stats_data.items():
        addmsg("ceph.%s" % k, v)

    #ceph.pool.used_bytes, ceph.pool.total_bytes,ceph.pool.objects
    for pool in df_pools_data:
        pool_stats = pool.get("stats")
        if pool_stats:
            tags = "name=%s,id=%d" % (pool.get("name"),pool.get("id"))
            addmsg("ceph.pool.used_bytes", pool_stats.get("bytes_used"), tags)
            addmsg("ceph.pool.total_bytes", pool_stats.get("max_avail"), tags)
            addmsg("ceph.pool.objects", pool_stats.get("objects"), tags)

def get_mon_data():
    try:
        mon_json = commands.getoutput('ceph mon dump --format=json 2>/dev/null')
        mon_data = json.loads(mon_json)
    except:
        return

    #ceph.mon.num
    addmsg("ceph.mon.num", len(mon_data.get("mons")))

def get_osd_data():
    try:
        osd_json = commands.getoutput('ceph osd dump --format=json 2>/dev/null')
        osd_data = json.loads(osd_json)
    except:
        return

    #ceph.osd.updown,ceph.osd.inout
    osd_osds_data = osd_data.get("osds")
    for osd in osd_osds_data:
        id_tag = "id=%d" % osd.get("osd")
        addmsg("ceph.osd.updown", osd.get("up"), id_tag)
        addmsg("ceph.osd.inout", osd.get("in"), id_tag)

    try:
        osd_df_json = commands.getoutput('ceph osd df --format=json 2>/dev/null')
        osd_df_data = json.loads(osd_df_json)
    except:
        return
    
    #ceph.osd.df.total_kb,ceph.osd.df.total_used_kb,ceph.osd.df.total_avail_kb
    osd_df_total = osd_df_data.get("summary")
    if osd_df_total:
        addmsg("ceph.osd.total_kb", osd_df_total.get("total_kb"))
        addmsg("ceph.osd.total_used_kb", osd_df_total.get("total_kb_avail"))
        addmsg("ceph.osd.total_avail_kb", osd_df_total.get("total_kb_used"))

    #ceph.osd.df.kb,ceph.osd.df.used_kb,ceph.osd.df.avail_kb,ceph.osd.df.percent
    osd_df_nodes = osd_df_data.get("nodes")
    for node in osd_df_nodes:
        addmsg("ceph.osd.df.kb", node.get("kb"))
        addmsg("ceph.osd.df.used_kb", node.get("kb_used"))
        addmsg("ceph.osd.df.avail_kb", node.get("kb_avail"))
        addmsg("ceph.osd.df.percent", node.get("utilization"))

def get_stat_data():
    try:
        stat_json = commands.getoutput('ceph -s -f json 2>/dev/null')
        stat_data = json.loads(stat_json)
    except:
        return

    #ceph.osd.num_osds,ceph.osd.num_in_osds,ceph.osd.num_up_osds,ceph.osd.num_remapped_pgs
    stat_osdmap = stat_data.get("osdmap").get("osdmap")
    if stat_osdmap:
        addmsg("ceph.osd.num_osds", stat_osdmap.get("num_osds"))
        addmsg("ceph.osd.num_in_osds", stat_osdmap.get("num_in_osds"))
        addmsg("ceph.osd.num_up_osds", stat_osdmap.get("num_up_osds"))
        addmsg("ceph.osd.num_remapped_pgs", stat_osdmap.get("num_remapped_pgs"))

    #ceph.mds.in, ceph.mds.up, ceph.mds.max
    stat_mdsmap = stat_data.get("mdsmap")
    if stat_mdsmap:
        addmsg("ceph.mds.in", stat_mdsmap.get("in"))
        addmsg("ceph.mds.up", stat_mdsmap.get("up"))
        addmsg("ceph.mds.max", stat_mdsmap.get("max"))

    #ceph.pg.total_bytes,ceph.pg.avail_bytes,ceph.pg.used_bytes,ceph.pg.data_bytes,
    #ceph.pg.num_pgs,ceph.pg.op_per_sec,ceph.pg.read_bytes_sec,ceph.pg.write_bytes_sec
    stat_pgmap = stat_data.get("pgmap")
    if stat_pgmap:
        addmsg("ceph.pg.total_bytes", stat_pgmap.get("bytes_total"))
        addmsg("ceph.pg.avail_bytes", stat_pgmap.get("bytes_avail"))
        addmsg("ceph.pg.used_bytes", stat_pgmap.get("bytes_used"))
        addmsg("ceph.pg.data_bytes", stat_pgmap.get("data_bytes"))
        addmsg("ceph.pg.num_pgs", stat_pgmap.get("num_pgs"))
        addmsg("ceph.pg.op_per_sec", stat_pgmap.get("op_per_sec"))
        addmsg("ceph.pg.read_bytes_sec", stat_pgmap.get("read_bytes_sec"))
        addmsg("ceph.pg.write_bytes_sec", stat_pgmap.get("write_bytes_sec"))

    #ceph.health
    stat_health =  stat_data.get("health")
    if stat_health:
        addmsg("ceph.health",
                HEALTH.get(stat_health.get("overall_status"),-1))

def get_data():
    get_stat_data()
    get_df_data()
    get_mon_data()
    get_osd_data()
    return messages

def push(message):
    try:
        urllib2.urlopen(
            url  = 'http://127.0.0.1:1988/v1/push',
            data = json.dumps(message)
            )
    except:
        pass

parser = OptionParser()
parser.add_option("-p", "--push", action="store_true", dest="push", help="push result to agent")
parser.add_option("-d", "--debug", action="store_true", dest="debug", help="output debug info")
parser.add_option("-s", "--step", action="store", dest="step", help="check special metric")
(options, args) = parser.parse_args()
if not options.step:
    step = 60
else:
    step = int(options.step)
messages = get_data() 
if options.push:
    push(messages)
else:
    print json.dumps(messages, indent=2)
