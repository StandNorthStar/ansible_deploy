import socket


HOSTNAME = socket.gethostname()

METRIC_TEMP = {
    "endpoint": "",
    "metric": "",
    "timestamp": 0,
    "step": 60,
    "value": 0,
    "counterType": "GAUGE",
    "tags": "",
}

PROCESS_MAP = {
    "sshd": {
        "active": 0,
    },
    "ntpd": {
        "active": 0,
    },
    "crond": {
        "active": 0,
    },
    "falcon-agent": {
        "active": 0,
    },
}

TAGPREFIX = "type=linux,service="
