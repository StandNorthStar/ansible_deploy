

PROCESS_MAP = {
    "neutron-server": {
        "port_list": [9696],
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/neutron/server.log",
        "active": 0,
    },
    "glance-api": {
        "port_list": [9292],
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/glance/api.log",
        "active": 0,
    },
    "glance-registry": {
        "port_list": [9191],
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/glance/registry.log",
        "active": 0,
    },
    "cinder-api": {
        "port_list": [8776],
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/cinder/api.log",
        "active": 0,
    },
    "cinder-schedule": {
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/cinder/scheduler.log",
        "active": 0,
    },
    "nova-api": {
        "port_list": [8773, 8774, 8775],
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/nova/nova-api.log",
        "active": 0,
    },
    "nova-scheduler": {
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/nova/nova-scheduler.log",
        "active": 0,
    },
    "nova-conductor": {
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/nova/nova-conductor.log",
        "active": 0,
    },
    "nova-consoleaut": {
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/nova/nova-consoleauth.log",
        "active": 0,
    },
    "nova-novncproxy": {
        "port_list": [6080],
        "log": "/var/log/nova/nova-novncproxy.log",
        "active": 0,
    },
    "nova-cert": {
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/nova/nova-cert.log",
        "active": 0,
    },
    "heat-api": {
        "port_list": [8004],
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/heat/heat-api.log",
        "active": 0,
    },
    "heat-engine": {
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/heat/heat-engine.log",
        "active": 0,
    },
    "heat-api-cfn": {
        "port_list": [8000],
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/heat/heat-api-cfn.log",
        "active": 0,
    },
    "httpd": {
        "mysql_con": 0,
        "port_list": [80],
    },
    "memcached": {
        "port_list": [11211],
        "active": 0,
    },
    "keepalived": {
        "log": "/var/log/keepalived.log",
        "active": 0,
    },
    "epmd": {
        "active": 0,
    },
    "beam.smp": {
        "active": 0,
    },
    "mysqld": {
        "active": 0,
    }
}

TAGPREFIX = "type=openstack,service="
