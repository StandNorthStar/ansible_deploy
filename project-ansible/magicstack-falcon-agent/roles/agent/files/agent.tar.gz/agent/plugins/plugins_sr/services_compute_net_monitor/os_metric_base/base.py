import copy
import json
import socket
import os.path, time

import requests

from os_metric_base.globe_define import HOSTNAME, METRIC_TEMP

RESULT = list()

class Net_Connections(object):
    """deal with all proc fd conns.
    """
    def __init__(self, ps_net_connections):
        self.net_connections = ps_net_connections

    def parse_ps_net_connections(self):
        result = dict()
        for sconn in self.net_connections:
            if result.get(str(sconn.pid)):
                if sconn.laddr:
                    result[str(sconn.pid)]['laddr'].append(sconn.laddr[1])
                if sconn.raddr:
                    result[str(sconn.pid)]['raddr'].append(sconn.raddr[1])
            else:
                result[str(sconn.pid)] = dict(laddr=list(), raddr=list())
        return result


class OSMetric(object):
    """
    Openstack components metric module.
    """
    PROCESS_MAP = ""
    TAGPREFIX = ""
    step = 60
    api_host = 'http://127.0.0.1:1988/v1/push'

    def __init__(self, pname, s_tag, timestamp):
        """Init openstack metric object.
        :params pname: the process or sub process's name.
        :params s_tag: to know what type(openstack) or service(nova).

        !deprecated multiple threads.
        """
        self.processers = []
        self.p_active = False
        self.pname = pname
        self.s_tag = s_tag
        self.timestamp = timestamp

    def run(self, net_conns=None):
        self.parse_processers(net_conns)

    def push_data(self, payload):
        # if payload:
        #     requests.post(self.api_host, data=json.dumps(payload), timeout=3)
        global RESULT
        RESULT += payload

    def make_metric(self, metric, timestamp, step,
                    value, tags):
        """Package a metric data.
        """
        tmp = copy.copy(METRIC_TEMP)
        tmp["endpoint"] = HOSTNAME
        tmp["metric"] = metric
        tmp["timestamp"] = timestamp
        tmp["step"] = step
        tmp["value"] = value
        tmp["tags"] = tags
        return tmp

    def get_procs_mem(self):
        """Calculate the porocessers mem percent.
        """
        mem_percent = list()
        for i in self.processers:
            # i.get_cpu_percent()
            mem_percent.append(i.memory_percent())
        m_data = round(sum(mem_percent), 4)
        return m_data

    def get_procs_cpu(self, get_value=False):
        """Calculate the porocessers cpu percent.
        """
        if get_value:
            cpu_percent = list()
            for k in self.processers:
                cpu_percent.append(k.cpu_percent())
            return round(sum(cpu_percent), 4)
        else:
            for k in self.processers:
                k.cpu_percent()
        return None

    def read_porc_config(self, configs, tags, l_ports=[], r_ports=[]):
        """read proc's configs and calculate ports.
        """
        for k, v in configs.items():
            if k == 'port_list':
                for i in v:
                    metric = self.pname + ".port." + str(i)
                    data = self.make_metric(metric,
                                            self.timestamp,
                                            self.step,
                                            l_ports.count(i),
                                            tags)
                    yield data
            else:
                if k == 'mysql_con':
                    metric = self.pname + ".mysql_connection"
                    p_value = r_ports.count(3306)
                if k == 'rabbit_con':
                    metric = self.pname + ".rabbit_connection"
                    p_value = r_ports.count(5672)
                if k == 'log':
                    metric = self.pname + ".log.time"
                    log_time = os.stat(v).st_mtime
                    p_value = round(time.time() - log_time, 4)
                if k == 'active':
                    metric = self.pname + ".process"
                    if self.p_active:
                        p_value = 1
                    else:
                        p_value = 0
                data = self.make_metric(metric,
                                        self.timestamp,
                                        self.step,
                                        p_value, tags)
                yield data

    def parse_proc_ports(self, configs, net_conns):
        """Parse all conns with pid.
        """
        l_ports = list()
        r_ports = list()
        p_judge = False

        for i in configs:
            if i in ['port_list', 'mysql_con', 'rabbit_con']:
                p_judge = True
                break

        if p_judge and net_conns:
            for proc in self.processers:
                if net_conns.get(str(proc.pid)):
                    l_ports += net_conns.get(str(proc.pid))['laddr']
                    r_ports += net_conns.get(str(proc.pid))['raddr']
        return l_ports, r_ports

    def package_processers(self, configs, net_conns):
        """Return porocessers all metric data.
        """
        result = list()
        tags = self.TAGPREFIX + self.s_tag
        self.get_procs_cpu()

        m_data = self.get_procs_mem()
        l_ports, r_ports = self.parse_proc_ports(configs, net_conns)

        for data in self.read_porc_config(configs, tags, l_ports, r_ports):
            result.append(data)

        mem_metric = self.pname + ".memory.percent"
        mem_data = self.make_metric(mem_metric,
                                    self.timestamp,
                                    self.step,
                                    m_data, tags)
        result.append(mem_data)
        return result

    def push_procs_cpu_precent(self):
        result = list()
        tags = self.TAGPREFIX + self.s_tag
        cpu_metric = self.pname + ".cpu.percent"
        c_data = self.get_procs_cpu(True)
        cpu_data = self.make_metric(cpu_metric,
                                    self.timestamp,
                                    self.step,
                                    c_data, tags)
        result.append(cpu_data)
        self.push_data(result)
        return None

    def parse_processers(self, net_conns=None):
        """Judge the process is alive or not.
        """
        try:
            configs = self.PROCESS_MAP[self.pname]
            payload = self.package_processers(configs, net_conns)
            self.push_data(payload)
        except Exception, e:
            #print e #if write into log will make too much txt.
            self.p_active = False

        if self.p_active:
            #print "success:", self.pname
            pass
        else:
            #print "failed:", self.pname
            pass
        return None
