#!/usr/bin/bash

cd ./plugins/plugins_sr/mysql_monitor/
./bin/mysql_mon -c etc/mon.cfg
