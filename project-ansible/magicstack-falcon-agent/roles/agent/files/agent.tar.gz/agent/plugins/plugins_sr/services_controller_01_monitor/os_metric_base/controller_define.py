

PROCESS_MAP = {
    "ceilometer-alarm-evaluator": {
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/ceilometer/alarm-evaluator.log",
        "active": 0,
    },
    "ceilometer-polling": {
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/ceilometer/central.log",
        "active": 0,
    },
    "ceilometer-alarm-notifier": {
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/ceilometer/alarm-notifier.log",
        "active": 0,
    },
    "ceilometer-api": {
        "port_list": [8777],
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/ceilometer/api.log",
        "active": 0,
    },
    "ceilometer-collector": {
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/ceilometer/collector.log",
        "active": 0,
    },
    "ceilometer-agent-notification": {
        "port_list": [5672],
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/ceilometer/agent-notification.log",
        "active": 0,
    },
    "portal-service-cache": {
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/portal/cache.log",
        "active": 0,
    },
    "portal-service-notify": {
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/portal/notifier.log",
        "active": 0,
    },
    "portal-service-rating": {
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/portal/rating.log",
        "active": 0,
    },
    "portal-service-rating_ext": {
        "log": "/var/log/portal/rating_ext.log",
        "active": 0,
    },
    "portal-service-wss": {
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/portal/websocket.log",
        "active": 0,
    },
    "mongos": {
        "port_list": [27017],
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/mongodb/mongos.log",
        "active": 0,
    },
    "mongod": {
        "port_list": [27018],
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/mongodb/mongod.log",
        "active": 0,
    },
}

TAGPREFIX = "type=openstack,service="
