#!/usr/bin/env python
import time
import json

import psutil

from os_metric_base.base import OSMetric, RESULT
from os_metric_base.compute_net_define import PROCESS_MAP, TAGPREFIX


class ComputeNetMetric(OSMetric):
    PROCESS_MAP = PROCESS_MAP
    TAGPREFIX = TAGPREFIX
    pass


class NovaCompute(ComputeNetMetric):
    pass


class CinderVolume(ComputeNetMetric):
    pass


class NeutronLinuxbridgeAgent(ComputeNetMetric):
    pass


class Libvirtd(ComputeNetMetric):
    pass

class CeilometerPolling(ComputeNetMetric):
    pass


def main():
    vm_thread_list = list()
    timestamp = int(time.time())

    nova_compute = NovaCompute('nova-compute', 'nova', timestamp)
    cinder_volume = CinderVolume('cinder-volume', 'cinder', timestamp)
    libvirtd = Libvirtd('libvirtd', 'libvirt', timestamp)
    neutron_lb_agent = NeutronLinuxbridgeAgent('neutron-linuxbridge-agent',
                                               'neutron', timestamp)
    ceilometer_polling = CeilometerPolling('ceilometer-polling','ceilometer', timestamp)

    for proc in psutil.process_iter():
        try:
            if proc.name() == "nova-compute":
                nova_compute.p_active = True
                nova_compute.processers.append(proc)
            elif proc.name() == "cinder-volume":
                cinder_volume.p_active = True
                cinder_volume.processers.append(proc)
            elif proc.name() == "libvirtd":
                libvirtd.p_active = True
                libvirtd.processers.append(proc)
            elif proc.name() == "neutron-linuxbr":
                neutron_lb_agent.p_active = True
                neutron_lb_agent.processers.append(proc)
            elif proc.name() == "ceilometer-polling":
                ceilometer_polling.p_active = True
                ceilometer_polling.processers.append(proc)
            else:
                pass
        except Exception, e:
            # print e
            pass

    task_list = [nova_compute, cinder_volume, libvirtd, neutron_lb_agent,ceilometer_polling]

    for task in task_list:
        # timestamp = int(time.time())
        task.run()
        # print "finished! %d seconds" % (int(time.time()) - timestamp)
    time.sleep(1)
    for task in task_list:
        # timestamp = int(time.time())
        task.push_procs_cpu_precent()
        # print "finished! %d seconds" % (int(time.time()) - timestamp)
    print json.dumps(RESULT)


if __name__ == '__main__':
    main()
