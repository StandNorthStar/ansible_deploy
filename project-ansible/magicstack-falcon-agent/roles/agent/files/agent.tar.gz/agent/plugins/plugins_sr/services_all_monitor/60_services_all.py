#!/usr/bin/env python
import time
import json

import psutil

from os_metric_base.base import OSMetric, RESULT
from os_metric_base.globe_define import PROCESS_MAP, TAGPREFIX


class LinuxMetric(OSMetric):
    PROCESS_MAP = PROCESS_MAP
    TAGPREFIX = TAGPREFIX
    pass


class Sshd(LinuxMetric):
    pass


class Ntpd(LinuxMetric):
    pass


class Crond(LinuxMetric):
    pass

class FalconAgent(LinuxMetric):
    pass

def main():
    vm_thread_list = list()
    timestamp = int(time.time())

    sshd = Sshd('sshd', 'ssh', timestamp)
    ntpd = Ntpd('ntpd', 'ntpd', timestamp)
    crond = Crond('crond', 'crond', timestamp)
    falcon_agent = FalconAgent('falcon-agent', 'falcon-agent', timestamp)

    for proc in psutil.process_iter():
        try:
            if proc.name() == "sshd":
                sshd.p_active = True
                sshd.processers.append(proc)
            elif proc.name() == "ntpd":
                ntpd.p_active = True
                ntpd.processers.append(proc)
            elif proc.name() == "crond":
                crond.p_active = True
                crond.processers.append(proc)
            elif proc.name() == "falcon-agent":
                falcon_agent.p_active = True
                falcon_agent.processers.append(proc)
            else:
                pass
        except Exception, e:
            #print e
            pass

    task_list = [sshd, ntpd, crond, falcon_agent]

    for task in task_list:
        # timestamp = int(time.time())
        task.run()
        # print "finished! %d seconds" % (int(time.time()) - timestamp)
    time.sleep(1)
    for task in task_list:
        # timestamp = int(time.time())
        task.push_procs_cpu_precent()
        # print "finished! %d seconds" % (int(time.time()) - timestamp)
    print json.dumps(RESULT)


if __name__ == '__main__':
    main()
