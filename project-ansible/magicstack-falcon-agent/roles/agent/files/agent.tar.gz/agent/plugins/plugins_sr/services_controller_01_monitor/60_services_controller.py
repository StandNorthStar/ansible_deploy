#!/usr/bin/env python
import time
import json

import psutil

from os_metric_base.base import Net_Connections, OSMetric, RESULT
from os_metric_base.controller_define import PROCESS_MAP, TAGPREFIX


class ControllerMetric(OSMetric):
    PROCESS_MAP = PROCESS_MAP
    TAGPREFIX = TAGPREFIX
    pass


class CeilometerAlarmEvaluator(ControllerMetric):
    pass


class CeilometerPolling(ControllerMetric):
    pass


class CeilometerAlarmNotifier(ControllerMetric):
    pass


class CeilometerApi(ControllerMetric):
    pass


class CeilometerCollector(ControllerMetric):
    pass


class CeilometerAgentNotification(ControllerMetric):
    pass


class PortalServiceCache(ControllerMetric):
    pass


class PortalServiceNotify(ControllerMetric):
    pass


class PortalServiceRating(ControllerMetric):
    pass


class PortalServiceRating_ext(ControllerMetric):
    pass


class PortalServiceWss(ControllerMetric):
    pass


class Mongos(ControllerMetric):
    pass

class Mongod(ControllerMetric):
    pass

def main():
    vm_thread_list = list()
    timestamp = int(time.time())

    net_connections = Net_Connections(psutil.net_connections(kind='inet'))
    net_conns = net_connections.parse_ps_net_connections()

    ceilometer_alarm_evaluator = CeilometerAlarmEvaluator('ceilometer-alarm-evaluator', 'ceilometer', timestamp)
    ceilometer_polling = CeilometerPolling('ceilometer-polling', 'ceilometer', timestamp)
    ceilometer_alarm_notifier = CeilometerAlarmNotifier('ceilometer-alarm-notifier','ceilometer', timestamp)
    ceilometer_api = CeilometerApi('ceilometer-api', 'ceilometer', timestamp)
    ceilometer_collector = CeilometerCollector('ceilometer-collector', 'ceilometer', timestamp)
    ceilometer_agent_notification = CeilometerAgentNotification('ceilometer-agent-notification', 'ceilometer', timestamp)

    portal_service_cache = PortalServiceCache('portal-service-cache', 'portal', timestamp)
    portal_service_notify = PortalServiceNotify('portal-service-notify', 'portal', timestamp)
    portal_service_rating = PortalServiceRating('portal-service-rating', 'portal', timestamp)
    portal_service_rating_ext = PortalServiceRating_ext('portal-service-rating_ext', 'portal', timestamp)
    portal_service_wss = PortalServiceWss('portal-service-wss', 'portal', timestamp)

    mongos = Mongos('mongos', 'mongos', timestamp)
    mongod = Mongod('mongod', 'mongos', timestamp)

    for proc in psutil.process_iter():
        try:
            if proc.name() == "ceilometer-alarm-evaluator":
                ceilometer_alarm_evaluator.p_active = True
                ceilometer_alarm_evaluator.processers.append(proc)
            elif proc.name() == "ceilometer-polling":
                ceilometer_api.p_active = True
                ceilometer_alarm_evaluator.processers.append(proc)
            elif proc.name() == "ceilometer-alarm-notifier":
                ceilometer_alarm_notifier.p_active = True
                ceilometer_alarm_notifier.processers.append(proc)
            elif proc.name() == "ceilometer-api":
                ceilometer_api.p_active = True
                ceilometer_api.processers.append(proc)
            elif proc.name() == "ceilometer-collector":
                ceilometer_collector.p_active = True
                ceilometer_collector.processers.append(proc)
            elif proc.name() == "ceilometer-agent-notification":
                ceilometer_agent_notification.p_active = True
                ceilometer_agent_notification.processers.append(proc)
            elif proc.name() == "portal-service-cache":
                portal_service_cache.p_active = True
                portal_service_cache.processers.append(proc)
            elif proc.name() == "portal-service-notify":
                portal_service_notify.p_active = True
                portal_service_notify.processers.append(proc)
            elif proc.name() == "portal-service-rating":
                portal_service_rating.p_active = True
                portal_service_rating.processers.append(proc)
            elif proc.name() == "portal-service-rating_ext":
                portal_service_rating_ext.p_active = True
                portal_service_rating_ext.processers.append(proc)
            elif proc.name() == "portal-service-wss":
                portal_service_wss.p_active = True
                portal_service_wss.processers.append(proc)
            elif proc.name() == "mongos":
                mongos.p_active = True
                mongos.processers.append(proc)
            elif proc.name() == "mongod":
                mongod.p_active = True
                mongod.processers.append(proc)
            else:
                pass
        except Exception, e:
            #print e
            pass

    # print "prepared: ok, used %d seconds" % (int(time.time()) - timestamp)
    task_list = [ceilometer_alarm_evaluator,ceilometer_polling,ceilometer_alarm_notifier,
                 ceilometer_api,ceilometer_collector,ceilometer_agent_notification,
                 portal_service_cache,portal_service_notify,portal_service_rating,
                 portal_service_rating_ext,portal_service_wss,mongos,mongod]

    for task in task_list:
        # timestamp = int(time.time())
        task.run(net_conns)
        # print "finished! %d seconds" % (int(time.time()) - timestamp)
    time.sleep(1)
    for task in task_list:
        # timestamp = int(time.time())
        task.push_procs_cpu_precent()
        # print "finished! %d seconds" % (int(time.time()) - timestamp)
    print json.dumps(RESULT)


if __name__ == '__main__':
    main()
