#!/usr/bin/env python
import time
import json

import psutil

from os_metric_base.base import Net_Connections, OSMetric, RESULT
from os_metric_base.controller_define import PROCESS_MAP, TAGPREFIX


class ControllerMetric(OSMetric):
    PROCESS_MAP = PROCESS_MAP
    TAGPREFIX = TAGPREFIX
    pass


class NeutronServer(ControllerMetric):
    pass


class GlanceApi(ControllerMetric):
    pass


class GlanceRegistry(ControllerMetric):
    pass


class CinderApi(ControllerMetric):
    pass


class CinderSchedule(ControllerMetric):
    pass


class KeystoneAll(ControllerMetric):
    pass


class NovaApi(ControllerMetric):
    pass


class NovaScheduler(ControllerMetric):
    pass


class NovaConductor(ControllerMetric):
    pass


class NovaConsoleaut(ControllerMetric):
    pass


class NovaNovncproxy(ControllerMetric):
    pass


class NovaCert(ControllerMetric):
    pass


class HeatApi(ControllerMetric):
    pass


class HeatEngine(ControllerMetric):
    pass


class HeatApiCfn(ControllerMetric):
    pass


class Httpd(ControllerMetric):
    pass


class Memcached(ControllerMetric):
    pass


class Keepalived(ControllerMetric):
    pass


class Epmd(ControllerMetric):
    pass


class BeamSmp(ControllerMetric):
    pass


class Mysqld(ControllerMetric):
    pass


def main():
    vm_thread_list = list()
    timestamp = int(time.time())

    net_connections = Net_Connections(psutil.net_connections(kind='inet'))
    net_conns = net_connections.parse_ps_net_connections()

    neutron_server = NeutronServer('neutron-server', 'neutron', timestamp)
    glance_api = GlanceApi('glance-api', 'glance', timestamp)
    glance_registry = GlanceRegistry('glance-registry',
                                     'glance', timestamp)
    cinder_api = CinderApi('cinder-api', 'cinder', timestamp)
    cinder_schedule = CinderSchedule('cinder-schedule', 'cinder', timestamp)
    nova_api = NovaApi('nova-api', 'nova', timestamp)
    nova_scheduler = NovaScheduler('nova-scheduler', 'nova', timestamp)
    nova_conductor = NovaConductor('nova-conductor', 'nova', timestamp)
    nova_consoleaut = NovaConsoleaut('nova-consoleaut', 'nova', timestamp)
    nova_novncproxy = NovaNovncproxy('nova-novncproxy', 'nova', timestamp)
    nova_cert = NovaCert('nova-cert', 'nova', timestamp)
    heat_api = HeatApi('heat-api', 'heat', timestamp)
    heat_engine = HeatEngine('heat-engine', 'heat', timestamp)
    heat_apicfn = HeatApiCfn('heat-api-cfn', 'heat', timestamp)
    httpd = Httpd('httpd', 'dashboard', timestamp)
    memcached = Memcached('memcached', 'memcache', timestamp)
    keepalived = Keepalived('keepalived', 'keepalive', timestamp)
    epmd = Epmd('epmd', 'rabbitmqctl', timestamp)
    beam_smp = BeamSmp('beam.smp', 'rabbitmq', timestamp)
    mysqld = Mysqld('mysqld', 'mysql', timestamp)

    for proc in psutil.process_iter():
        try:
            if proc.name() == "neutron-server":
                neutron_server.p_active = True
                neutron_server.processers.append(proc)
            elif proc.name() == "glance-api":
                glance_api.p_active = True
                glance_api.processers.append(proc)
            elif proc.name() == "glance-registry":
                glance_registry.p_active = True
                glance_registry.processers.append(proc)
            elif proc.name() == "cinder-api":
                cinder_api.p_active = True
                cinder_api.processers.append(proc)
            elif proc.name() == "cinder-schedule":
                cinder_schedule.p_active = True
                cinder_schedule.processers.append(proc)
            elif proc.name() == "nova-api":
                nova_api.p_active = True
                nova_api.processers.append(proc)
            elif proc.name() == "nova-scheduler":
                nova_scheduler.p_active = True
                nova_scheduler.processers.append(proc)
            elif proc.name() == "nova-conductor":
                nova_conductor.p_active = True
                nova_conductor.processers.append(proc)
            elif proc.name() == "nova-consoleaut":
                nova_consoleaut.p_active = True
                nova_consoleaut.processers.append(proc)
            elif proc.name() == "nova-novncproxy":
                nova_novncproxy.p_active = True
                nova_novncproxy.processers.append(proc)
            elif proc.name() == "nova-cert":
                nova_cert.p_active = True
                nova_cert.processers.append(proc)
            elif proc.name() == "heat-api":
                heat_api.p_active = True
                heat_api.processers.append(proc)
            elif proc.name() == "heat-engine":
                heat_engine.p_active = True
                heat_engine.processers.append(proc)
            elif proc.name() == "heat-api-cfn":
                heat_apicfn.p_active = True
                heat_apicfn.processers.append(proc)
            elif proc.name() == "httpd":
                httpd.p_active = True
                httpd.processers.append(proc)
            elif proc.name() == "memcached":
                memcached.p_active = True
                memcached.processers.append(proc)
            elif proc.name() == "keepalived":
                keepalived.p_active = True
                keepalived.processers.append(proc)
            elif proc.name() == 'epmd':
                epmd.p_active = True
                epmd.processers.append(proc)
            elif proc.name() == 'beam.smp':
                beam_smp.p_active = True
                beam_smp.processers.append(proc)
            elif proc.name() == 'mysqld':
                mysqld.p_active = True
                mysqld.processers.append(proc)
            else:
                pass
        except Exception, e:
            #print e
            pass

    # print "prepared: ok, used %d seconds" % (int(time.time()) - timestamp)
    task_list = [neutron_server, glance_api, glance_registry,
                 cinder_api, cinder_schedule,
                 nova_api, nova_scheduler, nova_conductor,
                 nova_consoleaut, nova_novncproxy, nova_cert,
                 heat_api, heat_engine, heat_apicfn, httpd,
                 memcached, keepalived, epmd, beam_smp, mysqld]

    for task in task_list:
        # timestamp = int(time.time())
        task.run(net_conns)
        # print "finished! %d seconds" % (int(time.time()) - timestamp)
    time.sleep(1)
    for task in task_list:
        # timestamp = int(time.time())
        task.push_procs_cpu_precent()
        # print "finished! %d seconds" % (int(time.time()) - timestamp)
    print json.dumps(RESULT)


if __name__ == '__main__':
    main()
