#!/usr/bin/env python
import time
import json
import zlib
import base64
import copy
import threading
import requests

import libvirt
import libvirt_qemu

CMD_TEMP = {'windows': '{"execute":"guest-command-execute", '
                       '"arguments":{"path":"python qga_main %s"}}',
            'linux': '{"execute":"guest-command-execute", '
                     '"arguments":{"path":"qga_main %s"}}',
            'info': '{"execute":"guest-info"}'}

METRIC_TEMP = {
    "endpoint": "",
    "metric": "",
    "timestamp": 0,
    "step": 60,
    "value": 0,
    "counterType": "GAUGE",
    "tags": "",
}

ITEM_LIST = ['cpu', 'disk', 'memory', 'network']

VM_TO_OPENFALCON = {
    "cpu.load.1min": "load.1min",
    "cpu.load.5min": "load.5min",
    "cpu.load.15min": "load.15min",
    "cpu.usage.percent": "cpu.busy",
    "disk.read.iops": "disk.io.read_requests",
    "disk.write.iops": "disk.io.write_requests",
    "disk.read.bps": "disk.io.read_bytes",
    "disk.write.bps": "disk.io.write_bytes",
    "disk.size.total": "df.bytes.total",
    "disk.size.used": "df.bytes.used",
    "memory.total": "mem.memtotal",
    "memory.avail": "mem.memfree",
    "memory.swap.total": "mem.swaptotal",
    "memory.swap.avail": "mem.swapfree",
    "network.incoming.bytes": "net.if.in.bytes",
    "network.outgoing.bytes": "net.if.out.bytes",
    "network.ip.incoming.datagrams": "net.if.in.packets",
    "network.ip.outgoing.datagrams": "net.if.out.packets",
    "network.outgoing.errors": "net.if.out.errors",
    "network.bandwidth.bits": "net.if.speed.bits",
}

METRIC_CONTER_LIST = ["disk.read.iops",
                      "disk.write.iops",
                      "disk.read.bps",
                      "disk.write.bps",
                      "network.incoming.bytes",
                      "network.outgoing.bytes",
                      "network.ip.incoming.datagrams",
                      "network.ip.outgoing.datagrams"]

RESULT = list()

class InstanceThread(threading.Thread):
    """
    Get monitor data from qga, init with libvirt domain, os_type, timestamp.
    Push all monitor data to local open-falcon agent.
    """
    step = 60
    api_host = 'http://127.0.0.1:1988/v1/push'

    def __init__(self, domain, os_type, timestamp):
        threading.Thread.__init__(self)
        self.domain = domain
        self.os_type = os_type
        self.timestamp = timestamp

    def run(self):
        self.parse_domain()

    def parse_qga_data(self, qga_data, m_type):
        """
        Deal with the data type return dict type.
        """
        compress_output = qga_data['return']['buf-b64'].strip()
        try:
            sample_str = zlib.decompress(base64.b64decode(compress_output))
        except:
            sample_str = compress_output
        sample = eval(sample_str)
        if eval(sample['result']):
            result = sample[m_type]
            return result
        else:
            return None

    def package_data(self, data, m_type):
        """
        Pakage monitor data with ignoring os_type.
        Make tag for a serial same type monitor data.
        """
        payload = []
        if m_type == 'memory':
            data = [data]

        tag = "name=%s,type=vm" % m_type
        for index in range(0, len(data)):
            if m_type == 'disk':
                tag += ",device=%s" % data[index]['device']
            elif m_type == 'network':
                tag += ",device=%s" % data[index]['name']
            else:
                pass

            for k, v in data[index].items():
                if k in ['device', 'mac', 'Description', 'name']:
                    continue
                tmp = copy.copy(METRIC_TEMP)
                tmp['endpoint'] = self.domain.UUIDString()
                tmp['metric'] = VM_TO_OPENFALCON.get(k) or k
                tmp['timestamp'] = self.timestamp
                tmp['value'] = v
                tmp['tags'] = tag
                if k in METRIC_CONTER_LIST:
                    tmp['counterType'] = 'COUNTER'
                payload.append(tmp)
        return payload

    def metric_data_handler(self, qga_data, m_type):
        """
        Parse data and package data.
        """
        data = self.parse_qga_data(qga_data, m_type)
        if data:
            return self.package_data(data, m_type)
        else:
            return None

    def push_data(self, payload):
        # requests.post(self.api_host, data=json.dumps(payload))
        print payload

    def parse_domain(self):
        """
        Get data from qga according the os_type and m_type.
        Send data to func metric_data_handler.
        """
        for m_type in ITEM_LIST:
            try:
                output = libvirt_qemu.qemuAgentCommand(self.domain,
                                                       CMD_TEMP[self.os_type]
                                                       % m_type,
                                                       60, 0)
                output = json.loads(output)
                payload = self.metric_data_handler(output, m_type)
                if payload:
                    global RESULT
                    RESULT += payload
            except Exception as e:
                print e
                continue
        return None


def main():
    """
    Connect to libvirt and init InstanceThread with os_type,
    which judged from the guest-info command.

    Uncomment print line to debug the script.
    """
    vm_thread_list = []
    timestamp = int(time.time())

    conn = libvirt.open('qemu:///system')
    domains = conn.listAllDomains()
    # print "%d domains" % len(domains)

    for dom in domains:
        if dom.info()[0] == 1:
            try:
                output = libvirt_qemu.qemuAgentCommand(dom,
                                                       CMD_TEMP['info'], 60, 0)
                output = json.loads(output)
                if output['return']['supported_commands'][1]['enabled']:
                    vm_thread = InstanceThread(dom, 'linux', timestamp)
                    vm_thread_list.append(vm_thread)
                else:
                    vm_thread = InstanceThread(dom, 'windows', timestamp)
                    vm_thread_list.append(vm_thread)

            except:
                continue
    conn.close()

    # print "strart: %d threads" % len(vm_thread_list)
    # vm_thread_list[0].start()
    # vm_thread_list[0].join()
    # print "end"
    for th in vm_thread_list:
        th.start()

    for th in vm_thread_list:
        th.join()

    print json.dumps(RESULT)

if __name__ == '__main__':
    main()
