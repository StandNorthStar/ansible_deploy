#!/usr/bin/env python
"""A wrapper script with srvadmin and other tools for hardware monitor.

Supported metrics:
    cpu memory raidcard pdisk vdisk raidcard_bat
    bios cmos_bat fan power board_temp cpu_temp

"""

import subprocess
import json
import time
import socket
import urllib2
import requests
from optparse import OptionParser

host = socket.gethostname()
messages = []

def addmsg(metric, value):
    m = {}
    m['metric'] = 'hw.%s' % metric.lower()
    m['endpoint'] = host
    m['tags'] = ''
    m['value'] = value
    m['timestamp'] = int(time.time())
    m['step'] = int(step)
    m['counterType'] = 'GAUGE'
    messages.append(m)

def map_value(state):
    statemap = {0:['crit', 'critical'],
                1:['warn', 'warning', 'non-critical'],
                2:['ok', 'ready']
                }
    for i in statemap:
        if state.lower() in statemap[i]:
            return i

def execute(cmd):
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=True)
    return p.communicate()

def check_fan():
    cmd = 'ipmitool sdr type Fan'
    stdout, stderr = execute(cmd)
    fans = [fan for fan in stdout.splitlines() if 'RPM' in fan]
    if not fans:
        return
    for line in fans:
        i = line.split('|')
        Index = i[0].strip().replace(' ','.')
        Value = i[4].strip().split()[0]
        addmsg(Index, Value)

def check_voltage():
    cmd = 'ipmitool sdr type Voltage'
    stdout, stderr = execute(cmd)
    voltages = [vol for vol in stdout.splitlines() if 'Volts' in vol]
    if not voltages:
        return
    for line in voltages:
        i = line.split('|')
        Index = i[0].strip().replace(' ','.')
        Value = i[4].strip().split()[0]
        addmsg(Index, Value)

def check_temp():
    cmd = 'ipmitool sdr type Temperature'
    stdout, stderr = execute(cmd)
    temps = [temp for temp in stdout.splitlines() if 'degrees C' in temp]
    if not temps:
        return
    for line in temps:
        i = line.split('|')
        Index = i[0].strip().replace(' ','.')
        Value = i[4].strip().split()[0]
        addmsg(Index, Value)

def check_power_supply():
    cmd = "ipmitool sdr type 'Power Supply'"
    stdout, stderr = execute(cmd)
    supplys = [supply for supply in stdout.splitlines() if 'detected' in supply]
    if not supplys:
        return
    for line in supplys:
        Value = 0
        i = line.split('|')
        Index = i[0].strip().replace(' ','.')
        Status = i[2].strip()
        if Status == 'ok':
            Value = 1
        addmsg(Index, Value)
# power
def check_power_status():
    cmd = 'ipmitool power status'
    stdout, stderr = execute(cmd)
    powers = [pwr for pwr in stdout.splitlines()]
    Value = 0
    if 'on' in powers:
        Value = 1
    addmsg('power-status', Value)

# board temp

# cpu temp
def check(target=False):
    if not target:
        check_fan()
        check_temp()
        check_power_supply()
        check_voltage()
        check_power_status()
    elif target == 'voltage':
        check_voltage()
    elif target == 'fan':
        check_fan()
    elif target == 'power_supply':
        check_power_supply()
    elif target == 'temp':
        check_temp()
    elif target == 'power_status':
        check_power_status()
    return messages

def push(message):
    try:
        url = 'http://127.0.0.1:1988/v1/push'
        data = json.dumps(message)
        requests.post(url, data=data, timeout=30)
    except Exception, e:
        print e
    return None

def main():
    metrics = ['temp','fan','power_status','power_supply','voltage']
    parser = OptionParser()
    parser.add_option("-p", "--push", action="store_true", dest="push", help="push result to agent")
    parser.add_option("-d", "--debug", action="store_true", dest="debug", help="output debug info")
    parser.add_option("-m", "--metric", action="store", dest="metric", help="check special metric")
    parser.add_option("-s", "--step", action="store", dest="step", help="check special metric")
    (options, args) = parser.parse_args()
    global step
    if not options.step:
        step = 60
    else:
        step = int(options.step)
    metric=None
    if options.metric:
        metric = options.metric
        if metric not in metrics:
            print __doc__
            parser.print_help()
            exit(1)
    messages = check(target=metric)
    if options.push:
        push(messages)
    else:
        print json.dumps(messages, indent=2)

if __name__ == '__main__':
    main()
