

PROCESS_MAP = {
    "nova-compute": {
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/nova/nova-compute.log",
        "active": 0,
    },
    "cinder-volume": {
        "mysql_con": 0,
        "rabbit_con": 0,
        "log": "/var/log/cinder/volume.log",
        "active": 0,
    },
    "libvirtd": {
        "active": 0,
    },
    "neutron-linuxbridge-agent": {
        "rabbit_con": 0,
        "log": "/var/log/linuxbridge-agent.log",
        "active": 0,
    },
    "ceilometer-polling": {
        "rabbit_con": 0,
        "log": "/var/log/ceilometer/central.log",
        "active": 0,
    }
}

TAGPREFIX = "type=openstack,service="
