#!/usr/bin/env python
import time
import json
from optparse import OptionParser

import psutil
from os_metric_base.base import OSMetric, Net_Connections, RESULT, PROJECT_FILE_PATH


BLACK_LIST = ["scsi_tmf_1", "scsi_tmf_0", "xfsalloc", "fsnotify_mark",
              "systemd-logind", "dbus-daemon", "systemd", "khugepaged",
              "khungtaskd", "kpsmoused", "qmgr", "lvmetad", "ata_sff",
              "crypto", "tuned", "auditd", "rcu_bh", "atd", "rcu_sched",
              "pickup", "irqbalance", "writeback", "deferwq", "events_power_ef",
              "kdevtmpfs", "ipv6_addrconf", "kmpath_rdacd", "bioset",
              "kswapd0", "qxl_gc", "systemd-udevd", "agetty", "kauditd",
              "kblockd", "wpa_supplicant", "scsi_eh_0", "scsi_eh_1",
              "ksmd", "ttm_swap", "perf", "polkitd", "xfs_mru_cache", "bash",
              "netns", "kthrotld", "khelper", "md", "systemd-journald",
              "kintegrityd", "nslcd", "kthreadd", "vballoon", "sh"]


def get_process_name():
    name_list = list()
    result = list()

    for proc in psutil.process_iter():
        name_list.append(proc.name())

    for i in list(set(name_list)):
        if ('/' in i) or (i in BLACK_LIST):
            continue
        else:
            result.append(i)
    return result

def main():
    net_connections = Net_Connections(psutil.net_connections(kind='inet'))
    net_conns = net_connections.parse_ps_net_connections()
    timestamp = int(time.time())

    proc_name_list = get_process_name()
    task_dict = dict()

    try:
        for i in proc_name_list:
            proc = OSMetric(tag=i, timestamp=timestamp)
            task_dict[i] = proc
    except Exception, e:
        pass

    for proc in psutil.process_iter():
        try:
            if proc.name() in proc_name_list:
                task_dict[proc.name()].processers.append(proc)
                task_dict[proc.name()].p_active = True
            else:
                continue
        except Exception, e:
            pass

    for (key, task) in task_dict.items():
        task.run(net_conns)

    time.sleep(2)
    for (key, task) in task_dict.items():
        task.push_procs_cpu_percent()

    print json.dumps(RESULT)


if __name__ == '__main__':
    main()
